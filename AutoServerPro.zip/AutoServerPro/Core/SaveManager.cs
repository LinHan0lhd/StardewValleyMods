#nullable disable
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Serialization;
using HarmonyLib;
using Microsoft.Xna.Framework;
using StardewModdingAPI;
using StardewModdingAPI.Events;
using StardewValley;
using StardewValley.Extensions;
using StardewValley.ItemTypeDefinitions;
using StardewValley.Locations;
using StardewValley.Menus;
using StardewValley.Monsters;
using StardewValley.Objects;
using StardewValley.Pathfinding;
using AutoServerPro.Utils;
using StardewValley.SaveSerialization;
using AutoServerPro.Models;
using StardewValley.Characters;

namespace AutoServerPro.Core
{
    #region DTOs

    [XmlRoot("Items")] public class ItemsWrapper { [XmlElement("Item")] public Item[] Items { get; set; } }

    [XmlRoot("ChunkState")]
    public class ChunkState
    {
        [XmlElement("X")] public float X; [XmlElement("Y")] public float Y;
        [XmlElement("RandomOffset")] public int RandomOffset;
        [XmlElement("XSpriteSheet")] public int XSpriteSheet; [XmlElement("YSpriteSheet")] public int YSpriteSheet;
        [XmlElement("Scale")] public float Scale; [XmlElement("Alpha")] public float Alpha; [XmlElement("Rotation")] public float Rotation;
        [XmlElement("RotationVelocity")] public float RotationVelocity; [XmlElement("HitWall")] public bool HitWall;
        [XmlElement("Bob")] public float Bob; [XmlElement("Bounces")] public int Bounces;
    }

    [XmlRoot("DebrisState")]
    public class DebrisState
    {
        [XmlElement("LocationName")] public string LocationName;
        [XmlElement("ItemId")] public string ItemId; [XmlElement("ItemXml")] public string ItemXml;
        [XmlElement("Stack")] public int Stack; [XmlElement("Quality")] public int Quality;
        [XmlElement("DebrisType")] public int DebrisType; [XmlElement("ChunkType")] public int ChunkType;
        [XmlElement("ChunkFinalYLevel")] public int ChunkFinalYLevel; [XmlElement("FloppingFish")] public bool FloppingFish;
        [XmlElement("Scale")] public float Scale; [XmlElement("ItemQuality")] public int ItemQuality;
        [XmlElement("ChunksColorR")] public int ChunksColorR; [XmlElement("ChunksColorG")] public int ChunksColorG;
        [XmlElement("ChunksColorB")] public int ChunksColorB; [XmlElement("ChunksColorA")] public int ChunksColorA;
        [XmlElement("NonSpriteColorR")] public int NonSpriteColorR; [XmlElement("NonSpriteColorG")] public int NonSpriteColorG;
        [XmlElement("NonSpriteColorB")] public int NonSpriteColorB; [XmlElement("NonSpriteColorA")] public int NonSpriteColorA;
        [XmlElement("SpriteChunkSheetName")] public string SpriteChunkSheetName;
        [XmlElement("SizeOfSourceRectSquares")] public int SizeOfSourceRectSquares;
        [XmlElement("DebrisMessage")] public string DebrisMessage;
        [XmlElement("IsSinking")] public bool IsSinking;
        [XmlElement("ChunksMoveTowardPlayer")] public bool ChunksMoveTowardPlayer;
        [XmlElement("TimeSinceDoneBouncing")] public float TimeSinceDoneBouncing;
        [XmlArray("Chunks")][XmlArrayItem("Chunk")] public List<ChunkState> Chunks = new List<ChunkState>();
    }

    [XmlRoot("ObjectState")]
    public class ObjectState { [XmlElement("TileX")] public float TileX; [XmlElement("TileY")] public float TileY; [XmlElement("ItemId")] public string ItemId; [XmlElement("ItemXml")] public string ItemXml; }

    [XmlRoot("FarmerPositionState")]
    public class FarmerPositionState { [XmlElement("FarmerId")] public long FarmerId; [XmlElement("X")] public float X; [XmlElement("Y")] public float Y; }

    [XmlRoot("MineState")]
    public class MineState
    {
        [XmlElement("MineLevel")] public int MineLevel; [XmlElement("ForceLayout")] public int? ForceLayout;
        [XmlArray("Objects")][XmlArrayItem("Object")] public List<ObjectState> Objects = new List<ObjectState>();
        [XmlArray("FarmerPositions")][XmlArrayItem("FarmerPosition")] public List<FarmerPositionState> FarmerPositions = new List<FarmerPositionState>();
    }

    [XmlRoot("NpcPositionData")]
    public class NpcPositionData
    {
        [XmlElement("Name")] public string Name { get; set; }
        [XmlElement("MapName")] public string MapName { get; set; }
        [XmlElement("X")] public float X { get; set; }
        [XmlElement("Y")] public float Y { get; set; }
    }

    [XmlRoot("GameStateSnapshot")]
    public class GameStateSnapshot
    {
        [XmlElement("TimeOfDay")] public int TimeOfDay;
        [XmlArray("DebrisItems")][XmlArrayItem("DebrisItem")] public List<DebrisState> DebrisItems = new List<DebrisState>();
        [XmlElement("MineState")] public MineState Mine;
        [XmlArray("NpcPositions")][XmlArrayItem("NpcPosition")] public List<NpcPositionData> NpcPositions = new List<NpcPositionData>();
    }

    #endregion

    /// <summary>
    /// Harmony 补丁，用于在保存时更新所有 NPC 的 DefaultMap 和 DefaultPosition，
    /// 确保加载后 NPC 出现在保存时的精确位置。
    /// </summary>
    public static class SavePatch
    {
        public static IMonitor Monitor { get; set; }

        [HarmonyPostfix]
        [HarmonyPatch(typeof(SaveGame), nameof(SaveGame.getSaveEnumerator))]
        public static void Postfix()
        {
            Monitor?.Log("SavePatch.Postfix is running!", LogLevel.Info);

            foreach (var npc in Utility.getAllCharacters())
            {
                if (npc.currentLocation == null)
                    continue;

                Monitor?.Log($"Save NPC: {npc.Name}, Map: {npc.currentLocation.NameOrUniqueName}, Pos: {npc.Position}, DefaultPos: {npc.DefaultPosition}");
                npc.DefaultMap = npc.currentLocation.NameOrUniqueName;
                npc.DefaultPosition = npc.Position;
            }
        }
    }

    public class SaveManager
    {
        private readonly IMonitor _monitor;
        private ModConfig _config;
        private readonly IModHelper _helper;
        private readonly FestivalManager _festivalManager;
        private string _currentSaveName = "";
        private Harmony _harmony;
        private static string _tempSavesPathOverride;
        private static bool _npcPatchRegistered = false;

        private IEnumerator<int> _saveCoroutine;
        private bool _isSaving, _waitingForFestivalEnd, _saveRequestedDuringFestival, _quitAfterSave;
        private GameStateSnapshot _pendingSnapshot;
        private int _freezeDelay = 0;
        public bool IsSavingComplete { get; private set; }
        public bool IsSaving => _isSaving;
        public bool IsWaitingFestivalEnd => _waitingForFestivalEnd;
        public string CurrentSavesPath { get; private set; }

        private static readonly XmlSerializer ItemSerializer, SnapshotSerializer;
        private static readonly Type[] ItemDerivedTypes;
        private static readonly MethodInfo GetSaveEnumeratorMethod, LoadForNewGameMethod;
        private static readonly MethodInfo GetRouteEndBehaviorMethod;

        static SaveManager()
        {
            ItemDerivedTypes = Assembly.GetAssembly(typeof(Item)).GetTypes().Where(t => t.IsSubclassOf(typeof(Item)) && !t.IsAbstract).ToArray();
            ItemSerializer = new XmlSerializer(typeof(ItemsWrapper), ItemDerivedTypes);
            SnapshotSerializer = new XmlSerializer(typeof(GameStateSnapshot));

            GetSaveEnumeratorMethod = AccessTools.Method(typeof(SaveGame), "getSaveEnumerator");
            LoadForNewGameMethod = AccessTools.Method(typeof(Game1), "loadForNewGame");
            // 反射获取受保护的 getRouteEndBehaviorFunction 方法
            GetRouteEndBehaviorMethod = typeof(NPC).GetMethod("getRouteEndBehaviorFunction", BindingFlags.Instance | BindingFlags.NonPublic);
        }

        public SaveManager(IMonitor monitor, ModConfig config, IModHelper helper, FestivalManager festivalManager)
        {
            _monitor = monitor;
            _config = config;
            _helper = helper;
            _festivalManager = festivalManager;
            CurrentSavesPath = SavesRootPath;

            try
            {
                _harmony = new Harmony("LinHan.AutoServerPro.SavePathRedirect");
                SavePatch.Monitor = monitor;

                if (!_npcPatchRegistered)
                {
                    var original = AccessTools.Method(typeof(SaveGame), "getSaveEnumerator");
                    var postfix = new HarmonyMethod(typeof(SavePatch), nameof(SavePatch.Postfix));
                    _harmony.Patch(original, postfix: postfix);
                    _npcPatchRegistered = true;
                    _monitor.Log("NPC 位置保存补丁已注册", LogLevel.Info);
                }
            }
            catch (Exception ex)
            {
                _monitor.Log($"注册 NPC 补丁失败: {ex.Message}", LogLevel.Warn);
            }

            _helper.Events.GameLoop.SaveLoaded += OnSaveLoaded;
            _helper.Events.GameLoop.UpdateTicked += OnUpdateTicked;
        }

        private void OnSaveLoaded(object sender, SaveLoadedEventArgs e)
        {
            if (!Context.IsMainPlayer) return;
            RestoreExtraDataAfterLoad();
            _freezeDelay = 2; // 延迟两帧，确保 NPC 位置已稳定，再恢复日程
        }

        private void OnUpdateTicked(object sender, UpdateTickedEventArgs e)
        {
            if (_freezeDelay > 0)
            {
                _freezeDelay--;
                if (_freezeDelay == 0)
                {
                    ResumeAllNpcSchedules();
                }
            }
        }

        /// <summary>同步在线农场工人的当前位置到 farmhandData，确保存档后能恢复正确位置。</summary>
        private static void SyncOnlinePlayerPositions()
        {
            if (Game1.netWorldState?.Value?.farmhandData == null) return;
            int daysPlayed = (int?)Game1.MasterPlayer?.stats?.DaysPlayed ?? 0;
            foreach (var farmer in Game1.otherFarmers.Values)
            {
                if (farmer == null) continue;
                try
                {
                    if (Game1.netWorldState.Value.farmhandData.TryGetValue(farmer.UniqueMultiplayerID, out var fd))
                    {
                        fd.disconnectPosition.Value = farmer.position.Value;
                        fd.disconnectLocation.Value = farmer.currentLocation?.NameOrUniqueName ?? "";
                        fd.disconnectDay.Value = daysPlayed;
                    }
                }
                catch { }
            }
        }

        public void UpdateConfig(ModConfig config) => _config = config;

        public string SavesRootPath => string.IsNullOrWhiteSpace(_config.CustomSavesPath)
            ? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "StardewValley", "Saves") : _config.CustomSavesPath;
        public string BackupRootPath => string.IsNullOrWhiteSpace(_config.BackupPath)
            ? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "StardewValley", "AutoServerBackups") : _config.BackupPath;
        public string TempSavesRootPath => string.IsNullOrWhiteSpace(_config.CustomTempSavesPath)
            ? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "StardewValley", "TempSaves") : _config.CustomTempSavesPath;

        private string ExtraDataPath(string saveName) => Path.Combine(CurrentSavesPath, saveName, "extradata.xml");

        #region 路径重定向

        public void RedirectSavesToTemp()
        {
            try
            {
                _harmony ??= new Harmony("LinHan.AutoServerPro.SavePathRedirect");
                var method = AccessTools.Method(typeof(Program), "GetSavesFolder");
                if (method == null) { _monitor.Log("无法找到 Program.GetSavesFolder 方法", LogLevel.Error); return; }

                var patchInfo = Harmony.GetPatchInfo(method);
                bool hasPrefix = patchInfo?.Prefixes?.Any(p => p.owner == "LinHan.AutoServerPro.SavePathRedirect") ?? false;
                if (!hasPrefix)
                    _harmony.Patch(method, prefix: new HarmonyMethod(typeof(SaveManager), nameof(GetSavesFolderPrefix)));

                _tempSavesPathOverride = TempSavesRootPath;
                CurrentSavesPath = TempSavesRootPath;
            }
            catch (Exception ex) { _monitor.Log($"重定向存档路径失败: {ex.Message}", LogLevel.Error); }
        }

        public void RedirectSavesToOriginal()
        {
            try
            {
                if (_harmony != null)
                {
                    var method = AccessTools.Method(typeof(Program), "GetSavesFolder");
                    if (method != null) _harmony.Unpatch(method, HarmonyPatchType.Prefix, "LinHan.AutoServerPro.SavePathRedirect");
                }
            }
            catch (Exception ex) { _monitor.Log($"恢复存档路径失败: {ex.Message}", LogLevel.Warn); }
            finally { CurrentSavesPath = SavesRootPath; }
        }

        private static bool GetSavesFolderPrefix(ref string __result)
        {
            __result = _tempSavesPathOverride ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "StardewValley", "TempSaves");
            return false;
        }

        #endregion

        #region 自动加载

        private string GetLatestSave()
        {
            if (Directory.Exists(SavesRootPath))
            {
                var dirs = Directory.GetDirectories(SavesRootPath).OrderByDescending(d => Directory.GetLastWriteTime(d)).ToList();
                if (dirs.Count > 0)
                {
                    string name = Path.GetFileName(dirs[0]);
                    string tempDir = Path.Combine(TempSavesRootPath, name);
                    if (Directory.Exists(tempDir) && Directory.GetLastWriteTime(tempDir) > Directory.GetLastWriteTime(dirs[0]))
                        return name;
                    return name;
                }
            }
            if (Directory.Exists(TempSavesRootPath))
            {
                var dirs = Directory.GetDirectories(TempSavesRootPath).OrderByDescending(d => Directory.GetLastWriteTime(d)).ToList();
                if (dirs.Count > 0) return Path.GetFileName(dirs[0]);
            }
            return null;
        }

        private void LoadSave(string saveName)
        {
            string path = Path.Combine(CurrentSavesPath, saveName);
            if (!Directory.Exists(path)) { _monitor.Log($"存档 {saveName} 不存在", LogLevel.Warn); return; }
            try
            {
                SaveGame.Load(saveName); _currentSaveName = saveName;
                if (Game1.activeClickableMenu is TitleMenu menu) menu.exitThisMenu(false);
                _monitor.Log($"存档 {saveName} 加载成功", LogLevel.Info);
            }
            catch (Exception ex) { _monitor.Log($"加载存档失败：{ex.Message}", LogLevel.Error); }
        }

        public bool AutoLoadSave()
        {
            string saveName = !string.IsNullOrWhiteSpace(_config.NewSaveName) ? _config.NewSaveName : GetLatestSave();
            if (string.IsNullOrEmpty(saveName)) { _monitor.Log("未找到存档", LogLevel.Info); return false; }
            string src = DetermineLoadSource(saveName);
            if (src == "TempSaves") RedirectSavesToTemp(); else RedirectSavesToOriginal();
            _monitor.Log($"加载存档：{saveName}（来源：{src}）", LogLevel.Info);
            LoadSave(saveName);
            Game1.multiplayerMode = 2;
            return true;
        }

        private string DetermineLoadSource(string saveName)
        {
            string savesDir = Path.Combine(SavesRootPath, saveName), tempDir = Path.Combine(TempSavesRootPath, saveName);
            bool hasSaves = Directory.Exists(savesDir), hasTemp = Directory.Exists(tempDir);
            if (!hasTemp) return "Saves"; if (!hasSaves) return "TempSaves";
            var savesTime = GetDirectoryLatestTime(savesDir); var tempTime = GetDirectoryLatestTime(tempDir);
            if (!savesTime.HasValue) return "TempSaves"; if (!tempTime.HasValue) return "Saves";
            return savesTime.Value >= tempTime.Value ? "Saves" : "TempSaves";
        }

        #endregion

        #region 额外数据恢复

        public void RestoreExtraDataAfterLoad()
        {
            if (string.IsNullOrEmpty(_currentSaveName)) return;
            string extraPath = ExtraDataPath(_currentSaveName);
            if (!File.Exists(extraPath)) { _monitor.Log("无额外存档数据，跳过恢复", LogLevel.Debug); return; }
            try
            {
                using (var fs = new FileStream(extraPath, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    var snapshot = (GameStateSnapshot)SnapshotSerializer.Deserialize(fs);
                    if (snapshot == null) return;
                    _monitor.Log($"加载额外数据 - 时间: {snapshot.TimeOfDay}:00, 掉落物: {snapshot.DebrisItems.Count}, NPC: {snapshot.NpcPositions.Count}", LogLevel.Info);
                    RestoreSnapshot(snapshot);
                }
            }
            catch (Exception ex) { _monitor.Log($"恢复存档数据失败: {ex.Message}", LogLevel.Warn); }
        }

        private void RestoreNpcPositions(List<NpcPositionData> positions)
        {
            if (positions == null || positions.Count == 0) return;

            // 冻结所有 NPC
            FreezeAllNpcs();

            int restored = 0;
            foreach (var pos in positions)
            {
                try
                {
                    var npc = Game1.getCharacterFromName(pos.Name, mustBeVillager: false);
                    if (npc == null) continue;

                    var loc = Game1.getLocationFromName(pos.MapName);
                    if (loc == null) continue;

                    Game1.warpCharacter(npc, loc, new Vector2(pos.X, pos.Y));

                    // 再次冻结，防止 warpCharacter 后自动解冻
                    npc.ignoreScheduleToday = true;
                    npc.controller = null;
                    npc.temporaryController = null;
                    restored++;
                }
                catch (Exception ex)
                {
                    _monitor?.Log($"恢复 NPC {pos.Name} 失败: {ex.Message}", LogLevel.Warn);
                }
            }

            // 再次冻结所有 NPC（确保安全）
            FreezeAllNpcs();

            _monitor?.Log($"恢复了 {restored} 个 NPC 位置（已冻结）", LogLevel.Info);
        }

        private void FreezeAllNpcs()
        {
            foreach (var npc in Utility.getAllCharacters())
            {
                if (npc.IsVillager)
                {
                    npc.ignoreScheduleToday = true;
                    npc.controller = null;
                    npc.temporaryController = null;
                }
            }
        }

        private void ResumeAllNpcSchedules()
        {
            foreach (var npc in Utility.getAllCharacters())
            {
                if (!npc.IsVillager) continue;
                if (npc.Schedule == null || npc.Schedule.Count == 0) continue;

                try
                {
                    // 清除旧控制器
                    npc.controller = null;
                    npc.temporaryController = null;

                    // 找到当前时间之前最近的日程条目（过去的）
                    var entry = npc.Schedule
                        .Where(kv => kv.Key <= Game1.timeOfDay)
                        .OrderByDescending(kv => kv.Key)
                        .FirstOrDefault();

                    if (entry.Key == 0) continue;

                    var pathDesc = entry.Value;
                    string targetLocationName = pathDesc.targetLocationName;
                    Point targetTile = pathDesc.targetTile;
                    GameLocation targetLocation = Game1.getLocationFromName(targetLocationName);
                    if (targetLocation == null) continue;

                    // 从当前位置重新生成路径到目标点
                    var newPathDesc = npc.pathfindToNextScheduleLocation(
                        "resume",
                        npc.currentLocation.NameOrUniqueName,
                        npc.TilePoint.X,
                        npc.TilePoint.Y,
                        targetLocationName,
                        targetTile.X,
                        targetTile.Y,
                        pathDesc.facingDirection,
                        pathDesc.endOfRouteBehavior,
                        pathDesc.endOfRouteMessage
                    );

                    if (newPathDesc?.route == null || newPathDesc.route.Count == 0)
                        continue;

                    // 创建控制器
                    var controller = new PathFindController(newPathDesc.route, npc, npc.currentLocation);
                    controller.finalFacingDirection = newPathDesc.facingDirection;

                    // 反射调用 getRouteEndBehaviorFunction 获取结束行为委托
                    if (GetRouteEndBehaviorMethod != null)
                    {
                        var endBehavior = GetRouteEndBehaviorMethod.Invoke(npc, new object[] { newPathDesc.endOfRouteBehavior, newPathDesc.endOfRouteMessage });
                        if (endBehavior is PathFindController.endBehavior behavior)
                            controller.endBehaviorFunction = behavior;
                    }

                    npc.controller = controller;
                    npc.lastAttemptedSchedule = entry.Key;
                    npc.ignoreScheduleToday = false; // 解冻，让 NPC 开始移动
                }
                catch (Exception ex)
                {
                    _monitor?.Log($"NPC {npc.Name} 恢复日程失败: {ex.Message}", LogLevel.Trace);
                }
            }
        }

        private void RestoreSnapshot(GameStateSnapshot snapshot)
        {
            // 恢复 NPC 位置并冻结
            RestoreNpcPositions(snapshot.NpcPositions);

            // 恢复时间
            SafelySetTime(snapshot.TimeOfDay);

            // 恢复矿井和掉落物
            RestoreMineState(snapshot);
            RestoreDebrisItems(snapshot);

            _monitor.Log("快照恢复完成", LogLevel.Info);
        }

        private void SafelySetTime(int targetTime)
        {
            int intervals = Utility.CalculateMinutesBetweenTimes(Game1.timeOfDay, targetTime) / 10;
            if (intervals > 0)
            {
                for (int i = 0; i < intervals; i++)
                    Game1.performTenMinuteClockUpdate();
            }
            else if (intervals < 0)
            {
                for (int i = 0; i > intervals; i--)
                {
                    Game1.timeOfDay = Utility.ModifyTime(Game1.timeOfDay, -20);
                    Game1.performTenMinuteClockUpdate();
                }
            }

            Game1.outdoorLight = Color.White;
            Game1.ambientLight = Color.White;
            Game1.gameTimeInterval = 0;
            Game1.UpdateGameClock(Game1.currentGameTime);
        }

        #endregion

        #region 矿井恢复

        private void RestoreMineState(GameStateSnapshot snapshot)
        {
            if (snapshot.Mine == null) return;
            var mineState = snapshot.Mine;
            var current = Game1.currentLocation as MineShaft;
            if (current == null) { _monitor.Log("跳过矿井恢复：当前非矿井", LogLevel.Debug); return; }
            _monitor.Log($"恢复矿井: Level={mineState.MineLevel}", LogLevel.Debug);

            if (current.mineLevel == mineState.MineLevel)
            {
                current.objects.Clear(); current.terrainFeatures.Clear();
                foreach (var os in mineState.Objects)
                {
                    Item item = null;
                    if (!string.IsNullOrEmpty(os.ItemXml)) try { item = DeserializeItem(os.ItemXml); } catch { }
                    if (item == null && !string.IsNullOrEmpty(os.ItemId)) item = ItemRegistry.Create(os.ItemId);
                    if (item is StardewValley.Object obj) { obj.TileLocation = new Vector2(os.TileX, os.TileY); current.objects[obj.TileLocation] = obj; }
                }
            }

            int daysPlayed = (int)Game1.MasterPlayer.stats.DaysPlayed;
            foreach (var fp in mineState.FarmerPositions)
            {
                if (Game1.netWorldState.Value.farmhandData.TryGetValue(fp.FarmerId, out var fh))
                {
                    fh.disconnectDay.Value = daysPlayed;
                    fh.disconnectLocation.Value = current.NameOrUniqueName;
                    fh.disconnectPosition.Value = new Vector2(fp.X, fp.Y);
                }
            }
        }

        #endregion

        #region 掉落物恢复

        private void RestoreDebrisItems(GameStateSnapshot snapshot)
        {
            if (snapshot.DebrisItems == null || snapshot.DebrisItems.Count == 0) return;
            _monitor.Log($"恢复 {snapshot.DebrisItems.Count} 个掉落物", LogLevel.Debug);

            var locs = snapshot.DebrisItems.Select(d => d.LocationName).Where(n => !string.IsNullOrEmpty(n)).Distinct().ToList();
            foreach (var ln in locs)
            {
                var loc = Game1.getLocationFromName(ln);
                if (loc != null) loc.debris.Clear();
            }

            int restored = 0, failed = 0;
            foreach (var ds in snapshot.DebrisItems)
            {
                try
                {
                    var loc = Game1.getLocationFromName(ds.LocationName);
                    if (loc == null) continue;

                    Item item = null;
                    if (!string.IsNullOrEmpty(ds.ItemXml)) try { item = DeserializeItem(ds.ItemXml); } catch { }
                    if (item == null && !string.IsNullOrEmpty(ds.ItemId)) item = ItemRegistry.Create(ds.ItemId, ds.Stack > 0 ? ds.Stack : 1, ds.Quality);
                    if (item == null) { failed++; continue; }

                    var debris = new Debris();
                    debris.itemId.Value = item.QualifiedItemId;
                    debris.itemQuality = item.Quality;
                    if (ds.Stack > 0) item.Stack = ds.Stack;

                    debris.InitializeItem(item.QualifiedItemId);
                    debris.debrisType.Value = (Debris.DebrisType)ds.DebrisType;

                    var data = ItemRegistry.GetData(item.QualifiedItemId);
                    if (data.HasTypeObject())
                    {
                        debris.floppingFish.Value = (data.Category == -4 && data.InternalName != "Mussel");
                        debris.isFishable = (data.ObjectType == "Fish");
                        if (data.ObjectType == "Arch") debris.debrisType.Value = Debris.DebrisType.ARCHAEOLOGY;
                    }
                    else debris.item = item;

                    debris.chunkType.Value = ds.ChunkType;
                    debris.chunkFinalYLevel = ds.ChunkFinalYLevel;
                    debris.scale.Value = ds.Scale;
                    debris.chunksMoveTowardPlayer = ds.ChunksMoveTowardPlayer;
                    debris.timeSinceDoneBouncing = ds.TimeSinceDoneBouncing;
                    debris.isSinking.Value = ds.IsSinking;
                    debris.chunksColor.Value = new Color(ds.ChunksColorR, ds.ChunksColorG, ds.ChunksColorB, ds.ChunksColorA);
                    debris.nonSpriteChunkColor.Value = new Color(ds.NonSpriteColorR, ds.NonSpriteColorG, ds.NonSpriteColorB, ds.NonSpriteColorA);
                    debris.spriteChunkSheetName.Value = ds.SpriteChunkSheetName ?? "";
                    debris.sizeOfSourceRectSquares.Value = ds.SizeOfSourceRectSquares;
                    debris.debrisMessage.Value = ds.DebrisMessage ?? "";

                    debris.Chunks.Clear();
                    if (ds.Chunks != null && ds.Chunks.Count > 0)
                    {
                        foreach (var cs in ds.Chunks)
                        {
                            var chunk = new Chunk(new Vector2(cs.X, cs.Y), 0f, 0f, cs.RandomOffset);
                            chunk.xSpriteSheet.Value = cs.XSpriteSheet; chunk.ySpriteSheet.Value = cs.YSpriteSheet;
                            chunk.scale = cs.Scale; chunk.alpha = cs.Alpha; chunk.rotation = cs.Rotation;
                            chunk.rotationVelocity = cs.RotationVelocity; chunk.hitWall = cs.HitWall; chunk.bob = cs.Bob; chunk.bounces = cs.Bounces;
                            chunk.hasPassedRestingLineOnce.Value = true; chunk.sinkTimer.Value = int.MaxValue;
                            chunk.position.Field.CancelInterpolation();
                            debris.Chunks.Add(chunk);
                        }
                    }
                    else
                    {
                        debris.Chunks.Add(new Chunk(new Vector2(0, ds.ChunkFinalYLevel), 0f, 0f, 0) { scale = 1f, alpha = 1f, hasPassedRestingLineOnce = { Value = true }, sinkTimer = { Value = int.MaxValue } });
                    }

                    loc.debris.Add(debris); restored++;
                }
                catch { failed++; }
            }
            _monitor.Log($"掉落物恢复: 成功{restored}个, 失败{failed}个", LogLevel.Debug);
        }

        #endregion

        #region 序列化

        private string SerializeItem(Item item)
        {
            try
            {
                var wrapper = new ItemsWrapper { Items = new[] { item } };
                using (var ms = new MemoryStream()) { ItemSerializer.Serialize(ms, wrapper); ms.Position = 0; return new StreamReader(ms).ReadToEnd(); }
            }
            catch { return null; }
        }

        private Item DeserializeItem(string xml)
        {
            try
            {
                if (string.IsNullOrEmpty(xml)) return null;
                xml = Regex.Replace(xml, @"\s+xmlns:xsd\s*=\s*[""'][^""']*[""']", "");
                using (var sr = new StringReader(xml))
                {
                    var wrapper = (ItemsWrapper)ItemSerializer.Deserialize(sr);
                    return wrapper?.Items?.FirstOrDefault();
                }
            }
            catch { return null; }
        }

        #endregion

        #region 备份

        private string GetBackupRootPath() { string p = BackupRootPath; if (!Directory.Exists(p)) Directory.CreateDirectory(p); return p; }

        public void AutoBackupCheck()
        {
            if (!Context.IsWorldReady || string.IsNullOrEmpty(_currentSaveName)) return;
            string saveDir = Path.Combine(CurrentSavesPath, _currentSaveName);
            if (!Directory.Exists(saveDir)) return;
            string marker = Path.Combine(saveDir, ".last_backup");
            int today = Game1.Date.TotalDays;
            if (File.Exists(marker) && int.TryParse(File.ReadAllText(marker).Trim(), out int last) && (today - last) < _config.AutoBackupDayInterval) return;
            DoSaveBackup(_currentSaveName);
            File.WriteAllText(marker, today.ToString());
            if (_config.AutoCleanOldBackup) CleanOldBackups(GetBackupRootPath());
        }

        private void DoSaveBackup(string saveName)
        {
            string src = Path.Combine(CurrentSavesPath, saveName);
            string dst = Path.Combine(BackupRootPath, $"{saveName}_{DateTime.Now:yyyyMMdd_HHmmss}");
            DirectoryHelper.CopyDirectory(src, dst, true);
            _monitor.Log($"备份完成：{Path.GetFileName(dst)}", LogLevel.Info);
        }

        private void CleanOldBackups(string root)
        {
            if (!Directory.Exists(root)) return;
            var dirs = new DirectoryInfo(root).GetDirectories().OrderByDescending(d => d.CreationTime).ToList();
            foreach (var d in dirs.Skip(_config.MaxBackupCount)) { Directory.Delete(d.FullName, true); _monitor.Log($"清理过期备份：{d.Name}", LogLevel.Debug); }
        }

        public void ManualBackupCommand(string _, string[] __)
        {
            if (!Context.IsWorldReady || string.IsNullOrEmpty(_currentSaveName)) { _monitor.Log("请先加载存档", LogLevel.Warn); return; }
            DoSaveBackup(_currentSaveName);
        }

        #endregion

        #region 保存流程

        public void TickFestivalSaveFlow()
        {
            if (!_waitingForFestivalEnd) return;
            if (_festivalManager.IsFestivalActive)
            {
                if (Game1.multiplayerMode != 0) { Game1.multiplayerMode = 0; _monitor.Log("节日中切换单机模式...", LogLevel.Info); }
                return;
            }
            _waitingForFestivalEnd = false;
            if (_saveRequestedDuringFestival) { _saveRequestedDuringFestival = false; ForceSaveNow(); }
        }

        public void ForceSaveNow()
        {
            if (!Context.IsWorldReady) { _monitor.Log("世界未加载", LogLevel.Warn); return; }
            if (_isSaving) { _monitor.Log("保存中...", LogLevel.Warn); return; }
            if (_festivalManager.IsFestivalActive) { _waitingForFestivalEnd = true; _saveRequestedDuringFestival = true; _monitor.Log("等待节日结束...", LogLevel.Info); return; }
            if (SaveGame.IsProcessing) { _monitor.Log("游戏正在保存", LogLevel.Warn); return; }

            try
            {
                // 同步在线玩家位置
                SyncOnlinePlayerPositions();

                RedirectSavesToTemp();
                _pendingSnapshot = CreateSnapshot();

                if (GetSaveEnumeratorMethod == null)
                {
                    _monitor.Log("找不到 getSaveEnumerator", LogLevel.Error);
                    SaveGame.IsProcessing = false;
                    _pendingSnapshot = null;
                    return;
                }

                SaveGame.IsProcessing = true;
                _saveCoroutine = (IEnumerator<int>)GetSaveEnumeratorMethod.Invoke(null, null);
                _isSaving = true;
                IsSavingComplete = false;
                _monitor.Log($"开始保存... (掉落物: {_pendingSnapshot.DebrisItems.Count})", LogLevel.Info);
            }
            catch (Exception ex)
            {
                _monitor.Log($"启动保存失败: {ex.Message}", LogLevel.Error);
                CleanupSaveState();
            }
        }

        public void ForceSaveAndQuit()
        {
            if (!Context.IsWorldReady) { Game1.quit = true; return; }
            if (_isSaving) { _quitAfterSave = true; return; }
            IsSavingComplete = false; _quitAfterSave = true; ForceSaveNow();
            if (!_isSaving) Game1.quit = true;
        }

        private void CleanupSaveState()
        {
            _isSaving = false;
            _saveCoroutine = null;
            SaveGame.IsProcessing = false;
            _pendingSnapshot = null;
        }

        public void UpdateSave()
        {
            if (!_isSaving || _saveCoroutine == null) return;
            try
            {
                bool moved = _saveCoroutine.MoveNext();
                int progress = moved ? _saveCoroutine.Current : -1;
                if ((moved && progress == 100) || !moved) FinishSave();
                else if (progress % 20 == 0) _monitor.Log($"保存进度: {progress}%", LogLevel.Debug);
            }
            catch (Exception ex)
            {
                _monitor.Log($"保存失败: {ex.Message}", LogLevel.Error);
                CleanupSaveState();
                if (_quitAfterSave) { Game1.quit = true; _quitAfterSave = false; }
            }
        }

        private void FinishSave()
        {
            _monitor.Log("原生保存完成", LogLevel.Info);
            IsSavingComplete = true;

            var snapshot = _pendingSnapshot;

            if (snapshot != null)
            {
                try { SaveExtraData(snapshot); }
                catch (Exception ex) { _monitor.Log($"保存额外数据失败: {ex.Message}", LogLevel.Warn); }
            }

            CleanupSaveState();

            RedirectSavesToOriginal();

            if (!string.IsNullOrEmpty(_currentSaveName))
                try { DoSaveBackup(_currentSaveName); }
                catch (Exception ex) { _monitor.Log($"备份失败: {ex.Message}", LogLevel.Warn); }

            if (_quitAfterSave)
            {
                _quitAfterSave = false;
                Game1.quit = true;
            }
        }

        #endregion

        #region 快照

        private GameStateSnapshot CreateSnapshot()
        {
            var snapshot = new GameStateSnapshot { TimeOfDay = Game1.timeOfDay };
            int debrisCount = 0, chunkCount = 0, failed = 0, xmlFail = 0;

            // 收集掉落物
            foreach (var loc in Game1.locations)
            {
                if (loc?.debris == null) continue;
                foreach (var debris in loc.debris)
                {
                    try
                    {
                        Item item = debris.item;
                        string itemId = debris.itemId.Value;
                        if (item == null && !string.IsNullOrEmpty(itemId)) item = ItemRegistry.Create(itemId, 1, debris.itemQuality);
                        if (item == null) continue;

                        string itemXml = null; try { itemXml = SerializeItem(item); } catch { }
                        var state = new DebrisState
                        {
                            LocationName = loc.NameOrUniqueName,
                            ItemId = itemId ?? item.QualifiedItemId,
                            ItemXml = itemXml,
                            Stack = item.Stack > 0 ? item.Stack : 1,
                            Quality = item.Quality,
                            DebrisType = (int)debris.debrisType.Value,
                            ChunkType = debris.chunkType.Value,
                            ChunkFinalYLevel = debris.chunkFinalYLevel,
                            FloppingFish = debris.floppingFish.Value,
                            Scale = debris.scale.Value,
                            ItemQuality = debris.itemQuality,
                            ChunksColorR = debris.chunksColor.Value.R,
                            ChunksColorG = debris.chunksColor.Value.G,
                            ChunksColorB = debris.chunksColor.Value.B,
                            ChunksColorA = debris.chunksColor.Value.A,
                            NonSpriteColorR = debris.nonSpriteChunkColor.Value.R,
                            NonSpriteColorG = debris.nonSpriteChunkColor.Value.G,
                            NonSpriteColorB = debris.nonSpriteChunkColor.Value.B,
                            NonSpriteColorA = debris.nonSpriteChunkColor.Value.A,
                            SpriteChunkSheetName = debris.spriteChunkSheetName.Value ?? "",
                            SizeOfSourceRectSquares = debris.sizeOfSourceRectSquares.Value,
                            DebrisMessage = debris.debrisMessage.Value ?? "",
                            IsSinking = debris.isSinking.Value,
                            ChunksMoveTowardPlayer = debris.chunksMoveTowardPlayer,
                            TimeSinceDoneBouncing = debris.timeSinceDoneBouncing,
                        };

                        if (debris.Chunks != null && debris.Chunks.Count > 0)
                        {
                            foreach (var chunk in debris.Chunks)
                            {
                                try
                                {
                                    Vector2 pos = chunk.position.Field.TargetValue;
                                    state.Chunks.Add(new ChunkState
                                    {
                                        X = pos.X,
                                        Y = pos.Y,
                                        RandomOffset = chunk.randomOffset,
                                        XSpriteSheet = chunk.xSpriteSheet.Value,
                                        YSpriteSheet = chunk.ySpriteSheet.Value,
                                        Scale = chunk.scale,
                                        Alpha = chunk.alpha,
                                        Rotation = chunk.rotation,
                                        RotationVelocity = chunk.rotationVelocity,
                                        HitWall = chunk.hitWall,
                                        Bob = chunk.bob,
                                        Bounces = chunk.bounces,
                                    });
                                    chunkCount++;
                                }
                                catch { }
                            }
                        }
                        else state.Chunks.Add(new ChunkState { X = 0, Y = debris.chunkFinalYLevel, Scale = 1f, Alpha = 1f });

                        snapshot.DebrisItems.Add(state);
                        if (itemXml == null) xmlFail++; debrisCount++;
                    }
                    catch { failed++; }
                }
            }

            // 收集矿井状态
            var mine = Game1.currentLocation as MineShaft;
            if (mine != null)
            {
                int? forceLayout = null; try { MineShaft.IsGeneratedLevel(mine, out _, out forceLayout); } catch { }
                snapshot.Mine = new MineState { MineLevel = mine.mineLevel, ForceLayout = forceLayout };
                foreach (var farmer in Game1.getAllFarmers())
                    if (farmer.currentLocation == mine)
                        snapshot.Mine.FarmerPositions.Add(new FarmerPositionState { FarmerId = farmer.UniqueMultiplayerID, X = farmer.Position.X, Y = farmer.Position.Y });

                foreach (var kvp in mine.objects.Pairs.ToList())
                {
                    try
                    {
                        var obj = kvp.Value; if (obj?.ItemId == null) continue;
                        string itemXml = null; try { itemXml = SerializeItem(obj); } catch { }
                        snapshot.Mine.Objects.Add(new ObjectState { TileX = kvp.Key.X, TileY = kvp.Key.Y, ItemId = obj.ItemId, ItemXml = itemXml });
                    }
                    catch { }
                }
            }

            // 收集 NPC 位置
            foreach (var npc in Utility.getAllCharacters())
            {
                if (npc.currentLocation == null) continue;
                snapshot.NpcPositions.Add(new NpcPositionData
                {
                    Name = npc.Name,
                    MapName = npc.currentLocation.NameOrUniqueName,
                    X = npc.Position.X,
                    Y = npc.Position.Y
                });
            }

            if (xmlFail > 0) _monitor.Log($"XML序列化失败: {xmlFail}个", LogLevel.Warn);
            if (failed > 0) _monitor.Log($"记录失败: {failed}个", LogLevel.Warn);
            return snapshot;
        }

        private void SaveExtraData(GameStateSnapshot snapshot)
        {
            if (string.IsNullOrEmpty(_currentSaveName)) return;
            try
            {
                string dir = Path.Combine(CurrentSavesPath, _currentSaveName);
                if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
                using (var fs = new FileStream(ExtraDataPath(_currentSaveName), FileMode.Create))
                    SnapshotSerializer.Serialize(fs, snapshot);
                _monitor.Log($"额外数据已保存: {snapshot.DebrisItems.Count}掉落物, {snapshot.NpcPositions.Count}个NPC", LogLevel.Info);
            }
            catch (Exception ex) { _monitor.Log($"保存额外数据失败: {ex.Message}", LogLevel.Warn); }
        }

        #endregion

        #region 新存档

        public void SetCurrentSaveName(string saveName) => _currentSaveName = saveName;

        public void CreateNewWorld(string saveName, string hostName = null)
        {
            hostName ??= _config.DefaultHostName;
            if (Directory.Exists(Path.Combine(CurrentSavesPath, saveName))) { _monitor.Log($"存档已存在", LogLevel.Error); return; }
            if (LoadForNewGameMethod == null) { _monitor.Log("找不到 loadForNewGame", LogLevel.Error); return; }
            try
            {
                Game1.SetSaveName(saveName);
                LoadForNewGameMethod.Invoke(Game1.game1, new object[] { false });
                if (!string.IsNullOrEmpty(hostName) && Game1.player != null) Game1.player.Name = hostName;
                _currentSaveName = saveName;
                _monitor.Log($"已创建新存档：{saveName}", LogLevel.Info);
            }
            catch (Exception ex) { _monitor.Log($"创建失败: {ex.Message}", LogLevel.Error); }
        }

        #endregion

        #region 工具

        private DateTime? GetDirectoryLatestTime(string dirPath)
        {
            if (!Directory.Exists(dirPath)) return null;
            try
            {
                var files = Directory.GetFiles(dirPath, "*", SearchOption.AllDirectories);
                if (files.Length == 0) return null;
                DateTime latest = DateTime.MinValue;
                foreach (var f in files) { var t = File.GetLastWriteTime(f); if (t > latest) latest = t; }
                return latest;
            }
            catch { return null; }
        }

        #endregion
    }
}