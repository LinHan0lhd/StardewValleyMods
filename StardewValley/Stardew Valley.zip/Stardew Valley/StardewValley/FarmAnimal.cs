﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Netcode;
using StardewValley.Audio;
using StardewValley.Buildings;
using StardewValley.Extensions;
using StardewValley.GameData;
using StardewValley.GameData.Buildings;
using StardewValley.GameData.FarmAnimals;
using StardewValley.Logging;
using StardewValley.Menus;
using StardewValley.Monsters;
using StardewValley.Network;
using StardewValley.Objects;
using StardewValley.Pathfinding;
using StardewValley.TerrainFeatures;
using StardewValley.TokenizableStrings;
using StardewValley.Tools;
using xTile.Dimensions;

namespace StardewValley
{
	// Token: 0x020000A2 RID: 162
	public class FarmAnimal : Character
	{
		// Token: 0x170000E8 RID: 232
		// (get) Token: 0x06000799 RID: 1945 RVA: 0x0004D908 File Offset: 0x0004BB08
		// (set) Token: 0x0600079A RID: 1946 RVA: 0x0004D920 File Offset: 0x0004BB20
		[XmlIgnore]
		public Building home
		{
			get
			{
				GameLocation value = this.netHomeInterior.Value;
				if (value == null)
				{
					return null;
				}
				return value.ParentBuilding;
			}
			set
			{
				this.netHomeInterior.Value = ((value != null) ? value.GetIndoors() : null);
			}
		}

		// Token: 0x170000E9 RID: 233
		// (get) Token: 0x0600079B RID: 1947 RVA: 0x0004D939 File Offset: 0x0004BB39
		// (set) Token: 0x0600079C RID: 1948 RVA: 0x0004D946 File Offset: 0x0004BB46
		[XmlIgnore]
		public GameLocation homeInterior
		{
			get
			{
				return this.netHomeInterior.Value;
			}
			set
			{
				this.netHomeInterior.Value = value;
			}
		}

		// Token: 0x170000EA RID: 234
		// (get) Token: 0x0600079D RID: 1949 RVA: 0x0004D954 File Offset: 0x0004BB54
		// (set) Token: 0x0600079E RID: 1950 RVA: 0x0004D9BC File Offset: 0x0004BBBC
		[XmlIgnore]
		public string displayHouse
		{
			get
			{
				if (this._displayHouse == null)
				{
					FarmAnimalData data = this.GetAnimalData();
					if (data != null)
					{
						BuildingData buildingData;
						this._displayHouse = (Game1.buildingData.TryGetValue(data.House, out buildingData) ? TokenParser.ParseText(buildingData.Name, null, null, null) : data.House);
					}
					else
					{
						this._displayHouse = this.buildingTypeILiveIn.Value;
					}
				}
				return this._displayHouse;
			}
			set
			{
				this._displayHouse = value;
			}
		}

		// Token: 0x170000EB RID: 235
		// (get) Token: 0x0600079F RID: 1951 RVA: 0x0004D9C5 File Offset: 0x0004BBC5
		// (set) Token: 0x060007A0 RID: 1952 RVA: 0x0004D9F5 File Offset: 0x0004BBF5
		[XmlIgnore]
		public string displayType
		{
			get
			{
				if (this._displayType == null)
				{
					FarmAnimalData animalData = this.GetAnimalData();
					this._displayType = TokenParser.ParseText((animalData != null) ? animalData.DisplayName : null, null, null, null);
				}
				return this._displayType;
			}
			set
			{
				this._displayType = value;
			}
		}

		// Token: 0x170000EC RID: 236
		// (get) Token: 0x060007A1 RID: 1953 RVA: 0x0004D9FE File Offset: 0x0004BBFE
		// (set) Token: 0x060007A2 RID: 1954 RVA: 0x0004DA06 File Offset: 0x0004BC06
		public override string displayName
		{
			get
			{
				return base.Name;
			}
			set
			{
			}
		}

		// Token: 0x170000ED RID: 237
		// (get) Token: 0x060007A3 RID: 1955 RVA: 0x0004DA08 File Offset: 0x0004BC08
		[MemberNotNullWhen(true, "home")]
		public bool IsHome
		{
			[MemberNotNullWhen(true, "home")]
			get
			{
				GameLocation homeInterior = this.homeInterior;
				return homeInterior != null && homeInterior.animals.ContainsKey(this.myID.Value);
			}
		}

		// Token: 0x060007A4 RID: 1956 RVA: 0x0004DA2C File Offset: 0x0004BC2C
		public FarmAnimal()
		{
		}

		// Token: 0x060007A5 RID: 1957 RVA: 0x0004DB98 File Offset: 0x0004BD98
		protected override void initNetFields()
		{
			this.bobOffset = Game1.random.Next(0, 1000);
			base.initNetFields();
			base.NetFields.AddField(this.currentProduce, "currentProduce").AddField(this.friendshipTowardFarmer, "friendshipTowardFarmer").AddField(this.age, "age").AddField(this.health, "health").AddField(this.produceQuality, "produceQuality").AddField(this.daysSinceLastLay, "daysSinceLastLay").AddField(this.happiness, "happiness").AddField(this.fullness, "fullness").AddField(this.wasPet, "wasPet").AddField(this.wasAutoPet, "wasAutoPet").AddField(this.allowReproduction, "allowReproduction").AddField(this.type, "type").AddField(this.buildingTypeILiveIn, "buildingTypeILiveIn").AddField(this.myID, "myID").AddField(this.ownerID, "ownerID").AddField(this.parentId, "parentId").AddField(this.netHomeInterior.NetFields, "netHomeInterior.NetFields").AddField(this.moodMessage, "moodMessage").AddField(this.isEating, "isEating").AddField(this.doFarmerPushEvent, "doFarmerPushEvent").AddField(this.doBuildingPokeEvent, "doBuildingPokeEvent").AddField(this.isSwimming, "isSwimming").AddField(this.doDiveEvent.NetFields, "doDiveEvent.NetFields").AddField(this.daysOwned, "daysOwned").AddField(this.skinID, "skinID").AddField(this.hasEatenAnimalCracker, "hasEatenAnimalCracker");
			this.position.Field.AxisAlignedMovement = true;
			this.doFarmerPushEvent.onEvent += this.doFarmerPush;
			this.doBuildingPokeEvent.onEvent += this.doBuildingPoke;
			this.doDiveEvent.onEvent += this.doDive;
			this.skinID.fieldChangeVisibleEvent += delegate(NetString a, string b, string c)
			{
				if (Game1.gameMode != 6)
				{
					this.ReloadTextureIfNeeded(false);
				}
			};
			this.isSwimming.fieldChangeVisibleEvent += delegate(NetBool a, bool b, bool c)
			{
				if (this.isSwimming.Value)
				{
					this.position.Field.AxisAlignedMovement = false;
					return;
				}
				this.position.Field.AxisAlignedMovement = true;
			};
			this.name.FilterStringEvent += Utility.FilterDirtyWords;
		}

		// Token: 0x060007A6 RID: 1958 RVA: 0x0004DE10 File Offset: 0x0004C010
		public FarmAnimal(string type, long id, long ownerID) : base(null, new Vector2((float)(64 * Game1.random.Next(2, 9)), (float)(64 * Game1.random.Next(4, 8))), 2, type)
		{
			this.ownerID.Value = ownerID;
			this.health.Value = 3;
			this.myID.Value = id;
			if (type == "Dairy Cow")
			{
				type = "Brown Cow";
			}
			this.type.Value = type;
			base.Name = Dialogue.randomName();
			this.displayName = this.name.Value;
			this.happiness.Value = 255;
			this.fullness.Value = 255;
			this._nextFollowTargetScan = Utility.RandomFloat(1f, 3f, null);
			this.ReloadTextureIfNeeded(true);
			FarmAnimalData data = this.GetAnimalData();
			if (data == null)
			{
				Game1.log.Warn("Constructed farm animal type '" + type + "' which has no entry in Data/FarmAnimals.");
			}
			this.buildingTypeILiveIn.Value = ((data != null) ? data.House : null);
			if (((data != null) ? data.Skins : null) != null)
			{
				Random random = Utility.CreateRandom((double)id, 0.0, 0.0, 0.0, 0.0);
				float totalWeight = 1f;
				foreach (FarmAnimalSkin skin in data.Skins)
				{
					totalWeight += skin.Weight;
				}
				totalWeight = Utility.RandomFloat(0f, totalWeight, random);
				foreach (FarmAnimalSkin skin2 in data.Skins)
				{
					totalWeight -= skin2.Weight;
					if (totalWeight <= 0f)
					{
						this.skinID.Value = skin2.Id;
						break;
					}
				}
			}
		}

		// Token: 0x060007A7 RID: 1959 RVA: 0x0004E178 File Offset: 0x0004C378
		public AnimatedSprite GetOrLoadTexture()
		{
			AnimatedSprite loaded = this.Sprite;
			if (loaded == null)
			{
				this.ReloadTextureIfNeeded(false);
				loaded = this.Sprite;
			}
			return loaded;
		}

		// Token: 0x060007A8 RID: 1960 RVA: 0x0004E1A0 File Offset: 0x0004C3A0
		public void ReloadTextureIfNeeded(bool forceReload = false)
		{
			if (this.Sprite == null || forceReload)
			{
				FarmAnimalData data = this.GetAnimalData();
				string texturePath;
				int spriteWidth;
				int spriteHeight;
				if (data != null)
				{
					texturePath = this.GetTexturePath(data);
					spriteWidth = data.SpriteWidth;
					spriteHeight = data.SpriteHeight;
				}
				else
				{
					texturePath = "Animals\\Error";
					spriteWidth = 16;
					spriteHeight = 16;
				}
				if (!Game1.content.DoesAssetExist<Texture2D>(texturePath))
				{
					IGameLogger log = Game1.log;
					DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(96, 2);
					defaultInterpolatedStringHandler.AppendLiteral("Farm animal '");
					defaultInterpolatedStringHandler.AppendFormatted(this.type.Value);
					defaultInterpolatedStringHandler.AppendLiteral("' failed to load texture path '");
					defaultInterpolatedStringHandler.AppendFormatted(texturePath);
					defaultInterpolatedStringHandler.AppendLiteral("': asset doesn't exist. Defaulting to error texture.");
					log.Warn(defaultInterpolatedStringHandler.ToStringAndClear());
					texturePath = "Animals\\Error";
					spriteWidth = 16;
					spriteHeight = 16;
				}
				this.Sprite = new AnimatedSprite(texturePath, 0, spriteWidth, spriteHeight)
				{
					textureUsesFlippedRightForLeft = (data != null && data.UseFlippedRightForLeft)
				};
				this.ValidateSpritesheetSize();
				return;
			}
			string texturePath2 = this.GetTexturePath();
			if (this.Sprite.textureName.Value != texturePath2)
			{
				this.Sprite.LoadTexture(texturePath2, true);
			}
		}

		// Token: 0x060007A9 RID: 1961 RVA: 0x0004E2B4 File Offset: 0x0004C4B4
		public string GetTexturePath()
		{
			return this.GetTexturePath(this.GetAnimalData());
		}

		// Token: 0x060007AA RID: 1962 RVA: 0x0004E2C4 File Offset: 0x0004C4C4
		public virtual string GetTexturePath(FarmAnimalData data)
		{
			string texturePath = "Animals\\" + this.type.Value;
			if (data != null)
			{
				FarmAnimalSkin skin = null;
				if (this.skinID.Value != null && data.Skins != null)
				{
					foreach (FarmAnimalSkin animalSkin in data.Skins)
					{
						if (this.skinID.Value == animalSkin.Id)
						{
							skin = animalSkin;
							break;
						}
					}
				}
				if (skin != null && skin.Texture != null)
				{
					texturePath = skin.Texture;
				}
				else if (data.Texture != null)
				{
					texturePath = data.Texture;
				}
				if (this.currentProduce.Value == null)
				{
					if (skin != null && skin.HarvestedTexture != null)
					{
						texturePath = skin.HarvestedTexture;
					}
					else if (data.HarvestedTexture != null)
					{
						texturePath = data.HarvestedTexture;
					}
				}
				if (this.isBaby())
				{
					if (skin != null && skin.BabyTexture != null)
					{
						texturePath = skin.BabyTexture;
					}
					else if (data.BabyTexture != null)
					{
						texturePath = data.BabyTexture;
					}
				}
			}
			return texturePath;
		}

		// Token: 0x060007AB RID: 1963 RVA: 0x0004E3E0 File Offset: 0x0004C5E0
		public static FarmAnimalData GetAnimalDataFromEgg(Item eggItem, GameLocation location)
		{
			string text;
			FarmAnimalData data;
			if (!FarmAnimal.TryGetAnimalDataFromEgg(eggItem, location, out text, out data))
			{
				return null;
			}
			return data;
		}

		// Token: 0x060007AC RID: 1964 RVA: 0x0004E400 File Offset: 0x0004C600
		public static bool TryGetAnimalDataFromEgg(Item eggItem, GameLocation location, out string id, out FarmAnimalData data)
		{
			if (!eggItem.HasTypeObject())
			{
				id = null;
				data = null;
				return false;
			}
			List<string> list;
			if (location == null)
			{
				list = null;
			}
			else
			{
				Building parentBuilding = location.ParentBuilding;
				if (parentBuilding == null)
				{
					list = null;
				}
				else
				{
					BuildingData data2 = parentBuilding.GetData();
					list = ((data2 != null) ? data2.ValidOccupantTypes : null);
				}
			}
			List<string> validOccupantTypes = list;
			foreach (KeyValuePair<string, FarmAnimalData> pair in Game1.farmAnimalData)
			{
				FarmAnimalData animalData = pair.Value;
				if (animalData.EggItemIds != null && animalData.EggItemIds.Count != 0 && (validOccupantTypes == null || validOccupantTypes.Contains(animalData.House)) && animalData.EggItemIds.Contains(eggItem.ItemId))
				{
					id = pair.Key;
					data = animalData;
					return true;
				}
			}
			id = null;
			data = null;
			return false;
		}

		// Token: 0x060007AD RID: 1965 RVA: 0x0004E4D8 File Offset: 0x0004C6D8
		public virtual FarmAnimalData GetAnimalData()
		{
			FarmAnimalData animalData;
			if (!Game1.farmAnimalData.TryGetValue(this.type.Value, out animalData))
			{
				return null;
			}
			return animalData;
		}

		// Token: 0x060007AE RID: 1966 RVA: 0x0004E504 File Offset: 0x0004C704
		public static string GetDisplayName(string id, bool forShop = false)
		{
			FarmAnimalData data;
			if (!Game1.farmAnimalData.TryGetValue(id, out data))
			{
				return null;
			}
			return TokenParser.ParseText(forShop ? (data.ShopDisplayName ?? data.DisplayName) : data.DisplayName, null, null, null);
		}

		// Token: 0x060007AF RID: 1967 RVA: 0x0004E548 File Offset: 0x0004C748
		public static string GetShopDescription(string id)
		{
			FarmAnimalData data;
			if (!Game1.farmAnimalData.TryGetValue(id, out data))
			{
				return null;
			}
			return TokenParser.ParseText(data.ShopDescription, null, null, null);
		}

		// Token: 0x060007B0 RID: 1968 RVA: 0x0004E574 File Offset: 0x0004C774
		public string shortDisplayType()
		{
			switch (LocalizedContentManager.CurrentLanguageCode)
			{
			case LocalizedContentManager.LanguageCode.en:
				return ArgUtility.SplitBySpace(this.displayType).Last<string>();
			case LocalizedContentManager.LanguageCode.ja:
				if (this.displayType.Contains("トリ"))
				{
					return "トリ";
				}
				if (this.displayType.Contains("ウシ"))
				{
					return "ウシ";
				}
				if (!this.displayType.Contains("ブタ"))
				{
					return this.displayType;
				}
				return "ブタ";
			case LocalizedContentManager.LanguageCode.ru:
				if (this.displayType.ContainsIgnoreCase("курица"))
				{
					return "Курица";
				}
				if (!this.displayType.ContainsIgnoreCase("корова"))
				{
					return this.displayType;
				}
				return "Корова";
			case LocalizedContentManager.LanguageCode.zh:
				if (this.displayType.Contains('鸡'))
				{
					return "鸡";
				}
				if (this.displayType.Contains('牛'))
				{
					return "牛";
				}
				if (!this.displayType.Contains('猪'))
				{
					return this.displayType;
				}
				return "猪";
			case LocalizedContentManager.LanguageCode.pt:
			case LocalizedContentManager.LanguageCode.es:
				return ArgUtility.SplitBySpaceAndGet(this.displayType, 0, null);
			case LocalizedContentManager.LanguageCode.de:
				return ArgUtility.SplitBySpace(this.displayType).Last<string>().Split('-', StringSplitOptions.None).Last<string>();
			default:
				return this.displayType;
			}
		}

		// Token: 0x060007B1 RID: 1969 RVA: 0x0004E6C8 File Offset: 0x0004C8C8
		public Microsoft.Xna.Framework.Rectangle GetHarvestBoundingBox()
		{
			Vector2 position = base.Position;
			return new Microsoft.Xna.Framework.Rectangle((int)(position.X + (float)(this.Sprite.getWidth() * 4 / 2) - 32f + 4f), (int)(position.Y + (float)(this.Sprite.getHeight() * 4) - 64f - 24f), 56, 72);
		}

		// Token: 0x060007B2 RID: 1970 RVA: 0x0004E72C File Offset: 0x0004C92C
		public Microsoft.Xna.Framework.Rectangle GetCursorPetBoundingBox()
		{
			Vector2 position = base.Position;
			FarmAnimalData animalData = this.GetAnimalData();
			if (animalData != null)
			{
				int width;
				int height;
				if (this.isBaby())
				{
					if (this.FacingDirection == 0 || this.FacingDirection == 2 || this.Sprite.currentFrame >= 12)
					{
						width = (int)(animalData.BabyUpDownPetHitboxTileSize.X * 64f);
						height = (int)(animalData.BabyUpDownPetHitboxTileSize.Y * 64f);
					}
					else
					{
						width = (int)(animalData.BabyLeftRightPetHitboxTileSize.X * 64f);
						height = (int)(animalData.BabyLeftRightPetHitboxTileSize.Y * 64f);
					}
				}
				else if (this.FacingDirection == 0 || this.FacingDirection == 2 || this.Sprite.currentFrame >= 12)
				{
					width = (int)(animalData.UpDownPetHitboxTileSize.X * 64f);
					height = (int)(animalData.UpDownPetHitboxTileSize.Y * 64f);
				}
				else
				{
					width = (int)(animalData.LeftRightPetHitboxTileSize.X * 64f);
					height = (int)(animalData.LeftRightPetHitboxTileSize.Y * 64f);
				}
				return new Microsoft.Xna.Framework.Rectangle((int)(base.Position.X + (float)(this.Sprite.getWidth() * 4 / 2) - (float)(width / 2)), (int)(base.Position.Y - 24f + (float)(this.Sprite.getHeight() * 4) - (float)height), width, height);
			}
			return new Microsoft.Xna.Framework.Rectangle((int)(position.X + (float)(this.Sprite.getWidth() * 4 / 2) - 32f + 4f), (int)(position.Y + (float)(this.Sprite.getHeight() * 4) - 64f - 24f), 56, 72);
		}

		// Token: 0x060007B3 RID: 1971 RVA: 0x0004E8D4 File Offset: 0x0004CAD4
		public override Microsoft.Xna.Framework.Rectangle GetBoundingBox()
		{
			Vector2 position = base.Position;
			return new Microsoft.Xna.Framework.Rectangle((int)(position.X + (float)(this.Sprite.getWidth() * 4 / 2) - 32f + 8f), (int)(position.Y + (float)(this.Sprite.getHeight() * 4) - 64f + 8f), 48, 48);
		}

		// Token: 0x060007B4 RID: 1972 RVA: 0x0004E937 File Offset: 0x0004CB37
		public void reload(GameLocation homeInterior)
		{
			this.homeInterior = homeInterior;
			this.ReloadTextureIfNeeded(false);
		}

		// Token: 0x060007B5 RID: 1973 RVA: 0x0004E947 File Offset: 0x0004CB47
		public void reload(Building home)
		{
			this.reload((home != null) ? home.GetIndoors() : null);
		}

		// Token: 0x060007B6 RID: 1974 RVA: 0x0004E95B File Offset: 0x0004CB5B
		public int GetDaysOwned()
		{
			if (this.daysOwned.Value < 0)
			{
				this.daysOwned.Value = this.age.Value;
			}
			return this.daysOwned.Value;
		}

		// Token: 0x060007B7 RID: 1975 RVA: 0x0004E98C File Offset: 0x0004CB8C
		public void pet(Farmer who, bool is_auto_pet = false)
		{
			if (!is_auto_pet)
			{
				if (who.FarmerSprite.PauseForSingleAnimation)
				{
					return;
				}
				who.Halt();
				who.faceGeneralDirection(base.Position, 0, false, false);
				if (Game1.timeOfDay >= 1900 && !this.isMoving())
				{
					Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\FarmAnimals:TryingToSleep", this.displayName));
					return;
				}
				this.Halt();
				this.Sprite.StopAnimation();
				this.uniqueFrameAccumulator = -1;
				switch (Game1.player.FacingDirection)
				{
				case 0:
					this.Sprite.currentFrame = 0;
					break;
				case 1:
					this.Sprite.currentFrame = 12;
					break;
				case 2:
					this.Sprite.currentFrame = 8;
					break;
				case 3:
					this.Sprite.currentFrame = 4;
					break;
				}
				if (!this.hasEatenAnimalCracker.Value)
				{
					Object activeObject = who.ActiveObject;
					if (((activeObject != null) ? activeObject.QualifiedItemId : null) == "(O)GoldenAnimalCracker")
					{
						FarmAnimalData animalData = this.GetAnimalData();
						if (!(((animalData != null) ? new bool?(animalData.CanEatGoldenCrackers) : null) ?? true))
						{
							Game1.playSound("cancel", null);
							base.doEmote(8, true);
							return;
						}
						this.hasEatenAnimalCracker.Value = true;
						Game1.playSound("give_gift", null);
						base.doEmote(56, true);
						Game1.player.reduceActiveItemByOne();
						return;
					}
				}
			}
			else if (this.wasAutoPet.Value)
			{
				return;
			}
			if (!this.wasPet.Value)
			{
				if (!is_auto_pet)
				{
					this.wasPet.Value = true;
				}
				int auto_pet_reduction = 7;
				if (this.wasAutoPet.Value)
				{
					this.friendshipTowardFarmer.Value = Math.Min(1000, this.friendshipTowardFarmer.Value + auto_pet_reduction);
				}
				else if (is_auto_pet)
				{
					this.friendshipTowardFarmer.Value = Math.Min(1000, this.friendshipTowardFarmer.Value + (15 - auto_pet_reduction));
				}
				else
				{
					this.friendshipTowardFarmer.Value = Math.Min(1000, this.friendshipTowardFarmer.Value + 15);
				}
				if (is_auto_pet)
				{
					this.wasAutoPet.Value = true;
				}
				FarmAnimalData data = this.GetAnimalData();
				int happinessDrain = (data != null) ? data.HappinessDrain : 0;
				if (!is_auto_pet)
				{
					if (data != null && data.ProfessionForHappinessBoost >= 0 && who.professions.Contains(data.ProfessionForHappinessBoost))
					{
						this.friendshipTowardFarmer.Value = Math.Min(1000, this.friendshipTowardFarmer.Value + 15);
						this.happiness.Value = (int)((byte)Math.Min(255, this.happiness.Value + Math.Max(5, 30 + happinessDrain)));
					}
					int emote_index = 20;
					if (this.wasAutoPet.Value)
					{
						emote_index = 32;
					}
					base.doEmote((this.moodMessage.Value == 4) ? 12 : emote_index, true);
				}
				this.happiness.Value = (int)((byte)Math.Min(255, this.happiness.Value + Math.Max(5, 30 + happinessDrain)));
				if (!is_auto_pet)
				{
					this.makeSound();
					who.gainExperience(0, 5);
					return;
				}
			}
			else if (!is_auto_pet)
			{
				Object activeObject2 = who.ActiveObject;
				if (((activeObject2 != null) ? activeObject2.QualifiedItemId : null) != "(O)178")
				{
					Game1.activeClickableMenu = new AnimalQueryMenu(this);
				}
			}
		}

		// Token: 0x060007B8 RID: 1976 RVA: 0x0004ED04 File Offset: 0x0004CF04
		public void farmerPushing()
		{
			this.pushAccumulator++;
			if (this.pushAccumulator > 60)
			{
				this.doFarmerPushEvent.Fire(Game1.player.FacingDirection);
				Microsoft.Xna.Framework.Rectangle bounds = this.GetBoundingBox();
				bounds = Utility.ExpandRectangle(bounds, Utility.GetOppositeFacingDirection(Game1.player.FacingDirection), 6);
				Game1.player.TemporaryPassableTiles.Add(bounds);
				this.pushAccumulator = 0;
			}
		}

		// Token: 0x060007B9 RID: 1977 RVA: 0x0004ED73 File Offset: 0x0004CF73
		public virtual void doDive()
		{
			this.yJumpVelocity = 8f;
			this.yJumpOffset = 1;
		}

		// Token: 0x060007BA RID: 1978 RVA: 0x0004ED87 File Offset: 0x0004CF87
		public void doFarmerPush(int direction)
		{
			if (!Game1.IsMasterGame)
			{
				return;
			}
			switch (direction)
			{
			case 0:
				this.Halt();
				return;
			case 1:
				this.Halt();
				return;
			case 2:
				this.Halt();
				return;
			case 3:
				this.Halt();
				return;
			default:
				return;
			}
		}

		// Token: 0x060007BB RID: 1979 RVA: 0x0004EDC3 File Offset: 0x0004CFC3
		public void Poke()
		{
			this.doBuildingPokeEvent.Fire();
		}

		// Token: 0x060007BC RID: 1980 RVA: 0x0004EDD0 File Offset: 0x0004CFD0
		public void doBuildingPoke()
		{
			if (Game1.IsMasterGame)
			{
				this.FacingDirection = Game1.random.Next(4);
				base.setMovingInFacingDirection();
			}
		}

		// Token: 0x060007BD RID: 1981 RVA: 0x0004EDF0 File Offset: 0x0004CFF0
		public void setRandomPosition(GameLocation location)
		{
			this.StopAllActions();
			Microsoft.Xna.Framework.Rectangle produceArea;
			if (!location.TryGetMapPropertyAs("ProduceArea", out produceArea, true))
			{
				return;
			}
			base.Position = new Vector2((float)(Game1.random.Next(produceArea.X, produceArea.Right) * 64), (float)(Game1.random.Next(produceArea.Y, produceArea.Bottom) * 64));
			int tries = 0;
			while (base.Position.Equals(Vector2.Zero) || location.Objects.ContainsKey(base.Position) || location.isCollidingPosition(this.GetBoundingBox(), Game1.viewport, false, 0, false, this))
			{
				base.Position = new Vector2((float)Game1.random.Next(produceArea.X, produceArea.Right), (float)Game1.random.Next(produceArea.Y, produceArea.Bottom)) * 64f;
				tries++;
				if (tries > 64)
				{
					break;
				}
			}
			this.SleepIfNecessary();
		}

		// Token: 0x060007BE RID: 1982 RVA: 0x0004EEF0 File Offset: 0x0004D0F0
		public virtual void StopAllActions()
		{
			this.foundGrass = null;
			this.controller = null;
			this.isSwimming.Value = false;
			this.hopOffset = Vector2.Zero;
			this._followTarget = null;
			this._followTargetPosition = null;
			this.Halt();
			this.Sprite.StopAnimation();
			this.Sprite.UpdateSourceRect();
		}

		// Token: 0x060007BF RID: 1983 RVA: 0x0004EF51 File Offset: 0x0004D151
		public virtual void HandleStatsOnProduceCollected(Item item, uint amount = 1U)
		{
			FarmAnimalData animalData = this.GetAnimalData();
			this.HandleStats((animalData != null) ? animalData.StatToIncrementOnProduce : null, item, amount);
		}

		// Token: 0x060007C0 RID: 1984 RVA: 0x0004EF70 File Offset: 0x0004D170
		public virtual void HandleStats(List<StatIncrement> stats, Item item, uint amount = 1U)
		{
			if (stats != null)
			{
				foreach (StatIncrement stat in stats)
				{
					if (stat.RequiredItemId == null || ItemRegistry.HasItemId(item, stat.RequiredItemId))
					{
						List<string> requiredTags = stat.RequiredTags;
						if (requiredTags == null || requiredTags.Count <= 0 || ItemContextTagManager.DoAllTagsMatch(stat.RequiredTags, item.GetContextTags()))
						{
							Game1.stats.Increment(stat.StatName, amount);
						}
					}
				}
			}
		}

		// Token: 0x060007C1 RID: 1985 RVA: 0x0004F00C File Offset: 0x0004D20C
		public string GetProduceID(Random r, bool deluxe = false)
		{
			FarmAnimalData data = this.GetAnimalData();
			if (data == null)
			{
				return null;
			}
			List<FarmAnimalProduce> produceList = new List<FarmAnimalProduce>();
			if (deluxe)
			{
				if (data.DeluxeProduceItemIds != null)
				{
					produceList.AddRange(data.DeluxeProduceItemIds);
				}
			}
			else if (data.ProduceItemIds != null)
			{
				produceList.AddRange(data.ProduceItemIds);
			}
			produceList.RemoveAll((FarmAnimalProduce produce) => (produce.MinimumFriendship > 0 && this.friendshipTowardFarmer.Value < produce.MinimumFriendship) || (produce.Condition != null && !GameStateQuery.CheckConditions(produce.Condition, this.currentLocation, null, null, null, r, null)));
			FarmAnimalProduce farmAnimalProduce = r.ChooseFrom(produceList);
			if (farmAnimalProduce == null)
			{
				return null;
			}
			return farmAnimalProduce.ItemId;
		}

		// Token: 0x060007C2 RID: 1986 RVA: 0x0004F098 File Offset: 0x0004D298
		public void dayUpdate(GameLocation environment)
		{
			if (this.daysOwned.Value < 0)
			{
				this.daysOwned.Value = this.age.Value;
			}
			FarmAnimalData data = this.GetAnimalData();
			FarmAnimalData animalData = this.GetAnimalData();
			int happinessDrain = (animalData != null) ? animalData.HappinessDrain : 0;
			int produceSpeedBonus = (data != null && data.FriendshipForFasterProduce >= 0 && this.friendshipTowardFarmer.Value >= data.FriendshipForFasterProduce) ? 1 : 0;
			this.StopAllActions();
			this.health.Value = 3;
			bool wasLeftOutLastNight = false;
			GameLocation insideHome = this.homeInterior;
			if (insideHome != null && !this.IsHome)
			{
				if (this.home.animalDoorOpen.Value)
				{
					environment.animals.Remove(this.myID.Value);
					insideHome.animals.TryAdd(this.myID.Value, this);
					if (Game1.timeOfDay > 1800 && this.controller == null)
					{
						this.happiness.Value /= 2;
					}
					this.setRandomPosition(insideHome);
					return;
				}
				this.moodMessage.Value = 6;
				wasLeftOutLastNight = true;
				this.happiness.Value /= 2;
			}
			else if (insideHome != null && this.IsHome && !this.home.animalDoorOpen.Value)
			{
				this.happiness.Value = (int)((byte)Math.Min(255, this.happiness.Value + happinessDrain * 2));
			}
			NetInt netInt = this.daysSinceLastLay;
			int i = netInt.Value;
			netInt.Value = i + 1;
			if (!this.wasPet.Value && !this.wasAutoPet.Value)
			{
				this.friendshipTowardFarmer.Value = Math.Max(0, this.friendshipTowardFarmer.Value - (10 - this.friendshipTowardFarmer.Value / 200));
				this.happiness.Value = (int)((byte)Math.Max(0, this.happiness.Value - 50));
			}
			this.wasPet.Value = false;
			this.wasAutoPet.Value = false;
			NetInt netInt2 = this.daysOwned;
			i = netInt2.Value;
			netInt2.Value = i + 1;
			if (this.fullness.Value < 200 && environment is AnimalHouse)
			{
				foreach (KeyValuePair<Vector2, Object> pair in environment.objects.Pairs.ToArray<KeyValuePair<Vector2, Object>>())
				{
					if (pair.Value.QualifiedItemId == "(O)178")
					{
						environment.objects.Remove(pair.Key);
						this.fullness.Value = 255;
						break;
					}
				}
			}
			Random r = Utility.CreateRandom((double)this.myID.Value / 2.0, Game1.stats.DaysPlayed, 0.0, 0.0, 0.0);
			int? num;
			if (this.fullness.Value > 200 || r.NextDouble() < (double)(this.fullness.Value - 30) / 170.0)
			{
				int value = this.age.Value;
				num = ((data != null) ? new int?(data.DaysToMature - 1) : null);
				if (value == num.GetValueOrDefault() & num != null)
				{
					this.growFully(r);
				}
				else
				{
					NetInt netInt3 = this.age;
					i = netInt3.Value;
					netInt3.Value = i + 1;
				}
				this.happiness.Value = (int)((byte)Math.Min(255, this.happiness.Value + happinessDrain * 2));
			}
			if (this.fullness.Value < 200)
			{
				this.happiness.Value = (int)((byte)Math.Max(0, this.happiness.Value - 100));
				this.friendshipTowardFarmer.Value = Math.Max(0, this.friendshipTowardFarmer.Value - 20);
			}
			Farmer owner = Game1.GetPlayer(this.ownerID.Value, false) ?? Game1.MasterPlayer;
			if (data != null && data.ProfessionForFasterProduce >= 0 && owner.professions.Contains(data.ProfessionForFasterProduce))
			{
				produceSpeedBonus++;
			}
			int value2 = this.daysSinceLastLay.Value;
			num = ((data != null) ? new int?(data.DaysToProduce - produceSpeedBonus) : null);
			bool produceToday = (value2 >= num.GetValueOrDefault() & num != null) && r.NextDouble() < (double)this.fullness.Value / 200.0 && r.NextDouble() < (double)this.happiness.Value / 70.0;
			string whichProduce;
			if (!produceToday || this.isBaby())
			{
				whichProduce = null;
			}
			else
			{
				whichProduce = this.GetProduceID(r, false);
				if (r.NextDouble() < (double)this.happiness.Value / 150.0)
				{
					float happinessModifier = (this.happiness.Value > 200) ? ((float)this.happiness.Value * 1.5f) : ((float)((this.happiness.Value <= 100) ? (this.happiness.Value - 100) : 0));
					string deluxeProduce = this.GetProduceID(r, true);
					if (data != null && data.DeluxeProduceCareDivisor >= 0f && deluxeProduce != null && this.friendshipTowardFarmer.Value >= data.DeluxeProduceMinimumFriendship && r.NextDouble() < (double)(((float)this.friendshipTowardFarmer.Value + happinessModifier) / data.DeluxeProduceCareDivisor) + Game1.player.team.AverageDailyLuck(null) * (double)data.DeluxeProduceLuckMultiplier)
					{
						whichProduce = deluxeProduce;
					}
					this.daysSinceLastLay.Value = 0;
					double chanceForQuality = (double)((float)this.friendshipTowardFarmer.Value / 1000f - (1f - (float)this.happiness.Value / 225f));
					if (data != null && data.ProfessionForQualityBoost >= 0 && owner.professions.Contains(data.ProfessionForQualityBoost))
					{
						chanceForQuality += 0.33;
					}
					if (chanceForQuality >= 0.95 && r.NextDouble() < chanceForQuality / 2.0)
					{
						this.produceQuality.Value = 4;
					}
					else if (r.NextDouble() < chanceForQuality / 2.0)
					{
						this.produceQuality.Value = 2;
					}
					else if (r.NextDouble() < chanceForQuality)
					{
						this.produceQuality.Value = 1;
					}
					else
					{
						this.produceQuality.Value = 0;
					}
				}
			}
			if ((data == null || data.HarvestType > FarmAnimalHarvestType.DropOvernight) && produceToday)
			{
				this.currentProduce.Value = whichProduce;
				whichProduce = null;
			}
			if (whichProduce != null && this.home != null)
			{
				bool spawn_object = true;
				Object producedObject = ItemRegistry.Create<Object>("(O)" + whichProduce, 1, 0, false);
				producedObject.CanBeSetDown = false;
				producedObject.Quality = this.produceQuality.Value;
				if (this.hasEatenAnimalCracker.Value)
				{
					producedObject.Stack = 2;
				}
				this.HandleStats((data != null) ? data.StatToIncrementOnProduce : null, producedObject, (uint)producedObject.Stack);
				foreach (Object location_object in insideHome.objects.Values)
				{
					if (location_object.QualifiedItemId == "(BC)165")
					{
						Chest chest = location_object.heldObject.Value as Chest;
						if (chest != null && chest.addItem(producedObject) == null)
						{
							location_object.showNextIndex.Value = true;
							spawn_object = false;
							break;
						}
					}
				}
				if (spawn_object)
				{
					producedObject.Stack = 1;
					Utility.spawnObjectAround(base.Tile, producedObject, environment, true, null);
					if (this.hasEatenAnimalCracker.Value)
					{
						Object o = (Object)producedObject.getOne();
						Utility.spawnObjectAround(base.Tile, o, environment, true, null);
					}
				}
			}
			if (!wasLeftOutLastNight)
			{
				if (this.fullness.Value < 30)
				{
					this.moodMessage.Value = 4;
				}
				else if (this.happiness.Value < 30)
				{
					this.moodMessage.Value = 3;
				}
				else if (this.happiness.Value < 200)
				{
					this.moodMessage.Value = 2;
				}
				else
				{
					this.moodMessage.Value = 1;
				}
			}
			this.fullness.Value = 0;
			if (Utility.isFestivalDay())
			{
				this.fullness.Value = 250;
			}
			this.reload(this.homeInterior);
		}

		// Token: 0x060007C3 RID: 1987 RVA: 0x0004F93C File Offset: 0x0004DB3C
		public void OnDayStarted()
		{
			FarmAnimalData animalData = this.GetAnimalData();
			if (animalData != null && animalData.GrassEatAmount < 1)
			{
				this.fullness.Value = 255;
			}
		}

		// Token: 0x060007C4 RID: 1988 RVA: 0x0004F968 File Offset: 0x0004DB68
		public int getSellPrice()
		{
			FarmAnimalData animalData = this.GetAnimalData();
			double num = (double)((animalData != null) ? animalData.SellPrice : 0);
			double adjustedFriendship = (double)this.friendshipTowardFarmer.Value / 1000.0 + 0.3;
			return (int)(num * adjustedFriendship);
		}

		// Token: 0x060007C5 RID: 1989 RVA: 0x0004F9AC File Offset: 0x0004DBAC
		public bool isMale()
		{
			FarmAnimalData animalData = this.GetAnimalData();
			FarmAnimalGender? farmAnimalGender = (animalData != null) ? new FarmAnimalGender?(animalData.Gender) : null;
			if (farmAnimalGender != null)
			{
				FarmAnimalGender valueOrDefault = farmAnimalGender.GetValueOrDefault();
				if (valueOrDefault == FarmAnimalGender.Female)
				{
					return false;
				}
				if (valueOrDefault == FarmAnimalGender.Male)
				{
					return true;
				}
			}
			return this.myID.Value % 2L == 0L;
		}

		// Token: 0x060007C6 RID: 1990 RVA: 0x0004FA0C File Offset: 0x0004DC0C
		public string getMoodMessage()
		{
			string gender = this.isMale() ? "Male" : "Female";
			switch (this.moodMessage.Value)
			{
			case 0:
				if (this.parentId.Value != -1L)
				{
					return Game1.content.LoadString("Strings\\FarmAnimals:MoodMessage_NewHome_Baby_" + gender, this.displayName);
				}
				return Game1.content.LoadString("Strings\\FarmAnimals:MoodMessage_NewHome_Adult_" + gender + "_" + (Game1.dayOfMonth % 2 + 1).ToString(), this.displayName);
			case 4:
				return Game1.content.LoadString("Strings\\FarmAnimals:MoodMessage_" + ((((long)Game1.dayOfMonth + this.myID.Value) % 2L == 0L) ? "Hungry1" : "Hungry2"), this.displayName);
			case 5:
				return Game1.content.LoadString("Strings\\FarmAnimals:MoodMessage_DisturbedByDog_" + gender, this.displayName);
			case 6:
				return Game1.content.LoadString("Strings\\FarmAnimals:MoodMessage_LeftOutsideAtNight_" + gender, this.displayName);
			}
			if (this.happiness.Value < 30)
			{
				this.moodMessage.Value = 3;
			}
			else if (this.happiness.Value < 200)
			{
				this.moodMessage.Value = 2;
			}
			else
			{
				this.moodMessage.Value = 1;
			}
			switch (this.moodMessage.Value)
			{
			case 1:
				return Game1.content.LoadString("Strings\\FarmAnimals:MoodMessage_Happy", this.displayName);
			case 2:
				return Game1.content.LoadString("Strings\\FarmAnimals:MoodMessage_Fine", this.displayName);
			case 3:
				return Game1.content.LoadString("Strings\\FarmAnimals:MoodMessage_Sad", this.displayName);
			default:
				return "";
			}
		}

		// Token: 0x060007C7 RID: 1991 RVA: 0x0004FBE8 File Offset: 0x0004DDE8
		public bool isAdult()
		{
			FarmAnimalData animalData = this.GetAnimalData();
			int? adultAge = (animalData != null) ? new int?(animalData.DaysToMature) : null;
			if (adultAge != null)
			{
				int value = this.age.Value;
				int? num = adultAge;
				return value >= num.GetValueOrDefault() & num != null;
			}
			return true;
		}

		// Token: 0x060007C8 RID: 1992 RVA: 0x0004FC44 File Offset: 0x0004DE44
		public bool isBaby()
		{
			int value = this.age.Value;
			FarmAnimalData animalData = this.GetAnimalData();
			int? num = (animalData != null) ? new int?(animalData.DaysToMature) : null;
			return value < num.GetValueOrDefault() & num != null;
		}

		// Token: 0x060007C9 RID: 1993 RVA: 0x0004FC8D File Offset: 0x0004DE8D
		public bool CanGetProduceWithTool(Tool tool)
		{
			return tool != null && tool.Name != null && this.GetAnimalData().HarvestTool == tool.Name;
		}

		// Token: 0x060007CA RID: 1994 RVA: 0x0004FCB4 File Offset: 0x0004DEB4
		public FarmAnimalHarvestType? GetHarvestType()
		{
			FarmAnimalData animalData = this.GetAnimalData();
			if (animalData == null)
			{
				return null;
			}
			return new FarmAnimalHarvestType?(animalData.HarvestType);
		}

		// Token: 0x060007CB RID: 1995 RVA: 0x0004FCE0 File Offset: 0x0004DEE0
		public bool CanLiveIn(Building building)
		{
			BuildingData buildingData = (building != null) ? building.GetData() : null;
			return ((buildingData != null) ? buildingData.ValidOccupantTypes : null) != null && buildingData.ValidOccupantTypes.Contains(this.buildingTypeILiveIn.Value) && !building.isUnderConstruction(true) && building.GetIndoors() is AnimalHouse;
		}

		// Token: 0x060007CC RID: 1996 RVA: 0x0004FD3C File Offset: 0x0004DF3C
		public void warpHome()
		{
			GameLocation insideHome = this.homeInterior;
			if (insideHome != null && insideHome != base.currentLocation)
			{
				if (insideHome.animals.TryAdd(this.myID.Value, this))
				{
					this.setRandomPosition(insideHome);
					NetInt currentOccupants = this.home.currentOccupants;
					int value = currentOccupants.Value;
					currentOccupants.Value = value + 1;
				}
				GameLocation currentLocation = base.currentLocation;
				if (currentLocation != null)
				{
					currentLocation.animals.Remove(this.myID.Value);
				}
				this.controller = null;
				this.isSwimming.Value = false;
				this.hopOffset = Vector2.Zero;
				this._followTarget = null;
				this._followTargetPosition = null;
			}
		}

		// Token: 0x060007CD RID: 1997 RVA: 0x0004FDF0 File Offset: 0x0004DFF0
		public void growFully(Random random = null)
		{
			FarmAnimalData data = this.GetAnimalData();
			int value = this.age.Value;
			int? num = (data != null) ? new int?(data.DaysToMature) : null;
			if (value <= num.GetValueOrDefault() & num != null)
			{
				this.age.Value = data.DaysToMature;
				if (data.ProduceOnMature)
				{
					this.currentProduce.Value = this.GetProduceID(random ?? Game1.random, false);
				}
				this.daysSinceLastLay.Value = 99;
				this.ReloadTextureIfNeeded(false);
			}
		}

		// Token: 0x060007CE RID: 1998 RVA: 0x0004FE88 File Offset: 0x0004E088
		public override void draw(SpriteBatch b)
		{
			Vector2 offset = new Vector2(0f, (float)this.yJumpOffset);
			Microsoft.Xna.Framework.Rectangle boundingBox = this.GetBoundingBox();
			FarmAnimalData data = this.GetAnimalData();
			bool isActuallySwimming = this.IsActuallySwimming();
			bool baby = this.isBaby();
			FarmAnimalShadowData shadow = (data != null) ? data.GetShadow(baby, isActuallySwimming) : null;
			if (shadow == null || shadow.Visible)
			{
				int? num;
				if (shadow == null)
				{
					num = null;
				}
				else
				{
					FarmAnimalShadowData farmAnimalShadowData = shadow;
					num = ((farmAnimalShadowData.Offset != null) ? new int?(farmAnimalShadowData.Offset.GetValueOrDefault().X) : null);
				}
				int? num2 = num;
				int shadowOffsetX = num2.GetValueOrDefault();
				int? num3;
				if (shadow == null)
				{
					num3 = null;
				}
				else
				{
					FarmAnimalShadowData farmAnimalShadowData2 = shadow;
					num3 = ((farmAnimalShadowData2.Offset != null) ? new int?(farmAnimalShadowData2.Offset.GetValueOrDefault().Y) : null);
				}
				num2 = num3;
				int shadowOffsetY = num2.GetValueOrDefault();
				if (isActuallySwimming)
				{
					float shadowScale = ((shadow != null) ? shadow.Scale : null) ?? (baby ? 2.5f : 3.5f);
					Vector2 shadowPos = new Vector2(base.Position.X + (float)shadowOffsetX, base.Position.Y - 24f + (float)shadowOffsetY);
					this.Sprite.drawShadow(b, Game1.GlobalToLocal(Game1.viewport, shadowPos), shadowScale, 0.5f);
					int bobAmount = (int)((Math.Sin(Game1.currentGameTime.TotalGameTime.TotalSeconds * 4.0 + (double)this.bobOffset) + 0.5) * 3.0);
					offset.Y += (float)bobAmount;
				}
				else
				{
					float shadowScale2 = ((shadow != null) ? shadow.Scale : null) ?? (baby ? 3f : 4f);
					Vector2 shadowPos2 = new Vector2(base.Position.X + (float)shadowOffsetX, base.Position.Y - 24f + (float)shadowOffsetY);
					this.Sprite.drawShadow(b, Game1.GlobalToLocal(Game1.viewport, shadowPos2), shadowScale2);
				}
			}
			offset.Y += (float)this.yJumpOffset;
			float layer_depth = ((float)(boundingBox.Center.Y + 4) + base.Position.X / 20000f) / 10000f;
			this.Sprite.draw(b, Utility.snapDrawPosition(Game1.GlobalToLocal(Game1.viewport, base.Position - new Vector2(0f, 24f) + offset)), layer_depth, 0, 0, (this.hitGlowTimer > 0) ? Color.Red : Color.White, this.FacingDirection == 3, 4f, 0f, false);
			if (this.isEmoting)
			{
				int emoteOffsetX = this.Sprite.SpriteWidth / 2 * 4 - 32 + ((data != null) ? data.EmoteOffset.X : 0);
				int emoteOffsetY = -64 + ((data != null) ? data.EmoteOffset.Y : 0);
				Vector2 emotePosition = Game1.GlobalToLocal(Game1.viewport, new Vector2(base.Position.X + offset.X + (float)emoteOffsetX, base.Position.Y + offset.Y + (float)emoteOffsetY));
				b.Draw(Game1.emoteSpriteSheet, emotePosition, new Microsoft.Xna.Framework.Rectangle?(new Microsoft.Xna.Framework.Rectangle(base.CurrentEmoteIndex * 16 % Game1.emoteSpriteSheet.Width, base.CurrentEmoteIndex * 16 / Game1.emoteSpriteSheet.Width * 16, 16, 16)), Color.White, 0f, Vector2.Zero, 4f, SpriteEffects.None, (float)boundingBox.Bottom / 10000f);
			}
		}

		// Token: 0x060007CF RID: 1999 RVA: 0x00050268 File Offset: 0x0004E468
		public virtual void updateWhenNotCurrentLocation(Building currentBuilding, GameTime time, GameLocation environment)
		{
			this.doFarmerPushEvent.Poll();
			this.doBuildingPokeEvent.Poll();
			this.doDiveEvent.Poll();
			AnimatedSprite sprite = this.GetOrLoadTexture();
			if (!Game1.shouldTimePass(false))
			{
				return;
			}
			this.update(time, environment, this.myID.Value, false);
			if (Game1.IsMasterGame)
			{
				if (this.hopOffset != Vector2.Zero)
				{
					this.HandleHop();
					return;
				}
				if (currentBuilding != null && Game1.random.NextBool(0.002) && currentBuilding.animalDoorOpen.Value && Game1.timeOfDay < 1630 && !environment.IsRainingHere() && !environment.IsWinterHere() && !environment.farmers.Any())
				{
					GameLocation buildingLocation = currentBuilding.GetParentLocation();
					Microsoft.Xna.Framework.Rectangle doorArea = currentBuilding.getRectForAnimalDoor();
					doorArea.Inflate(-2, -2);
					if (buildingLocation.isCollidingPosition(doorArea, Game1.viewport, false, 0, false, this, false, false, false, false) || buildingLocation.isCollidingPosition(new Microsoft.Xna.Framework.Rectangle(doorArea.X, doorArea.Y + 64, doorArea.Width, doorArea.Height), Game1.viewport, false, 0, false, this, false, false, false, false))
					{
						return;
					}
					buildingLocation.animals.Remove(this.myID.Value);
					currentBuilding.GetIndoors().animals.Remove(this.myID.Value);
					buildingLocation.animals.TryAdd(this.myID.Value, this);
					this.faceDirection(2);
					this.SetMovingDown(true);
					base.Position = new Vector2((float)doorArea.X, (float)(doorArea.Y - (sprite.getHeight() * 4 - this.GetBoundingBox().Height) + 32));
					if (FarmAnimal.NumPathfindingThisTick < FarmAnimal.MaxPathfindingPerTick)
					{
						FarmAnimal.NumPathfindingThisTick++;
						this.controller = new PathFindController(this, buildingLocation, new PathFindController.isAtEnd(FarmAnimal.grassEndPointFunction), Game1.random.Next(4), new PathFindController.endBehavior(FarmAnimal.behaviorAfterFindingGrassPatch), 200, Point.Zero, true);
					}
					PathFindController controller = this.controller;
					if (((controller != null) ? controller.pathToEndPoint : null) == null || this.controller.pathToEndPoint.Count < 3)
					{
						this.SetMovingDown(true);
						this.controller = null;
					}
					else
					{
						this.faceDirection(2);
						base.Position = new Vector2((float)(this.controller.pathToEndPoint.Peek().X * 64), (float)(this.controller.pathToEndPoint.Peek().Y * 64 - (sprite.getHeight() * 4 - this.GetBoundingBox().Height) + 16));
						if (sprite.SpriteWidth * 4 > 64)
						{
							this.position.X -= 32f;
						}
					}
					this.noWarpTimer = 3000;
					NetInt currentOccupants = currentBuilding.currentOccupants;
					int value = currentOccupants.Value;
					currentOccupants.Value = value - 1;
					if (Utility.isOnScreen(base.TilePoint, 192, buildingLocation))
					{
						buildingLocation.localSound("sandyStep", null, null, SoundContext.Default);
					}
					Farmer farmer = environment.isTileOccupiedByFarmer(base.Tile);
					if (farmer != null)
					{
						farmer.TemporaryPassableTiles.Add(this.GetBoundingBox());
					}
				}
				this.UpdateRandomMovements();
				this.behaviors(time, environment);
			}
		}

		// Token: 0x060007D0 RID: 2000 RVA: 0x000505BC File Offset: 0x0004E7BC
		public static void behaviorAfterFindingGrassPatch(Character c, GameLocation environment)
		{
			TerrainFeature feature;
			if (environment.terrainFeatures.TryGetValue(c.Tile, out feature))
			{
				Grass grass = feature as Grass;
				if (grass != null)
				{
					FarmAnimal.reservedGrass.Remove(grass);
				}
			}
			if (((FarmAnimal)c).fullness.Value < 255)
			{
				((FarmAnimal)c).eatGrass(environment);
			}
		}

		// Token: 0x060007D1 RID: 2001 RVA: 0x00050618 File Offset: 0x0004E818
		public static bool grassEndPointFunction(PathNode currentPoint, Point endPoint, GameLocation location, Character c)
		{
			Vector2 tileLocation = new Vector2((float)currentPoint.x, (float)currentPoint.y);
			TerrainFeature t;
			if (location.terrainFeatures.TryGetValue(tileLocation, out t))
			{
				Grass grass = t as Grass;
				if (grass != null)
				{
					if (FarmAnimal.reservedGrass.Contains(t))
					{
						return false;
					}
					FarmAnimal.reservedGrass.Add(grass);
					FarmAnimal animal = c as FarmAnimal;
					if (animal != null)
					{
						animal.foundGrass = grass;
					}
					return true;
				}
			}
			return false;
		}

		// Token: 0x060007D2 RID: 2002 RVA: 0x00050684 File Offset: 0x0004E884
		public virtual void updatePerTenMinutes(int timeOfDay, GameLocation environment)
		{
			if (timeOfDay >= 1800)
			{
				FarmAnimalData animalData = this.GetAnimalData();
				int happinessDrain = (animalData != null) ? animalData.HappinessDrain : 0;
				int change = 0;
				if (environment.IsOutdoors)
				{
					change = ((timeOfDay > 1900 || environment.IsRainingHere() || environment.IsWinterHere()) ? (-happinessDrain) : happinessDrain);
				}
				else if (this.happiness.Value > 150 && environment.IsWinterHere())
				{
					change = ((environment.numberOfObjectsWithName("Heater") > 0) ? happinessDrain : (-happinessDrain));
				}
				if (change != 0)
				{
					this.happiness.Value = (int)((byte)MathHelper.Clamp(this.happiness.Value + change, 0, 255));
				}
			}
			Farmer farmer = environment.isTileOccupiedByFarmer(base.Tile);
			if (farmer == null)
			{
				return;
			}
			farmer.TemporaryPassableTiles.Add(this.GetBoundingBox());
		}

		// Token: 0x060007D3 RID: 2003 RVA: 0x00050750 File Offset: 0x0004E950
		public void eatGrass(GameLocation environment)
		{
			TerrainFeature feature;
			if (environment.terrainFeatures.TryGetValue(base.Tile, out feature))
			{
				Grass grass = feature as Grass;
				if (grass != null)
				{
					FarmAnimal.reservedGrass.Remove(grass);
					if (this.foundGrass != null)
					{
						FarmAnimal.reservedGrass.Remove(this.foundGrass);
					}
					this.foundGrass = null;
					this.Eat(environment);
				}
			}
		}

		// Token: 0x060007D4 RID: 2004 RVA: 0x000507B0 File Offset: 0x0004E9B0
		public virtual void Eat(GameLocation location)
		{
			Vector2 tile = base.Tile;
			this.isEating.Value = true;
			int grassType = 1;
			TerrainFeature terrainFeature;
			if (location.terrainFeatures.TryGetValue(tile, out terrainFeature))
			{
				Grass grass = terrainFeature as Grass;
				if (grass != null)
				{
					grassType = (int)grass.grassType.Value;
					FarmAnimalData animalData = this.GetAnimalData();
					int grassEatAmount = (animalData != null) ? animalData.GrassEatAmount : 2;
					if (grass.reduceBy(grassEatAmount, location.Equals(Game1.currentLocation)))
					{
						location.terrainFeatures.Remove(tile);
					}
				}
			}
			this.Sprite.loop = false;
			this.fullness.Value = 255;
			if (this.moodMessage.Value != 5 && this.moodMessage.Value != 6 && !location.IsRainingHere())
			{
				this.happiness.Value = 255;
				this.friendshipTowardFarmer.Value = Math.Min(1000, this.friendshipTowardFarmer.Value + ((grassType == 7) ? 16 : 8));
			}
		}

		// Token: 0x060007D5 RID: 2005 RVA: 0x000508A8 File Offset: 0x0004EAA8
		public virtual bool behaviors(GameTime time, GameLocation location)
		{
			if (!Game1.IsMasterGame)
			{
				return false;
			}
			Building home = this.home;
			if (home == null)
			{
				return false;
			}
			if (this.isBaby() && this.CanFollowAdult())
			{
				this._nextFollowTargetScan -= (float)time.ElapsedGameTime.TotalSeconds;
				if (this._nextFollowTargetScan < 0f)
				{
					this._nextFollowTargetScan = Utility.RandomFloat(1f, 3f, null);
					if (this.controller == null && location.IsOutdoors)
					{
						if (this._followTarget == null)
						{
							if (!location.IsOutdoors)
							{
								goto IL_187;
							}
							using (NetDictionary<long, FarmAnimal, NetRef<FarmAnimal>, SerializableDictionary<long, FarmAnimal>, NetLongDictionary<FarmAnimal, NetRef<FarmAnimal>>>.ValuesCollection.Enumerator enumerator = location.animals.Values.GetEnumerator())
							{
								while (enumerator.MoveNext())
								{
									FarmAnimal animal = enumerator.Current;
									if (!animal.isBaby() && animal.type.Value == this.type.Value && FarmAnimal.GetFollowRange(animal, 4).Contains(base.StandingPixel))
									{
										this._followTarget = animal;
										this.GetNewFollowPosition();
										return false;
									}
								}
								goto IL_187;
							}
						}
						if (!FarmAnimal.GetFollowRange(this._followTarget, 2).Contains(this._followTargetPosition.Value))
						{
							this.GetNewFollowPosition();
						}
						return false;
					}
					this._followTarget = null;
					this._followTargetPosition = null;
				}
			}
			IL_187:
			if (this.isEating.Value)
			{
				if (home != null && home.getRectForAnimalDoor().Intersects(this.GetBoundingBox()))
				{
					FarmAnimal.behaviorAfterFindingGrassPatch(this, location);
					this.isEating.Value = false;
					this.Halt();
					return false;
				}
				FarmAnimalData animalData = this.GetAnimalData();
				int eatFrame = 16;
				if (!this.Sprite.textureUsesFlippedRightForLeft)
				{
					eatFrame += 4;
				}
				bool? flag = (animalData != null) ? new bool?(animalData.UseDoubleUniqueAnimationFrames) : null;
				if (flag != null && flag.GetValueOrDefault())
				{
					eatFrame += 4;
				}
				if (this.Sprite.Animate(time, eatFrame, 4, 100f))
				{
					this.isEating.Value = false;
					this.Sprite.loop = true;
					this.Sprite.currentFrame = 0;
					this.faceDirection(2);
				}
				return true;
			}
			else
			{
				if (this.controller != null)
				{
					return true;
				}
				if (!this.isSwimming.Value && location.IsOutdoors && this.fullness.Value < 195 && Game1.random.NextDouble() < 0.002 && FarmAnimal.NumPathfindingThisTick < FarmAnimal.MaxPathfindingPerTick)
				{
					FarmAnimal.NumPathfindingThisTick++;
					this.controller = new PathFindController(this, location, new PathFindController.isAtEnd(FarmAnimal.grassEndPointFunction), -1, new PathFindController.endBehavior(FarmAnimal.behaviorAfterFindingGrassPatch), 200, Point.Zero, true);
					this._followTarget = null;
					this._followTargetPosition = null;
				}
				if (Game1.timeOfDay >= 1700 && location.IsOutdoors && this.controller == null && Game1.random.NextDouble() < 0.002 && home.animalDoorOpen.Value)
				{
					if (!location.farmers.Any())
					{
						GameLocation insideHome = home.GetIndoors();
						location.animals.Remove(this.myID.Value);
						insideHome.animals.TryAdd(this.myID.Value, this);
						this.setRandomPosition(insideHome);
						this.faceDirection(Game1.random.Next(4));
						this.controller = null;
						return true;
					}
					if (FarmAnimal.NumPathfindingThisTick < FarmAnimal.MaxPathfindingPerTick)
					{
						FarmAnimal.NumPathfindingThisTick++;
						this.controller = new PathFindController(this, location, new PathFindController.isAtEnd(PathFindController.isAtEndPoint), 0, null, 200, new Point(home.tileX.Value + home.animalDoor.X, home.tileY.Value + home.animalDoor.Y), true);
						this._followTarget = null;
						this._followTargetPosition = null;
					}
				}
				if (location.IsOutdoors && !location.IsRainingHere() && !location.IsWinterHere() && this.currentProduce.Value != null && this.isAdult() && this.GetHarvestType().GetValueOrDefault() == FarmAnimalHarvestType.DigUp && Game1.random.NextDouble() < 0.0002)
				{
					Object produce = ItemRegistry.Create<Object>(this.currentProduce.Value, 1, 0, false);
					Microsoft.Xna.Framework.Rectangle rect = this.GetBoundingBox();
					for (int i = 0; i < 4; i++)
					{
						Vector2 v = Utility.getCornersOfThisRectangle(ref rect, i);
						Vector2 vec = new Vector2((float)((int)(v.X / 64f)), (float)((int)(v.Y / 64f)));
						if (location.terrainFeatures.ContainsKey(vec) || location.objects.ContainsKey(vec))
						{
							return false;
						}
					}
					if (Game1.player.currentLocation.Equals(location))
					{
						DelayedAction.playSoundAfterDelay("dirtyHit", 450, null, null, -1, false);
						DelayedAction.playSoundAfterDelay("dirtyHit", 900, null, null, -1, false);
						DelayedAction.playSoundAfterDelay("dirtyHit", 1350, null, null, -1, false);
					}
					if (location.Equals(Game1.currentLocation))
					{
						switch (this.FacingDirection)
						{
						case 0:
							this.Sprite.setCurrentAnimation(new List<FarmerSprite.AnimationFrame>
							{
								new FarmerSprite.AnimationFrame(9, 250),
								new FarmerSprite.AnimationFrame(11, 250),
								new FarmerSprite.AnimationFrame(9, 250),
								new FarmerSprite.AnimationFrame(11, 250),
								new FarmerSprite.AnimationFrame(9, 250),
								new FarmerSprite.AnimationFrame(11, 250, false, false, delegate(Farmer _)
								{
									this.DigUpProduce(location, produce);
								}, false)
							});
							break;
						case 1:
							this.Sprite.setCurrentAnimation(new List<FarmerSprite.AnimationFrame>
							{
								new FarmerSprite.AnimationFrame(5, 250),
								new FarmerSprite.AnimationFrame(7, 250),
								new FarmerSprite.AnimationFrame(5, 250),
								new FarmerSprite.AnimationFrame(7, 250),
								new FarmerSprite.AnimationFrame(5, 250),
								new FarmerSprite.AnimationFrame(7, 250, false, false, delegate(Farmer _)
								{
									this.DigUpProduce(location, produce);
								}, false)
							});
							break;
						case 2:
							this.Sprite.setCurrentAnimation(new List<FarmerSprite.AnimationFrame>
							{
								new FarmerSprite.AnimationFrame(1, 250),
								new FarmerSprite.AnimationFrame(3, 250),
								new FarmerSprite.AnimationFrame(1, 250),
								new FarmerSprite.AnimationFrame(3, 250),
								new FarmerSprite.AnimationFrame(1, 250),
								new FarmerSprite.AnimationFrame(3, 250, false, false, delegate(Farmer _)
								{
									this.DigUpProduce(location, produce);
								}, false)
							});
							break;
						case 3:
							this.Sprite.setCurrentAnimation(new List<FarmerSprite.AnimationFrame>
							{
								new FarmerSprite.AnimationFrame(5, 250, false, true, null, false),
								new FarmerSprite.AnimationFrame(7, 250, false, true, null, false),
								new FarmerSprite.AnimationFrame(5, 250, false, true, null, false),
								new FarmerSprite.AnimationFrame(7, 250, false, true, null, false),
								new FarmerSprite.AnimationFrame(5, 250, false, true, null, false),
								new FarmerSprite.AnimationFrame(7, 250, false, true, delegate(Farmer _)
								{
									this.DigUpProduce(location, produce);
								}, false)
							});
							break;
						}
						this.Sprite.loop = false;
					}
					else
					{
						this.DigUpProduce(location, produce);
					}
				}
				return false;
			}
		}

		// Token: 0x060007D6 RID: 2006 RVA: 0x0005112C File Offset: 0x0004F32C
		public virtual void DigUpProduce(GameLocation location, Object produce)
		{
			Random r = Utility.CreateRandom((double)this.myID.Value / 2.0, Game1.stats.DaysPlayed, (double)Game1.timeOfDay, 0.0, 0.0);
			bool success = false;
			if (produce.QualifiedItemId == "(O)430" && r.NextDouble() < 0.002)
			{
				RockCrab crab = new RockCrab(base.Tile, "Truffle Crab");
				Vector2 v = Utility.recursiveFindOpenTileForCharacter(crab, location, base.Tile, 50, false);
				if (v != Vector2.Zero)
				{
					crab.setTileLocation(v);
					location.addCharacter(crab);
					success = true;
				}
			}
			if (!success && Utility.spawnObjectAround(Utility.getTranslatedVector2(base.Tile, this.FacingDirection, 1f), produce, base.currentLocation, true, null) && produce.QualifiedItemId == "(O)430")
			{
				Stats stats = Game1.stats;
				uint trufflesFound = stats.TrufflesFound;
				stats.TrufflesFound = trufflesFound + 1U;
			}
			if (!r.NextBool((double)this.friendshipTowardFarmer.Value / 1500.0))
			{
				this.currentProduce.Value = null;
			}
		}

		// Token: 0x060007D7 RID: 2007 RVA: 0x00051258 File Offset: 0x0004F458
		public static Microsoft.Xna.Framework.Rectangle GetFollowRange(FarmAnimal animal, int distance = 2)
		{
			Point standingPixel = animal.StandingPixel;
			return new Microsoft.Xna.Framework.Rectangle(standingPixel.X - distance * 64, standingPixel.Y - distance * 64, distance * 64 * 2, 64 * distance * 2);
		}

		// Token: 0x060007D8 RID: 2008 RVA: 0x00051294 File Offset: 0x0004F494
		public virtual void GetNewFollowPosition()
		{
			if (this._followTarget == null)
			{
				this._followTargetPosition = null;
				return;
			}
			if (this._followTarget.isMoving() && this._followTarget.IsActuallySwimming())
			{
				this._followTargetPosition = new Point?(Utility.Vector2ToPoint(Utility.getRandomPositionInThisRectangle(FarmAnimal.GetFollowRange(this._followTarget, 1), Game1.random)));
				return;
			}
			this._followTargetPosition = new Point?(Utility.Vector2ToPoint(Utility.getRandomPositionInThisRectangle(FarmAnimal.GetFollowRange(this._followTarget, 2), Game1.random)));
		}

		// Token: 0x060007D9 RID: 2009 RVA: 0x0005131D File Offset: 0x0004F51D
		public void hitWithWeapon(MeleeWeapon t)
		{
		}

		// Token: 0x060007DA RID: 2010 RVA: 0x00051320 File Offset: 0x0004F520
		public void makeSound()
		{
			if (base.currentLocation == Game1.currentLocation && !Game1.options.muteAnimalSounds)
			{
				string soundToPlay = this.GetSoundId();
				if (soundToPlay != null)
				{
					Game1.playSound(soundToPlay, new int?(1200 + Game1.random.Next(-200, 201)));
				}
			}
		}

		// Token: 0x060007DB RID: 2011 RVA: 0x00051378 File Offset: 0x0004F578
		public string GetSoundId()
		{
			FarmAnimalData data = this.GetAnimalData();
			if (this.isBaby() && data != null && data.BabySound != null)
			{
				return data.BabySound;
			}
			if (data == null)
			{
				return null;
			}
			return data.Sound;
		}

		// Token: 0x060007DC RID: 2012 RVA: 0x000513B1 File Offset: 0x0004F5B1
		public virtual bool CanHavePregnancy()
		{
			FarmAnimalData animalData = this.GetAnimalData();
			return animalData != null && animalData.CanGetPregnant;
		}

		// Token: 0x060007DD RID: 2013 RVA: 0x000513C4 File Offset: 0x0004F5C4
		public virtual bool SleepIfNecessary()
		{
			if (Game1.timeOfDay >= 2000)
			{
				this.isSwimming.Value = false;
				this.hopOffset = Vector2.Zero;
				this._followTarget = null;
				this._followTargetPosition = null;
				if (this.isMoving())
				{
					this.Halt();
				}
				FarmAnimalData data = this.GetAnimalData();
				this.Sprite.currentFrame = ((data != null) ? data.SleepFrame : 12);
				this.FacingDirection = 2;
				this.Sprite.UpdateSourceRect();
				return true;
			}
			return false;
		}

		// Token: 0x060007DE RID: 2014 RVA: 0x00051449 File Offset: 0x0004F649
		public override bool isMoving()
		{
			return this._swimmingVelocity != Vector2.Zero || ((this.IsActuallySwimming() || this.uniqueFrameAccumulator == -1) && base.isMoving());
		}

		// Token: 0x060007DF RID: 2015 RVA: 0x00051478 File Offset: 0x0004F678
		public virtual bool updateWhenCurrentLocation(GameTime time, GameLocation location)
		{
			if (!Game1.shouldTimePass(false))
			{
				return false;
			}
			if (this.health.Value <= 0)
			{
				return true;
			}
			AnimatedSprite sprite = this.GetOrLoadTexture();
			this.doBuildingPokeEvent.Poll();
			this.doDiveEvent.Poll();
			if (this.IsActuallySwimming())
			{
				int time_multiplier = 1;
				if (this.isMoving())
				{
					time_multiplier = 4;
				}
				this.nextRipple -= (int)time.ElapsedGameTime.TotalMilliseconds * time_multiplier;
				if (this.nextRipple <= 0)
				{
					this.nextRipple = 2000;
					float scale = 1f;
					if (this.isBaby())
					{
						scale = 0.65f;
					}
					Point standingPixel = base.StandingPixel;
					float x_offset = base.Position.X - (float)standingPixel.X;
					TemporaryAnimatedSprite ripple = new TemporaryAnimatedSprite("TileSheets\\animations", new Microsoft.Xna.Framework.Rectangle(0, 0, 64, 64), this.isMoving() ? 75f : 150f, 8, 0, new Vector2((float)standingPixel.X + x_offset * scale, (float)standingPixel.Y - 32f * scale), false, Game1.random.NextBool(), 0.01f, 0.01f, Color.White * 0.75f, scale, 0f, 0f, 0f, false);
					Vector2 offset = Utility.PointToVector2(Utility.getTranslatedPoint(default(Point), this.FacingDirection, -1));
					ripple.motion = offset * 0.25f;
					location.TemporarySprites.Add(ripple);
				}
			}
			if (this.hitGlowTimer > 0)
			{
				this.hitGlowTimer -= time.ElapsedGameTime.Milliseconds;
			}
			if (sprite.CurrentAnimation != null)
			{
				if (sprite.animateOnce(time))
				{
					sprite.CurrentAnimation = null;
				}
				return false;
			}
			this.update(time, location, this.myID.Value, false);
			if (this.hopOffset != Vector2.Zero)
			{
				sprite.UpdateSourceRect();
				this.HandleHop();
				return false;
			}
			if (Game1.IsMasterGame && this.behaviors(time, location))
			{
				return false;
			}
			if (sprite.CurrentAnimation != null)
			{
				return false;
			}
			PathFindController controller = this.controller;
			if (controller != null && controller.timerSinceLastCheckPoint > 10000)
			{
				this.controller = null;
				this.Halt();
			}
			if (Game1.IsMasterGame)
			{
				if (!this.IsHome && this.noWarpTimer <= 0)
				{
					GameLocation insideHome = this.homeInterior;
					if (insideHome != null)
					{
						Microsoft.Xna.Framework.Rectangle bounds = this.GetBoundingBox();
						if (this.home.getRectForAnimalDoor().Contains(bounds.Center.X, bounds.Top))
						{
							if (Utility.isOnScreen(base.TilePoint, 192, location))
							{
								location.localSound("dwoop", null, null, SoundContext.Default);
							}
							location.animals.Remove(this.myID.Value);
							insideHome.animals[this.myID.Value] = this;
							this.setRandomPosition(insideHome);
							this.faceDirection(Game1.random.Next(4));
							this.controller = null;
							return true;
						}
					}
				}
				this.noWarpTimer = Math.Max(0, this.noWarpTimer - time.ElapsedGameTime.Milliseconds);
			}
			if (this.pauseTimer > 0)
			{
				this.pauseTimer -= time.ElapsedGameTime.Milliseconds;
			}
			if (this.SleepIfNecessary())
			{
				if (!this.isEmoting && Game1.random.NextDouble() < 0.002)
				{
					base.doEmote(24, true);
				}
			}
			else if (this.pauseTimer <= 0 && Game1.random.NextDouble() < 0.001 && this.isAdult() && Game1.gameMode == 3 && Utility.isOnScreen(base.Position, 192))
			{
				this.makeSound();
			}
			if (Game1.IsMasterGame)
			{
				this.UpdateRandomMovements();
				if (this.uniqueFrameAccumulator != -1 && this._followTarget != null && !FarmAnimal.GetFollowRange(this._followTarget, 1).Contains(base.StandingPixel))
				{
					this.uniqueFrameAccumulator = -1;
				}
				if (this.uniqueFrameAccumulator != -1)
				{
					this.uniqueFrameAccumulator += time.ElapsedGameTime.Milliseconds;
					if (this.uniqueFrameAccumulator > 500)
					{
						FarmAnimalData animalData = this.GetAnimalData();
						bool? flag = (animalData != null) ? new bool?(animalData.UseDoubleUniqueAnimationFrames) : null;
						if (flag != null && flag.GetValueOrDefault())
						{
							sprite.currentFrame = sprite.currentFrame + 1 - sprite.currentFrame % 2 * 2;
						}
						else if (sprite.currentFrame > 12)
						{
							sprite.currentFrame = (sprite.currentFrame - 13) * 4;
						}
						else
						{
							switch (this.FacingDirection)
							{
							case 0:
								sprite.currentFrame = 15;
								break;
							case 1:
								sprite.currentFrame = 14;
								break;
							case 2:
								sprite.currentFrame = 13;
								break;
							case 3:
								sprite.currentFrame = 14;
								break;
							}
						}
						this.uniqueFrameAccumulator = 0;
						if (Game1.random.NextDouble() < 0.4)
						{
							this.uniqueFrameAccumulator = -1;
						}
					}
					if (this.IsActuallySwimming())
					{
						this.MovePosition(time, Game1.viewport, location);
					}
				}
				else
				{
					this.MovePosition(time, Game1.viewport, location);
				}
			}
			if (this.IsActuallySwimming())
			{
				FarmAnimalData data = this.GetAnimalData();
				sprite.UpdateSourceRect();
				Microsoft.Xna.Framework.Rectangle source_rect = sprite.SourceRect;
				source_rect.Offset((data != null) ? data.SwimOffset : new Point(0, 112));
				sprite.SourceRect = source_rect;
			}
			return false;
		}

		// Token: 0x060007E0 RID: 2016 RVA: 0x00051A10 File Offset: 0x0004FC10
		public virtual void UpdateRandomMovements()
		{
			if (!Game1.IsMasterGame || Game1.timeOfDay >= 2000 || this.pauseTimer > 0)
			{
				return;
			}
			if (this.fullness.Value < 255 && this.IsActuallySwimming() && Game1.random.NextDouble() < 0.002 && !this.isEating.Value)
			{
				this.Eat(base.currentLocation);
			}
			if (Game1.random.NextDouble() < 0.007 && this.uniqueFrameAccumulator == -1)
			{
				int newDirection = Game1.random.Next(5);
				if (newDirection != (this.FacingDirection + 2) % 4 || this.IsActuallySwimming())
				{
					if (newDirection < 4)
					{
						int oldDirection = this.FacingDirection;
						this.faceDirection(newDirection);
						if (!base.currentLocation.isOutdoors.Value && base.currentLocation.isCollidingPosition(this.nextPosition(newDirection), Game1.viewport, this))
						{
							this.faceDirection(oldDirection);
							return;
						}
					}
					switch (newDirection)
					{
					case 0:
						this.SetMovingUp(true);
						break;
					case 1:
						this.SetMovingRight(true);
						break;
					case 2:
						this.SetMovingDown(true);
						break;
					case 3:
						this.SetMovingLeft(true);
						break;
					default:
						this.Halt();
						this.Sprite.StopAnimation();
						break;
					}
				}
				else if (this.noWarpTimer <= 0)
				{
					this.Halt();
					this.Sprite.StopAnimation();
				}
			}
			if (this.isMoving() && Game1.random.NextDouble() < 0.014 && this.uniqueFrameAccumulator == -1)
			{
				this.Halt();
				this.Sprite.StopAnimation();
				if (Game1.random.NextDouble() < 0.75)
				{
					FarmAnimalData data = this.GetAnimalData();
					this.uniqueFrameAccumulator = 0;
					bool? flag = (data != null) ? new bool?(data.UseDoubleUniqueAnimationFrames) : null;
					if (flag != null && flag.GetValueOrDefault())
					{
						switch (this.FacingDirection)
						{
						case 0:
							this.Sprite.currentFrame = 20;
							break;
						case 1:
							this.Sprite.currentFrame = 18;
							break;
						case 2:
							this.Sprite.currentFrame = 16;
							break;
						case 3:
							this.Sprite.currentFrame = 22;
							break;
						}
					}
					else
					{
						switch (this.FacingDirection)
						{
						case 0:
							this.Sprite.currentFrame = 15;
							break;
						case 1:
							this.Sprite.currentFrame = 14;
							break;
						case 2:
							this.Sprite.currentFrame = 13;
							break;
						case 3:
							this.Sprite.currentFrame = ((((data != null) ? new bool?(data.UseFlippedRightForLeft) : null) ?? false) ? 14 : 12);
							break;
						}
					}
					this.uniqueFrameAccumulator = 0;
				}
				this.Sprite.UpdateSourceRect();
			}
		}

		// Token: 0x060007E1 RID: 2017 RVA: 0x00051D16 File Offset: 0x0004FF16
		public virtual bool CanSwim()
		{
			FarmAnimalData animalData = this.GetAnimalData();
			return animalData != null && animalData.CanSwim;
		}

		// Token: 0x060007E2 RID: 2018 RVA: 0x00051D29 File Offset: 0x0004FF29
		public virtual bool CanFollowAdult()
		{
			if (this.isBaby())
			{
				FarmAnimalData animalData = this.GetAnimalData();
				return animalData != null && animalData.BabiesFollowAdults;
			}
			return false;
		}

		// Token: 0x060007E3 RID: 2019 RVA: 0x00051D46 File Offset: 0x0004FF46
		public override bool shouldCollideWithBuildingLayer(GameLocation location)
		{
			return true;
		}

		// Token: 0x060007E4 RID: 2020 RVA: 0x00051D4C File Offset: 0x0004FF4C
		public virtual void HandleHop()
		{
			int hop_speed = 4;
			if (this.hopOffset != Vector2.Zero)
			{
				if (this.hopOffset.X != 0f)
				{
					int move_amount = (int)Math.Min((float)hop_speed, Math.Abs(this.hopOffset.X));
					base.Position += new Vector2((float)(move_amount * Math.Sign(this.hopOffset.X)), 0f);
					this.hopOffset.X = Utility.MoveTowards(this.hopOffset.X, 0f, (float)move_amount);
				}
				if (this.hopOffset.Y != 0f)
				{
					int move_amount2 = (int)Math.Min((float)hop_speed, Math.Abs(this.hopOffset.Y));
					base.Position += new Vector2(0f, (float)(move_amount2 * Math.Sign(this.hopOffset.Y)));
					this.hopOffset.Y = Utility.MoveTowards(this.hopOffset.Y, 0f, (float)move_amount2);
				}
				if (this.hopOffset == Vector2.Zero && this.isSwimming.Value)
				{
					this.Splash();
					this._swimmingVelocity = Utility.getTranslatedVector2(Vector2.Zero, this.FacingDirection, (float)base.speed);
					base.Position = new Vector2((float)((int)Math.Round((double)base.Position.X)), (float)((int)Math.Round((double)base.Position.Y)));
				}
			}
		}

		// Token: 0x060007E5 RID: 2021 RVA: 0x00051EDC File Offset: 0x000500DC
		public override void MovePosition(GameTime time, xTile.Dimensions.Rectangle viewport, GameLocation currentLocation)
		{
			if (this.pauseTimer > 0 || Game1.IsClient)
			{
				return;
			}
			Location next_tile = base.nextPositionTile();
			if (!currentLocation.isTileOnMap(new Vector2((float)next_tile.X, (float)next_tile.Y)))
			{
				this.FacingDirection = Utility.GetOppositeFacingDirection(this.FacingDirection);
				this.moveUp = (this.facingDirection.Value == 0);
				this.moveLeft = (this.facingDirection.Value == 3);
				this.moveDown = (this.facingDirection.Value == 2);
				this.moveRight = (this.facingDirection.Value == 1);
				this._followTarget = null;
				this._followTargetPosition = null;
				this._swimmingVelocity = Vector2.Zero;
				return;
			}
			if (this._followTarget != null && (this._followTarget.currentLocation != currentLocation || this._followTarget.health.Value <= 0))
			{
				this._followTarget = null;
				this._followTargetPosition = null;
			}
			if (this._followTargetPosition != null)
			{
				Point standingPixel = base.StandingPixel;
				Point targetPosition = this._followTargetPosition.Value;
				Point offset = new Point(standingPixel.X - targetPosition.X, standingPixel.Y - targetPosition.Y);
				if (Math.Abs(offset.X) <= 64 || Math.Abs(offset.Y) <= 64)
				{
					this.moveDown = false;
					this.moveUp = false;
					this.moveLeft = false;
					this.moveRight = false;
					this.GetNewFollowPosition();
				}
				else if (this.nextFollowDirectionChange >= 0)
				{
					this.nextFollowDirectionChange -= (int)time.ElapsedGameTime.TotalMilliseconds;
				}
				else
				{
					if (this.IsActuallySwimming())
					{
						this.nextFollowDirectionChange = 100;
					}
					else
					{
						this.nextFollowDirectionChange = 500;
					}
					this.moveDown = false;
					this.moveUp = false;
					this.moveLeft = false;
					this.moveRight = false;
					if (Math.Abs(standingPixel.X - this._followTargetPosition.Value.X) < Math.Abs(standingPixel.Y - this._followTargetPosition.Value.Y))
					{
						if (standingPixel.Y > this._followTargetPosition.Value.Y)
						{
							this.moveUp = true;
						}
						else if (standingPixel.Y < this._followTargetPosition.Value.Y)
						{
							this.moveDown = true;
						}
					}
					else if (standingPixel.X < this._followTargetPosition.Value.X)
					{
						this.moveRight = true;
					}
					else if (standingPixel.X > this._followTargetPosition.Value.X)
					{
						this.moveLeft = true;
					}
				}
			}
			if (this.IsActuallySwimming())
			{
				Vector2 desired_movement = default(Vector2);
				if (!this.isEating.Value)
				{
					if (this.moveUp)
					{
						desired_movement.Y = (float)(-(float)base.speed);
					}
					else if (this.moveDown)
					{
						desired_movement.Y = (float)base.speed;
					}
					if (this.moveLeft)
					{
						desired_movement.X = (float)(-(float)base.speed);
					}
					else if (this.moveRight)
					{
						desired_movement.X = (float)base.speed;
					}
				}
				this._swimmingVelocity = new Vector2(Utility.MoveTowards(this._swimmingVelocity.X, desired_movement.X, 0.025f), Utility.MoveTowards(this._swimmingVelocity.Y, desired_movement.Y, 0.025f));
				Vector2 old_position = base.Position;
				base.Position += this._swimmingVelocity;
				Microsoft.Xna.Framework.Rectangle next_bounds = this.GetBoundingBox();
				base.Position = old_position;
				int moving_direction = -1;
				if (!currentLocation.isCollidingPosition(next_bounds, Game1.viewport, false, 0, false, this, false, false, false, false))
				{
					base.Position += this._swimmingVelocity;
					if (Math.Abs(this._swimmingVelocity.X) > Math.Abs(this._swimmingVelocity.Y))
					{
						if (this._swimmingVelocity.X < 0f)
						{
							moving_direction = 3;
						}
						else if (this._swimmingVelocity.X > 0f)
						{
							moving_direction = 1;
						}
					}
					else if (this._swimmingVelocity.Y < 0f)
					{
						moving_direction = 0;
					}
					else if (this._swimmingVelocity.Y > 0f)
					{
						moving_direction = 2;
					}
					switch (moving_direction)
					{
					case 0:
						this.Sprite.AnimateUp(time, 0, "");
						this.faceDirection(0);
						return;
					case 1:
						this.Sprite.AnimateRight(time, 0, "");
						this.faceDirection(1);
						return;
					case 2:
						this.Sprite.AnimateDown(time, 0, "");
						this.faceDirection(2);
						return;
					case 3:
						this.Sprite.AnimateRight(time, 0, "");
						this.FacingDirection = 3;
						return;
					default:
						return;
					}
				}
				else if (!this.HandleCollision(next_bounds))
				{
					this.Halt();
					this.Sprite.StopAnimation();
					this._swimmingVelocity *= -1f;
					return;
				}
			}
			else
			{
				if (this.moveUp)
				{
					if (!currentLocation.isCollidingPosition(this.nextPosition(0), Game1.viewport, false, 0, false, this, false, false, false, false))
					{
						this.position.Y -= (float)base.speed;
						this.Sprite.AnimateUp(time, 0, "");
					}
					else if (!this.HandleCollision(this.nextPosition(0)))
					{
						this.Halt();
						this.Sprite.StopAnimation();
						if (Game1.random.NextDouble() < 0.6 || this.IsActuallySwimming())
						{
							this.SetMovingDown(true);
						}
					}
					this.faceDirection(0);
					return;
				}
				if (this.moveRight)
				{
					if (!currentLocation.isCollidingPosition(this.nextPosition(1), Game1.viewport, false, 0, false, this))
					{
						this.position.X += (float)base.speed;
						this.Sprite.AnimateRight(time, 0, "");
					}
					else if (!this.HandleCollision(this.nextPosition(1)))
					{
						this.Halt();
						this.Sprite.StopAnimation();
						if (Game1.random.NextDouble() < 0.6 || this.IsActuallySwimming())
						{
							this.SetMovingLeft(true);
						}
					}
					this.faceDirection(1);
					return;
				}
				if (this.moveDown)
				{
					if (!currentLocation.isCollidingPosition(this.nextPosition(2), Game1.viewport, false, 0, false, this))
					{
						this.position.Y += (float)base.speed;
						this.Sprite.AnimateDown(time, 0, "");
					}
					else if (!this.HandleCollision(this.nextPosition(2)))
					{
						this.Halt();
						this.Sprite.StopAnimation();
						if (Game1.random.NextDouble() < 0.6 || this.IsActuallySwimming())
						{
							this.SetMovingUp(true);
						}
					}
					this.faceDirection(2);
					return;
				}
				if (this.moveLeft)
				{
					if (!currentLocation.isCollidingPosition(this.nextPosition(3), Game1.viewport, false, 0, false, this))
					{
						this.position.X -= (float)base.speed;
						this.Sprite.AnimateRight(time, 0, "");
					}
					else if (!this.HandleCollision(this.nextPosition(3)))
					{
						this.Halt();
						this.Sprite.StopAnimation();
						if (Game1.random.NextDouble() < 0.6 || this.IsActuallySwimming())
						{
							this.SetMovingRight(true);
						}
					}
					this.FacingDirection = 3;
				}
			}
		}

		// Token: 0x060007E6 RID: 2022 RVA: 0x0005264C File Offset: 0x0005084C
		public virtual bool HandleCollision(Microsoft.Xna.Framework.Rectangle next_position)
		{
			if (this._followTarget != null)
			{
				this._followTarget = null;
				this._followTargetPosition = null;
			}
			if (base.currentLocation.IsOutdoors && this.CanSwim() && (this.isSwimming.Value || this.controller == null) && this.wasPet.Value && this.hopOffset == Vector2.Zero)
			{
				base.Position = new Vector2((float)((int)Math.Round((double)base.Position.X)), (float)((int)Math.Round((double)base.Position.Y)));
				Microsoft.Xna.Framework.Rectangle current_position = this.GetBoundingBox();
				Vector2 offset = Utility.getTranslatedVector2(Vector2.Zero, this.FacingDirection, 1f);
				if (offset != Vector2.Zero)
				{
					Point hop_over_tile = base.TilePoint;
					hop_over_tile.X += (int)offset.X;
					hop_over_tile.Y += (int)offset.Y;
					offset *= 128f;
					Microsoft.Xna.Framework.Rectangle hop_destination = current_position;
					hop_destination.Offset(Utility.Vector2ToPoint(offset));
					Point hop_tile = new Point(hop_destination.X / 64, hop_destination.Y / 64);
					if (base.currentLocation.isWaterTile(hop_over_tile.X, hop_over_tile.Y) && base.currentLocation.doesTileHaveProperty(hop_over_tile.X, hop_over_tile.Y, "Passable", "Buildings", false) == null && !base.currentLocation.isCollidingPosition(hop_destination, Game1.viewport, false, 0, false, this) && base.currentLocation.isOpenWater(hop_tile.X, hop_tile.Y) != this.isSwimming.Value)
					{
						this.isSwimming.Value = !this.isSwimming.Value;
						if (!this.isSwimming.Value)
						{
							this.Splash();
						}
						this.hopOffset = offset;
						this.pauseTimer = 0;
						this.doDiveEvent.Fire();
					}
					return true;
				}
			}
			return false;
		}

		// Token: 0x060007E7 RID: 2023 RVA: 0x00052851 File Offset: 0x00050A51
		public virtual bool IsActuallySwimming()
		{
			return this.isSwimming.Value && this.hopOffset == Vector2.Zero;
		}

		// Token: 0x060007E8 RID: 2024 RVA: 0x00052874 File Offset: 0x00050A74
		public virtual void Splash()
		{
			if (Utility.isOnScreen(base.TilePoint, 192, base.currentLocation))
			{
				base.currentLocation.playSound("dropItemInWater", null, null, SoundContext.Default);
			}
			Game1.multiplayer.broadcastSprites(base.currentLocation, new TemporaryAnimatedSprite[]
			{
				new TemporaryAnimatedSprite(28, 100f, 2, 1, base.getStandingPosition() + new Vector2(-0.5f, -0.5f) * 64f, false, false)
				{
					delayBeforeAnimationStart = 0,
					layerDepth = (float)base.StandingPixel.Y / 10000f
				}
			});
		}

		// Token: 0x060007E9 RID: 2025 RVA: 0x00052928 File Offset: 0x00050B28
		public override void animateInFacingDirection(GameTime time)
		{
			if (this.FacingDirection == 3)
			{
				this.Sprite.AnimateRight(time, 0, "");
				return;
			}
			base.animateInFacingDirection(time);
		}

		// Token: 0x060007EA RID: 2026 RVA: 0x00052950 File Offset: 0x00050B50
		private void ValidateSpritesheetSize()
		{
			int num = 5 + ((!this.Sprite.textureUsesFlippedRightForLeft) ? 1 : 0);
			FarmAnimalData animalData = this.GetAnimalData();
			int expectedRows = num + (((((animalData != null) ? new bool?(animalData.UseDoubleUniqueAnimationFrames) : null) ?? false) > false) ? 1 : 0);
			if (this.Sprite.Texture.Height < expectedRows * this.Sprite.SpriteHeight)
			{
				IGameLogger log = Game1.log;
				DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(126, 3);
				defaultInterpolatedStringHandler.AppendLiteral("Farm animal '");
				defaultInterpolatedStringHandler.AppendFormatted(this.type.Value);
				defaultInterpolatedStringHandler.AppendLiteral("' has sprite height ");
				defaultInterpolatedStringHandler.AppendFormatted<int>(this.Sprite.Texture.Height);
				defaultInterpolatedStringHandler.AppendLiteral("px, but expected at least ");
				defaultInterpolatedStringHandler.AppendFormatted<int>(expectedRows * this.Sprite.SpriteHeight);
				defaultInterpolatedStringHandler.AppendLiteral("px based on its data. This may cause issues like frozen animations.");
				log.Warn(defaultInterpolatedStringHandler.ToStringAndClear());
			}
			if (this.Sprite.Texture.Width != 4 * this.Sprite.SpriteWidth)
			{
				IGameLogger log2 = Game1.log;
				DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(64, 3);
				defaultInterpolatedStringHandler.AppendLiteral("Farm animal '");
				defaultInterpolatedStringHandler.AppendFormatted(this.type.Value);
				defaultInterpolatedStringHandler.AppendLiteral("' has sprite width ");
				defaultInterpolatedStringHandler.AppendFormatted<int>(this.Sprite.Texture.Width);
				defaultInterpolatedStringHandler.AppendLiteral("px, but it should be exactly ");
				defaultInterpolatedStringHandler.AppendFormatted<int>(4 * this.Sprite.SpriteWidth);
				defaultInterpolatedStringHandler.AppendLiteral("px.");
				log2.Warn(defaultInterpolatedStringHandler.ToStringAndClear());
			}
		}

		// Token: 0x0400041E RID: 1054
		public const byte eatGrassBehavior = 0;

		// Token: 0x0400041F RID: 1055
		public const short newHome = 0;

		// Token: 0x04000420 RID: 1056
		public const short happy = 1;

		// Token: 0x04000421 RID: 1057
		public const short neutral = 2;

		// Token: 0x04000422 RID: 1058
		public const short unhappy = 3;

		// Token: 0x04000423 RID: 1059
		public const short hungry = 4;

		// Token: 0x04000424 RID: 1060
		public const short disturbedByDog = 5;

		// Token: 0x04000425 RID: 1061
		public const short leftOutAtNight = 6;

		// Token: 0x04000426 RID: 1062
		public const double chancePerUpdateToChangeDirection = 0.007;

		// Token: 0x04000427 RID: 1063
		public const byte fullnessValueOfGrass = 60;

		// Token: 0x04000428 RID: 1064
		public const int noWarpTimerTime = 3000;

		// Token: 0x04000429 RID: 1065
		public new const double chanceForSound = 0.002;

		// Token: 0x0400042A RID: 1066
		public const double chanceToGoOutside = 0.002;

		// Token: 0x0400042B RID: 1067
		public const int uniqueDownFrame = 16;

		// Token: 0x0400042C RID: 1068
		public const int uniqueRightFrame = 18;

		// Token: 0x0400042D RID: 1069
		public const int uniqueUpFrame = 20;

		// Token: 0x0400042E RID: 1070
		public const int uniqueLeftFrame = 22;

		// Token: 0x0400042F RID: 1071
		public const int pushAccumulatorTimeTillPush = 60;

		// Token: 0x04000430 RID: 1072
		public const int timePerUniqueFrame = 500;

		// Token: 0x04000431 RID: 1073
		public const string ErrorTextureName = "Animals\\Error";

		// Token: 0x04000432 RID: 1074
		public const int ErrorSpriteSize = 16;

		// Token: 0x04000433 RID: 1075
		public NetBool isSwimming = new NetBool();

		// Token: 0x04000434 RID: 1076
		[XmlIgnore]
		public Vector2 hopOffset = new Vector2(0f, 0f);

		// Token: 0x04000435 RID: 1077
		[XmlElement("currentProduce")]
		public readonly NetString currentProduce = new NetString();

		// Token: 0x04000436 RID: 1078
		[XmlElement("friendshipTowardFarmer")]
		public readonly NetInt friendshipTowardFarmer = new NetInt();

		// Token: 0x04000437 RID: 1079
		[XmlElement("skinID")]
		public readonly NetString skinID = new NetString();

		// Token: 0x04000438 RID: 1080
		[XmlIgnore]
		public int pushAccumulator;

		// Token: 0x04000439 RID: 1081
		[XmlIgnore]
		public int uniqueFrameAccumulator = -1;

		// Token: 0x0400043A RID: 1082
		[XmlElement("age")]
		public readonly NetInt age = new NetInt();

		// Token: 0x0400043B RID: 1083
		[XmlElement("daysOwned")]
		public readonly NetInt daysOwned = new NetInt(-1);

		// Token: 0x0400043C RID: 1084
		[XmlElement("health")]
		public readonly NetInt health = new NetInt();

		// Token: 0x0400043D RID: 1085
		[XmlElement("produceQuality")]
		public readonly NetInt produceQuality = new NetInt();

		// Token: 0x0400043E RID: 1086
		[XmlElement("daysSinceLastLay")]
		public readonly NetInt daysSinceLastLay = new NetInt();

		// Token: 0x0400043F RID: 1087
		[XmlElement("happiness")]
		public readonly NetInt happiness = new NetInt();

		// Token: 0x04000440 RID: 1088
		[XmlElement("fullness")]
		public readonly NetInt fullness = new NetInt();

		// Token: 0x04000441 RID: 1089
		[XmlElement("wasAutoPet")]
		public readonly NetBool wasAutoPet = new NetBool();

		// Token: 0x04000442 RID: 1090
		[XmlElement("wasPet")]
		public readonly NetBool wasPet = new NetBool();

		// Token: 0x04000443 RID: 1091
		[XmlElement("allowReproduction")]
		public readonly NetBool allowReproduction = new NetBool(true);

		// Token: 0x04000444 RID: 1092
		[XmlElement("type")]
		public readonly NetString type = new NetString();

		// Token: 0x04000445 RID: 1093
		[XmlElement("buildingTypeILiveIn")]
		public readonly NetString buildingTypeILiveIn = new NetString();

		// Token: 0x04000446 RID: 1094
		[XmlElement("myID")]
		public readonly NetLong myID = new NetLong();

		// Token: 0x04000447 RID: 1095
		[XmlElement("ownerID")]
		public readonly NetLong ownerID = new NetLong();

		// Token: 0x04000448 RID: 1096
		[XmlElement("parentId")]
		public readonly NetLong parentId = new NetLong(-1L);

		// Token: 0x04000449 RID: 1097
		[XmlIgnore]
		private readonly NetLocationRef netHomeInterior = new NetLocationRef();

		// Token: 0x0400044A RID: 1098
		[XmlElement("hasEatenAnimalCracker")]
		public readonly NetBool hasEatenAnimalCracker = new NetBool();

		// Token: 0x0400044B RID: 1099
		[XmlIgnore]
		public int noWarpTimer;

		// Token: 0x0400044C RID: 1100
		[XmlIgnore]
		public int hitGlowTimer;

		// Token: 0x0400044D RID: 1101
		[XmlIgnore]
		public int pauseTimer;

		// Token: 0x0400044E RID: 1102
		[XmlElement("moodMessage")]
		public readonly NetInt moodMessage = new NetInt();

		// Token: 0x0400044F RID: 1103
		[XmlElement("isEating")]
		public readonly NetBool isEating = new NetBool();

		// Token: 0x04000450 RID: 1104
		[XmlIgnore]
		private readonly NetEvent1Field<int, NetInt> doFarmerPushEvent = new NetEvent1Field<int, NetInt>();

		// Token: 0x04000451 RID: 1105
		[XmlIgnore]
		private readonly NetEvent0 doBuildingPokeEvent = new NetEvent0(false);

		// Token: 0x04000452 RID: 1106
		[XmlIgnore]
		private readonly NetEvent0 doDiveEvent = new NetEvent0(false);

		// Token: 0x04000453 RID: 1107
		private string _displayHouse;

		// Token: 0x04000454 RID: 1108
		private string _displayType;

		// Token: 0x04000455 RID: 1109
		public static int NumPathfindingThisTick = 0;

		// Token: 0x04000456 RID: 1110
		public static int MaxPathfindingPerTick = 1;

		// Token: 0x04000457 RID: 1111
		[XmlIgnore]
		public int nextRipple;

		// Token: 0x04000458 RID: 1112
		[XmlIgnore]
		public int nextFollowDirectionChange;

		// Token: 0x04000459 RID: 1113
		protected FarmAnimal _followTarget;

		// Token: 0x0400045A RID: 1114
		protected Point? _followTargetPosition;

		// Token: 0x0400045B RID: 1115
		protected float _nextFollowTargetScan = 1f;

		// Token: 0x0400045C RID: 1116
		[XmlIgnore]
		public int bobOffset;

		// Token: 0x0400045D RID: 1117
		[XmlIgnore]
		protected Vector2 _swimmingVelocity = Vector2.Zero;

		// Token: 0x0400045E RID: 1118
		[XmlIgnore]
		public static HashSet<Grass> reservedGrass = new HashSet<Grass>();

		// Token: 0x0400045F RID: 1119
		[XmlIgnore]
		public Grass foundGrass;
	}
}
