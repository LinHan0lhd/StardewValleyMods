﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using StardewValley.Characters;
using StardewValley.Extensions;
using StardewValley.GameData;
using StardewValley.GameData.Characters;
using StardewValley.GameData.FarmAnimals;
using StardewValley.GameData.Pets;
using StardewValley.ItemTypeDefinitions;
using StardewValley.Monsters;
using StardewValley.TokenizableStrings;

namespace StardewValley.Locations
{
	// Token: 0x020002F1 RID: 753
	public class Summit : GameLocation
	{
		// Token: 0x06003249 RID: 12873 RVA: 0x00282E5A File Offset: 0x0028105A
		public Summit()
		{
		}

		// Token: 0x0600324A RID: 12874 RVA: 0x00282E6D File Offset: 0x0028106D
		public Summit(string map, string name) : base(map, name)
		{
		}

		// Token: 0x0600324B RID: 12875 RVA: 0x00282E82 File Offset: 0x00281082
		public override void checkForMusic(GameTime time)
		{
		}

		// Token: 0x0600324C RID: 12876 RVA: 0x00282E84 File Offset: 0x00281084
		public override void UpdateWhenCurrentLocation(GameTime time)
		{
			if (Game1.random.NextDouble() < 0.005 || this.globalWind >= 1f || this.globalWind <= 0.35f)
			{
				if (this.globalWind < 0.35f)
				{
					this.windGust = (float)Game1.random.Next(3, 6) / 2000f;
				}
				else if (this.globalWind > 0.75f)
				{
					this.windGust = (float)(-(float)Game1.random.Next(2, 6)) / 2000f;
				}
				else
				{
					this.windGust = (float)(Game1.random.Choose(-1, 1) * Game1.random.Next(4, 6)) / 2000f;
				}
			}
			if (this.wind != null)
			{
				this.globalWind += this.windGust;
				this.globalWind = Utility.Clamp(this.globalWind, -0.5f, 1f);
				this.wind.SetVariable("Volume", Math.Abs(this.globalWind) * 60f);
				this.wind.SetVariable("Frequency", this.globalWind * 100f);
				Game1.sounds.SetPitch(this.wind, 1200f + Math.Abs(this.globalWind) * 1200f, true);
			}
			if (Game1.background != null && Game1.background.cursed)
			{
				if (Game1.random.NextDouble() < 0.01)
				{
					Game1.playSound(Game1.random.Choose(new string[]
					{
						"coin",
						"slimeHit",
						"squid_hit",
						"skeletonStep",
						"rabbit",
						"pig",
						"gulp"
					}), null);
					if (Game1.options.screenFlash)
					{
						Game1.background.c = Utility.getBlendedColor(Utility.getRandomRainbowColor(null), Color.Black);
					}
				}
				if (Game1.background.c.R > 0)
				{
					Background background = Game1.background;
					byte b = background.c.R;
					background.c.R = b - 1;
				}
				if (Game1.background.c.G > 0)
				{
					Background background2 = Game1.background;
					byte b = background2.c.G;
					background2.c.G = b - 1;
				}
				if (Game1.background.c.B > 0)
				{
					Background background3 = Game1.background;
					byte b = background3.c.B;
					background3.c.B = b - 1;
				}
			}
			base.UpdateWhenCurrentLocation(time);
			Season localSeason = base.GetSeason();
			if (this.currentEvent == null && Game1.background != null && !Game1.background.cursed && this.temporarySprites.Count == 0 && Game1.random.NextDouble() < ((Game1.timeOfDay >= 1800) ? ((Game1.season == Season.Summer && Game1.dayOfMonth == 20) ? 1.0 : 0.001) : 0.0006))
			{
				Rectangle sourceRect = Rectangle.Empty;
				Vector2 startingPosition = new Vector2((float)Game1.viewport.Width, (float)Game1.random.Next(10, Game1.viewport.Height / 2));
				float speed = -4f;
				int loops = 200;
				float animationSpeed = 100f;
				if (Game1.timeOfDay < 1800)
				{
					switch (localSeason)
					{
					case Season.Spring:
					case Season.Fall:
					{
						sourceRect = new Rectangle(640, 736, 16, 16);
						int rows = Game1.random.Next(1, 4);
						speed = -1f;
						for (int i = 0; i < rows; i++)
						{
							TemporaryAnimatedSprite bird = new TemporaryAnimatedSprite("LooseSprites\\Cursors", sourceRect, (float)Game1.random.Next(80, 121), 4, 200, startingPosition + new Vector2((float)((i + 1) * Game1.random.Next(15, 18)), (float)((i + 1) * -20)), false, false, 0.01f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
							{
								layerDepth = 0f
							};
							bird.motion = new Vector2(-1f, 0f);
							this.temporarySprites.Add(bird);
							bird = new TemporaryAnimatedSprite("LooseSprites\\Cursors", sourceRect, (float)Game1.random.Next(80, 121), 4, 200, startingPosition + new Vector2((float)((i + 1) * Game1.random.Next(15, 18)), (float)((i + 1) * 20)), false, false, 0.01f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
							{
								layerDepth = 0f
							};
							bird.motion = new Vector2(-1f, 0f);
							this.temporarySprites.Add(bird);
						}
						break;
					}
					case Season.Summer:
						sourceRect = new Rectangle(640, 752 + Game1.random.Choose(16, 0), 16, 16);
						speed = -0.5f;
						animationSpeed = 150f;
						break;
					}
					if (Game1.random.NextDouble() < 0.25)
					{
						TemporaryAnimatedSprite bird2;
						switch (localSeason)
						{
						case Season.Spring:
							bird2 = new TemporaryAnimatedSprite("LooseSprites\\Cursors2", new Rectangle(0, 302, 26, 18), (float)Game1.random.Next(80, 121), 4, 200, startingPosition, false, false, 0.01f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
							{
								layerDepth = 0f,
								pingPong = true
							};
							break;
						case Season.Summer:
							bird2 = new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(1, 165, 24, 21), (float)Game1.random.Next(60, 80), 6, 200, startingPosition, false, false, 0.01f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
							{
								layerDepth = 0f
							};
							break;
						case Season.Fall:
							bird2 = new TemporaryAnimatedSprite("TileSheets\\critters", new Rectangle(0, 64, 32, 32), (float)Game1.random.Next(60, 80), 5, 200, startingPosition, false, false, 0.01f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
							{
								layerDepth = 0f,
								pingPong = true
							};
							break;
						case Season.Winter:
							bird2 = new TemporaryAnimatedSprite("LooseSprites\\Cursors2", new Rectangle(104, 302, 26, 18), (float)Game1.random.Next(80, 121), 4, 200, startingPosition, false, false, 0.01f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
							{
								layerDepth = 0f,
								pingPong = true
							};
							break;
						default:
							bird2 = new TemporaryAnimatedSprite();
							break;
						}
						bird2.motion = new Vector2(-3f, 0f);
						this.temporarySprites.Add(bird2);
					}
					else if (Game1.random.NextDouble() < 0.15 && Game1.stats.Get("childrenTurnedToDoves") > 1U)
					{
						int j = 0;
						while ((long)j < (long)((ulong)Game1.stats.Get("childrenTurnedToDoves")))
						{
							sourceRect = Rectangle.Empty;
							TemporaryAnimatedSprite bird3 = new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(388, 1894, 24, 21), (float)Game1.random.Next(80, 121), 6, 200, startingPosition + new Vector2((float)((j + 1) * (Game1.random.Next(25, 27) * 4)), (float)(Game1.random.Next(-32, 33) * 4)), false, false, 0.01f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
							{
								layerDepth = 0f
							};
							bird3.motion = new Vector2(-3f, 0f);
							this.temporarySprites.Add(bird3);
							j++;
						}
					}
					if (Game1.MasterPlayer.eventsSeen.Contains("571102") && Game1.random.NextDouble() < 0.1)
					{
						sourceRect = Rectangle.Empty;
						TemporaryAnimatedSprite bird4 = new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(222, 1890, 20, 9), 30f, 2, 99900, startingPosition, false, false, 0.01f, 0f, Color.White, 2f, 0f, 0f, 0f, true)
						{
							yPeriodic = true,
							yPeriodicLoopTime = 4000f,
							yPeriodicRange = 8f,
							layerDepth = 0f
						};
						bird4.motion = new Vector2(-3f, 0f);
						this.temporarySprites.Add(bird4);
					}
					if (Game1.MasterPlayer.eventsSeen.Contains("10") && Game1.random.NextDouble() < 0.05)
					{
						sourceRect = Rectangle.Empty;
						TemporaryAnimatedSprite bird5 = new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(206, 1827, 15, 25), 30f, 4, 99900, startingPosition, false, false, 0.01f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
						{
							rotation = -1.0471976f,
							layerDepth = 0f
						};
						bird5.motion = new Vector2(-4f, -0.5f);
						this.temporarySprites.Add(bird5);
					}
				}
				else if (Game1.timeOfDay >= 1900)
				{
					sourceRect = new Rectangle(640, 816, 16, 16);
					speed = -2f;
					loops = 0;
					startingPosition.X -= (float)Game1.random.Next(64, Game1.viewport.Width);
					if (localSeason == Season.Summer && Game1.dayOfMonth == 20)
					{
						int numExtra = Game1.random.Next(3);
						for (int k = 0; k < numExtra; k++)
						{
							TemporaryAnimatedSprite t = new TemporaryAnimatedSprite("LooseSprites\\Cursors", sourceRect, (float)Game1.random.Next(80, 121), 4, loops, startingPosition, false, false, 0.01f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
							{
								layerDepth = 0f
							};
							t.motion = new Vector2(speed, 0f);
							this.temporarySprites.Add(t);
							startingPosition.X -= (float)Game1.random.Next(64, Game1.viewport.Width);
							startingPosition.Y = (float)Game1.random.Next(0, 200);
						}
					}
					else if (Game1.season == Season.Winter)
					{
						if (Game1.timeOfDay >= 1700 && Game1.random.NextDouble() < 0.1)
						{
							sourceRect = new Rectangle(640, 800, 32, 16);
							loops = 1000;
							startingPosition.X = (float)Game1.viewport.Width;
						}
						else
						{
							sourceRect = Rectangle.Empty;
						}
					}
				}
				if (Game1.timeOfDay >= 2200 && Game1.season == Season.Summer && Game1.dayOfMonth == 20 && Game1.random.NextDouble() < 0.05)
				{
					sourceRect = new Rectangle(640, 784, 16, 16);
					loops = 200;
					startingPosition.X = (float)Game1.viewport.Width;
					speed = -3f;
				}
				if (sourceRect != Rectangle.Empty && Game1.viewport.X > -10000)
				{
					TemporaryAnimatedSprite t2 = new TemporaryAnimatedSprite("LooseSprites\\Cursors", sourceRect, animationSpeed, (localSeason == Season.Winter) ? 2 : 4, loops, startingPosition, false, false, 0.01f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
					{
						layerDepth = 0f
					};
					t2.motion = new Vector2(speed, 0f);
					this.temporarySprites.Add(t2);
				}
			}
			if (Game1.viewport.X > -10000)
			{
				foreach (TemporaryAnimatedSprite temporaryAnimatedSprite in this.temporarySprites)
				{
					temporaryAnimatedSprite.position.Y = temporaryAnimatedSprite.position.Y - ((float)Game1.viewport.Y - Game1.previousViewportPosition.Y) / 8f;
					temporaryAnimatedSprite.drawAboveAlwaysFront = true;
				}
			}
			if (Game1.eventUp)
			{
				using (IEnumerator<TemporaryAnimatedSprite> enumerator = this.temporarySprites.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						TemporaryAnimatedSprite temporaryAnimatedSprite2 = enumerator.Current;
						Character attachedCharacter = temporaryAnimatedSprite2.attachedCharacter;
						if (attachedCharacter != null)
						{
							attachedCharacter.animateInFacingDirection(time);
						}
					}
					return;
				}
			}
			this.isShowingEndSlideshow = false;
		}

		// Token: 0x0600324D RID: 12877 RVA: 0x00283BC8 File Offset: 0x00281DC8
		public override void cleanupBeforePlayerExit()
		{
			this.isShowingEndSlideshow = false;
			base.cleanupBeforePlayerExit();
			Game1.background = null;
			Game1.displayHUD = true;
			ICue cue = this.wind;
			if (cue == null)
			{
				return;
			}
			cue.Stop(AudioStopOptions.Immediate);
		}

		// Token: 0x0600324E RID: 12878 RVA: 0x00283BF4 File Offset: 0x00281DF4
		protected override void resetLocalState()
		{
			if (!Game1.player.team.farmPerfect.Value)
			{
				Game1.background = new Background(this);
				Game1.background.cursed = true;
				Game1.background.c = Color.Red;
				this.showQiCheatingEvent();
				return;
			}
			Game1.getAchievement(44, true);
			this.isShowingEndSlideshow = false;
			this.isOutdoors.Value = false;
			base.resetLocalState();
			Game1.background = new Background(this);
			this.temporarySprites.Clear();
			Game1.displayHUD = false;
			Game1.changeMusicTrack("winter_day_ambient", true, MusicContext.SubLocation);
			Game1.playSound("wind", out this.wind);
			this.globalWind = 0f;
			this.windGust = 0.001f;
			if (!Game1.player.mailReceived.Contains("Summit_event") && Game1.MasterPlayer.mailReceived.Contains("Farm_Eternal"))
			{
				string eventScript = this.getSummitEvent();
				if (eventScript != "")
				{
					Game1.player.songsHeard.Add("end_credits");
					Game1.player.mailReceived.Add("Summit_event");
					this.startEvent(new Event(eventScript, null));
				}
			}
		}

		// Token: 0x0600324F RID: 12879 RVA: 0x00283D2C File Offset: 0x00281F2C
		public string GetSummitDialogue(string file, string key)
		{
			NPC spouse = Game1.player.getSpouse();
			string asset_path = "Data\\" + file + ":" + key;
			if (!(((spouse != null) ? spouse.Name : null) == "Penny"))
			{
				return Game1.content.LoadString(asset_path, "");
			}
			return Game1.content.LoadString(asset_path, "요");
		}

		// Token: 0x06003250 RID: 12880 RVA: 0x00283D90 File Offset: 0x00281F90
		private void showQiCheatingEvent()
		{
			StringBuilder sb = new StringBuilder();
			if (Game1.player.mailReceived.Contains("summit_cheat_event"))
			{
				Game1.player.health = -1;
				return;
			}
			sb.Append("winter_day_ambient/-1000 -1000/farmer 9 23 0 MrQi 11 13 0/viewport 11 13 clamp true/move farmer 0 -10 0/faceDirection MrQi 3/speak MrQi \"");
			sb.Append(Game1.content.LoadString("Strings\\1_6_Strings:QiSummitCheat") + "\"/faceDirection MrQi 0/pause 1000/playMusic none/pause 1000/speed MrQi 8/move MrQi -1 0 3/faceDirection farmer 2 true/animate farmer false true 100 94/startJittering/viewport -1000 -1000 true/end qiSummitCheat");
			this.startEvent(new Event(sb.ToString(), null));
			Game1.player.mailReceived.Add("summit_cheat_event");
		}

		// Token: 0x06003251 RID: 12881 RVA: 0x00283E18 File Offset: 0x00282018
		private string getSummitEvent()
		{
			StringBuilder sb = new StringBuilder();
			try
			{
				sb.Append("winter_day_ambient/-1000 -1000/farmer 9 23 0 ");
				NPC spouse = Game1.player.getSpouse();
				if (spouse != null && spouse.Name != "Krobus")
				{
					string spouseName = spouse.Name;
					sb.Append(spouseName).Append(" 11 13 0/skippable/viewport 10 17 clamp true/pause 2000/viewport move 0 -1 4000/move farmer 0 -10 0/move farmer 1 0 0/pause 2000/speak ").Append(spouseName).Append(" \"").Append(this.GetSummitDialogue("ExtraDialogue", "SummitEvent_Intro_Spouse")).Append("\"/viewport move 0 -1 4000/pause 5000/speak ").Append(spouseName).Append(" \"").Append(this.GetSummitDialogue("ExtraDialogue", "SummitEvent_Intro2_Spouse" + (this.sayGrufferSummitIntro(spouse) ? "_Gruff" : ""))).Append("\"/pause 400/emote farmer 56/pause 2000/speak ").Append(spouseName).Append(" \"").Append(this.GetSummitDialogue("ExtraDialogue", "SummitEvent_Dialogue1_Spouse")).Append("\"/pause 1000/speak ").Append(spouseName).Append(" \"").Append(this.GetSummitDialogue("ExtraDialogue", "SummitEvent_Dialogue1B_Spouse")).Append("\"/pause 2000/faceDirection ").Append(spouseName).Append(" 3/faceDirection farmer 1/pause 1000/speak ").Append(spouseName).Append(" \"").Append(this.GetSummitDialogue("ExtraDialogue", "SummitEvent_Dialogue2_Spouse")).Append("\"/pause 2000/faceDirection ").Append(spouseName).Append(" 0/faceDirection farmer 0/pause 2000/speak ").Append(spouseName).Append(" \"").Append(this.GetSummitDialogue("ExtraDialogue", "SummitEvent_Dialogue3_" + spouseName));
					if (!sb.ToString()[sb.Length - 1].Equals('"'))
					{
						sb.Append("\"");
					}
					sb.Append("/emote farmer 20/pause 500/faceDirection farmer 1/faceDirection ").Append(spouseName).Append(" 3/pause 1500/animate farmer false true 100 101/showKissFrame ").Append(spouseName).Append("/playSound dwop/positionOffset farmer 8 0/positionOffset ").Append(spouseName).Append(" -4 0/specificTemporarySprite heart 11 12/pause 10");
				}
				else if (Game1.MasterPlayer.mailReceived.Contains("JojaMember"))
				{
					sb.Append("Morris 11 13 0/skippable/viewport 10 17 clamp true/pause 2000/viewport move 0 -1 4000/move farmer 0 -10 0/pause 2000/speak Morris \"").Append(this.GetSummitDialogue("ExtraDialogue", "SummitEvent_Intro_Morris")).Append("\"/viewport move 0 -1 4000/pause 5000/speak Morris \"").Append(this.GetSummitDialogue("ExtraDialogue", "SummitEvent_Dialogue1_Morris")).Append("\"/pause 2000/faceDirection Morris 3/speak Morris \"").Append(this.GetSummitDialogue("ExtraDialogue", "SummitEvent_Dialogue2_Morris")).Append("\"/pause 2000/faceDirection Morris 0/speak Morris \"").Append(this.GetSummitDialogue("ExtraDialogue", "SummitEvent_Outro_Morris")).Append("\"/emote farmer 20/pause 10");
				}
				else
				{
					sb.Append("Lewis 11 13 0/skippable/viewport 10 17 clamp true/pause 2000/viewport move 0 -1 4000/move farmer 0 -10 0/pause 2000/speak Lewis \"").Append(this.GetSummitDialogue("ExtraDialogue", "SummitEvent_Intro_Lewis")).Append("\"/viewport move 0 -1 4000/pause 5000/speak Lewis \"").Append(this.GetSummitDialogue("ExtraDialogue", "SummitEvent_Dialogue1_Lewis")).Append("\"/pause 2000/faceDirection Lewis 3/speak Lewis \"").Append(this.GetSummitDialogue("ExtraDialogue", "SummitEvent_Dialogue2_Lewis")).Append("\"/pause 2000/faceDirection Lewis 0/speak Lewis \"").Append(this.GetSummitDialogue("ExtraDialogue", "SummitEvent_Outro_Lewis")).Append("\"/pause 10");
				}
				int pauseTime = 35000;
				if (Game1.player.mailReceived.Contains("Capsule_Broken"))
				{
					pauseTime += 8000;
				}
				if (Game1.player.totalMoneyEarned >= 100000000U)
				{
					pauseTime += 8000;
				}
				if (Game1.year <= 2)
				{
					pauseTime += 8000;
				}
				sb.Append("/playMusic moonlightJellies/pause 2000/specificTemporarySprite krobusraven/viewport move 0 -1 12000/pause 10/pause ").Append(pauseTime).Append("/pause 2000/playMusic none/viewport move 0 -1 5000/fade/playMusic end_credits/viewport -8000 -8000 true/removeTemporarySprites/specificTemporarySprite getEndSlideshow/pause 1000/playMusic none/pause 500").Append("/playMusic grandpas_theme/pause 2000/fade/viewport -3000 -2000/specificTemporarySprite doneWithSlideShow/removeTemporarySprites/pause 3000/addTemporaryActor MrQi 16 32 -998 -1000 2 true/addTemporaryActor Grandpa 1 1 -100 -100 2 true/specificTemporarySprite grandpaSpirit/viewport -1000 -1000 true/pause 6000/spriteText 3 \"").Append(this.GetSummitDialogue("ExtraDialogue", "SummitEvent_closingmessage")).Append(" \"/spriteText 3 \"").Append(this.GetSummitDialogue("ExtraDialogue", "SummitEvent_closingmessage2")).Append(" \"/spriteText 3 \"").Append(this.GetSummitDialogue("ExtraDialogue", "SummitEvent_closingmessage3")).Append(" \"/spriteText 3 \"").Append(this.GetSummitDialogue("ExtraDialogue", "SummitEvent_closingmessage4")).Append(" \"/spriteText 7 \"").Append(this.GetSummitDialogue("ExtraDialogue", "SummitEvent_closingmessage5")).Append(" \"/pause 400/playSound dwop/showFrame MrQi 1/pause 100/showFrame MrQi 2/pause 100/showFrame MrQi 3/pause 400/specificTemporarySprite grandpaThumbsUp/pause 10000/end");
			}
			catch (Exception)
			{
				return "";
			}
			return sb.ToString();
		}

		// Token: 0x06003252 RID: 12882 RVA: 0x002842A0 File Offset: 0x002824A0
		public string getEndSlideshow()
		{
			StringBuilder sb = new StringBuilder();
			int i = 0;
			foreach (KeyValuePair<string, CharacterData> entry in Game1.characterData)
			{
				string name = entry.Key;
				CharacterData data = entry.Value;
				if (data.EndSlideShow == EndSlideShowBehavior.MainGroup && this.TryDrawNpc(name, data, 90, i))
				{
					i += 500;
				}
			}
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("Maps\\night_market_tilesheet_objects", new Rectangle(586, 119, 122, 28), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f - 392f), false, false, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 2000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("Maps\\night_market_tilesheet_objects", new Rectangle(586, 119, 122, 28), 900f, 1, 999999, new Vector2((float)(Game1.viewport.Width + 488), (float)Game1.viewport.Height * 0.5f - 392f), false, false, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 2000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("Maps\\night_market_tilesheet_objects", new Rectangle(586, 119, 122, 28), 900f, 1, 999999, new Vector2((float)(Game1.viewport.Width + 976), (float)Game1.viewport.Height * 0.5f - 392f), false, false, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 2000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("Maps\\night_market_tilesheet_objects", new Rectangle(586, 119, 122, 28), 900f, 1, 999999, new Vector2((float)(Game1.viewport.Width + 1464), (float)Game1.viewport.Height * 0.5f - 392f), false, false, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 2000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(324, 1936, 12, 20), 90f, 4, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.4f + 192f), false, false, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-4f, 0f),
				delayBeforeAnimationStart = 14000,
				startSound = "dogWhining"
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\Cursors2", new Rectangle(43, 80, 51, 56), 90f, 1, 999999, new Vector2((float)(Game1.viewport.Width / 2), (float)Game1.viewport.Height), false, false, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-1f, -4f),
				delayBeforeAnimationStart = 27000,
				startSound = "trashbear",
				drawAboveAlwaysFront = true
			});
			sb.Append("pause 10/spriteText 5 \"").Append(Utility.loadStringShort("UI", "EndCredit_Neighbors")).Append(" \"/pause 30000/");
			i += 4000;
			int oldTime = i;
			foreach (KeyValuePair<string, CharacterData> entry2 in Game1.characterData)
			{
				string name2 = entry2.Key;
				CharacterData data2 = entry2.Value;
				if (data2.EndSlideShow == EndSlideShowBehavior.TrailingGroup && this.TryDrawNpc(name2, data2, 120, i))
				{
					i += 500;
				}
			}
			i += 5000;
			sb.Append("spriteText 4 \"").Append(Utility.loadStringShort("UI", "EndCredit_Animals")).Append(" \"/pause ").Append(i - oldTime + 22000);
			oldTime = i;
			foreach (KeyValuePair<string, FarmAnimalData> pair in Game1.farmAnimalData)
			{
				string id = pair.Key;
				FarmAnimalData animal = pair.Value;
				if (animal.ShowInSummitCredits)
				{
					int width = animal.SpriteWidth;
					int height = animal.SpriteHeight;
					int animalWidth = 0;
					base.TemporarySprites.Add(new TemporaryAnimatedSprite(animal.Texture, new Rectangle(0, height, width, height), 120f, 4, 999999, new Vector2((float)Game1.viewport.Width, (float)((int)((float)Game1.viewport.Height * 0.5f - (float)(height * 4)))), false, true, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
					{
						motion = new Vector2(-3f, 0f),
						delayBeforeAnimationStart = i
					});
					animalWidth += width * 4;
					int extra = (width > 16) ? 4 : 0;
					if (animal.BabyTexture != null && animal.BabyTexture != animal.Texture)
					{
						for (int babyCount = 1; babyCount <= 2; babyCount++)
						{
							base.TemporarySprites.Add(new TemporaryAnimatedSprite(animal.BabyTexture, new Rectangle(0, height, width, height), 90f, 4, 999999, new Vector2((float)(Game1.viewport.Width + (width + 2 + extra) * babyCount * 4), (float)((int)((float)Game1.viewport.Height * 0.5f - (float)(height * 4)))), false, true, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
							{
								motion = new Vector2(-3f, 0f),
								delayBeforeAnimationStart = i
							});
						}
						animalWidth += (width + 2 + extra) * 4 * 2;
					}
					string displayName = TokenParser.ParseText(animal.DisplayName, null, null, null) ?? id;
					float displayNameWidth = Game1.dialogueFont.MeasureString(displayName).X;
					base.TemporarySprites.Add(new TemporaryAnimatedSprite(null, new Rectangle(0, height, width, height), 120f, 1, 999999, new Vector2((float)(Game1.viewport.Width + animalWidth / 2) - displayNameWidth / 2f, (float)((int)((float)Game1.viewport.Height * 0.5f + 12f))), false, true, 0.9f, 0f, Color.White, 1f, 0f, 0f, 0f, true)
					{
						motion = new Vector2(-3f, 0f),
						delayBeforeAnimationStart = i,
						text = displayName
					});
					i += 2000 + extra * 300;
				}
			}
			int pet_i = 0;
			foreach (Pet p in Utility.getAllPets())
			{
				PetData petData;
				if (Pet.TryGetData(p.petType.Value, out petData) && petData.SummitPerfectionEvent != null)
				{
					PetBreed breed = petData.GetBreedById(p.whichBreed.Value, false);
					PetSummitPerfectionEventData summitData = petData.SummitPerfectionEvent;
					base.TemporarySprites.Add(new TemporaryAnimatedSprite(breed.Texture, summitData.SourceRect, 90f, summitData.AnimationLength, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f - 320f + (float)(p.petType.Value.Equals("Dog") ? 96 : 0)), false, summitData.Flipped, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
					{
						motion = summitData.Motion,
						delayBeforeAnimationStart = 38000 + pet_i * 400,
						startSound = petData.BarkSound,
						pingPong = summitData.PingPong
					});
					pet_i++;
				}
				if (pet_i >= 20)
				{
					break;
				}
			}
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("Tilesheets\\critters", new Rectangle(64, 192, 32, 32), 90f, 6, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 128f), false, true, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-4f, 0f),
				delayBeforeAnimationStart = 45000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("Tilesheets\\critters", new Rectangle(128, 160, 32, 32), 90f, 6, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 128f), false, true, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-4f, 0f),
				delayBeforeAnimationStart = 47000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("Tilesheets\\critters", new Rectangle(128, 224, 32, 32), 90f, 6, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 128f), false, true, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-4f, 0f),
				delayBeforeAnimationStart = 48000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("Tilesheets\\critters", new Rectangle(32, 160, 32, 32), 90f, 3, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f - 320f), false, false, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-4f, 0f),
				delayBeforeAnimationStart = 49000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("Tilesheets\\critters", new Rectangle(32, 160, 32, 32), 90f, 3, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f - 288f), false, false, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-4f, 0f),
				delayBeforeAnimationStart = 49500,
				pingPong = true
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("Tilesheets\\critters", new Rectangle(34, 98, 32, 32), 90f, 3, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f - 352f), false, false, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-4f, 0f),
				delayBeforeAnimationStart = 50000,
				pingPong = true
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("Tilesheets\\critters", new Rectangle(0, 32, 32, 32), 90f, 4, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f - 352f), false, false, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-4f, 0f),
				delayBeforeAnimationStart = 50500,
				pingPong = true
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("Tilesheets\\critters", new Rectangle(128, 96, 16, 16), 90f, 4, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f - 352f), false, false, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-4f, 0f),
				delayBeforeAnimationStart = 55000,
				pingPong = true,
				yPeriodic = true,
				yPeriodicRange = 8f,
				yPeriodicLoopTime = 3000f
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("Tilesheets\\critters", new Rectangle(192, 96, 16, 16), 90f, 4, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f - 358.4f), false, false, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-4f, 0f),
				delayBeforeAnimationStart = 55300,
				pingPong = true,
				yPeriodic = true,
				yPeriodicRange = 8f,
				yPeriodicLoopTime = 3000f
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("Tilesheets\\critters", new Rectangle(256, 96, 16, 16), 90f, 4, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f - 345.6f), false, false, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-4f, 0f),
				delayBeforeAnimationStart = 55600,
				pingPong = true,
				yPeriodic = true,
				yPeriodicRange = 8f,
				yPeriodicLoopTime = 3000f
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("Tilesheets\\critters", new Rectangle(0, 128, 16, 16), 90f, 3, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f - 352f), false, false, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-4f, 0f),
				delayBeforeAnimationStart = 57000,
				pingPong = true,
				yPeriodic = true,
				yPeriodicRange = 8f,
				yPeriodicLoopTime = 3000f
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("Tilesheets\\critters", new Rectangle(48, 144, 16, 16), 90f, 3, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f - 358.4f), false, false, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-4f, 0f),
				delayBeforeAnimationStart = 57300,
				pingPong = true,
				yPeriodic = true,
				yPeriodicRange = 8f,
				yPeriodicLoopTime = 3000f
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("Tilesheets\\critters", new Rectangle(96, 144, 16, 16), 90f, 3, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f - 345.6f), false, false, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-4f, 0f),
				delayBeforeAnimationStart = 57600,
				pingPong = true,
				yPeriodic = true,
				yPeriodicRange = 8f,
				yPeriodicLoopTime = 3000f
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("Tilesheets\\critters", new Rectangle(192, 288, 16, 16), 90f, 4, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f - 345.6f), false, false, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-4f, 0f),
				delayBeforeAnimationStart = 58000,
				pingPong = true,
				yPeriodic = true,
				yPeriodicRange = 8f,
				yPeriodicLoopTime = 3000f
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("Tilesheets\\critters", new Rectangle(128, 288, 16, 16), 90f, 4, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f - 358.4f), false, false, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-4f, 0f),
				delayBeforeAnimationStart = 58300,
				pingPong = true,
				yPeriodic = true,
				yPeriodicRange = 8f,
				yPeriodicLoopTime = 3000f
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("Tilesheets\\critters", new Rectangle(0, 224, 16, 16), 90f, 5, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 64f), false, true, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 54000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("Tilesheets\\critters", new Rectangle(0, 240, 16, 16), 90f, 5, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 64f), false, true, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 55000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\temporary_sprites_1", new Rectangle(67, 190, 24, 51), 90f, 3, 999999, new Vector2((float)(Game1.viewport.Width / 2), (float)Game1.viewport.Height), false, false, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, -4f),
				delayBeforeAnimationStart = 68000,
				rotation = -0.19634955f,
				pingPong = true,
				drawAboveAlwaysFront = true
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\temporary_sprites_1", new Rectangle(0, 0, 57, 70), 150f, 2, 999999, new Vector2((float)(Game1.viewport.Width / 2), (float)Game1.viewport.Height), false, false, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, -4f),
				delayBeforeAnimationStart = 69000,
				rotation = -0.19634955f,
				drawAboveAlwaysFront = true
			});
			sb.Append("/spriteText 1 \"").Append(Utility.loadStringShort("UI", "EndCredit_Fish")).Append(" \"/pause ").Append(i - oldTime + 18000);
			i += 6000;
			oldTime = i;
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\temporary_sprites_1", new Rectangle(257, 98, 182, 18), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 72f), false, true, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 70000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\temporary_sprites_1", new Rectangle(257, 98, 182, 18), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 72f), false, true, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 86000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\temporary_sprites_1", new Rectangle(257, 98, 182, 18), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 72f), false, true, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 91000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\temporary_sprites_1", new Rectangle(140, 78, 28, 38), 250f, 2, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 152f), false, true, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 102000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\temporary_sprites_1", new Rectangle(257, 98, 182, 18), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 72f), false, true, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 75000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\AquariumFish", new Rectangle(0, 287, 47, 14), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 56f), false, true, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 82000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\AquariumFish", new Rectangle(0, 287, 47, 14), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 56f), false, true, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 80000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\AquariumFish", new Rectangle(0, 287, 47, 14), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 56f), false, true, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 84000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\temporary_sprites_1", new Rectangle(132, 20, 8, 8), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 48f), false, true, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 81500,
				yPeriodic = true,
				yPeriodicRange = 21f,
				yPeriodicLoopTime = 5000f
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\temporary_sprites_1", new Rectangle(140, 20, 8, 8), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 48f), false, true, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 83500,
				yPeriodic = true,
				yPeriodicRange = 21f,
				yPeriodicLoopTime = 5000f
			});
			Dictionary<string, string> dictionary = DataLoader.Fish(Game1.content);
			Dictionary<string, string> aquariumData = DataLoader.AquariumFish(Game1.content);
			int stack = 0;
			foreach (KeyValuePair<string, string> v in dictionary)
			{
				try
				{
					string fishId = v.Key;
					string rawAquariumEntry;
					if (aquariumData.TryGetValue(fishId, out rawAquariumEntry))
					{
						ParsedItemData data3 = ItemRegistry.GetData("(O)" + fishId);
						string fishName = ((data3 != null) ? data3.DisplayName : null) ?? ArgUtility.SplitBySpaceAndGet(v.Value, 0, null);
						string[] array = rawAquariumEntry.Split('/', StringSplitOptions.None);
						string aquariumTextureName = ArgUtility.Get(array, 6, "LooseSprites\\AquariumFish", false);
						int aquariumIndex = ArgUtility.GetInt(array, 0, 0);
						Rectangle source = new Rectangle(24 * aquariumIndex % 480, 24 * aquariumIndex / 480 * 48, 24, 24);
						float textWidth = Game1.dialogueFont.MeasureString(fishName).X;
						base.TemporarySprites.Add(new TemporaryAnimatedSprite(aquariumTextureName, source, 9999f, 1, 999999, new Vector2((float)(Game1.viewport.Width + 192), (float)((int)((float)Game1.viewport.Height * 0.53f - (float)(stack * 64) * 2f))), false, true, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
						{
							motion = new Vector2(-3f, 0f),
							delayBeforeAnimationStart = i,
							yPeriodic = true,
							yPeriodicLoopTime = (float)Game1.random.Next(1500, 2100),
							yPeriodicRange = 4f
						});
						base.TemporarySprites.Add(new TemporaryAnimatedSprite(aquariumTextureName, source, 9999f, 1, 999999, new Vector2((float)(Game1.viewport.Width + 192 + 48) - textWidth / 2f, (float)((int)((float)Game1.viewport.Height * 0.53f - (float)(stack * 64) * 2f + 64f + 16f))), false, true, 0.9f, 0f, Color.White, 1f, 0f, 0f, 0f, true)
						{
							motion = new Vector2(-3f, 0f),
							delayBeforeAnimationStart = i,
							text = fishName
						});
						stack++;
						if (stack == 4)
						{
							i += 2000;
							stack = 0;
						}
					}
				}
				catch (Exception ex)
				{
					Game1.log.Error("Couldn't add fish '" + v.Key + "' to summit event credits.", ex);
				}
			}
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("Tilesheets\\projectiles", new Rectangle(64, 0, 16, 16), 909f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f - 352f), false, false, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-6f, 0f),
				delayBeforeAnimationStart = 123000,
				rotationChange = -0.1f
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("Tilesheets\\projectiles", new Rectangle(64, 0, 16, 16), 909f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f - 339.2f), false, false, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-6f, 0f),
				delayBeforeAnimationStart = 123300,
				rotationChange = -0.1f
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(0, 1452, 640, 69), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f - 392f), false, false, 0.2f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 108000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(0, 1452, 640, 69), 900f, 1, 999999, new Vector2((float)(Game1.viewport.Width + 2564), (float)Game1.viewport.Height * 0.5f - 392f), false, false, 0.2f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 108000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(0, 1452, 640, 69), 900f, 1, 999999, new Vector2((float)(Game1.viewport.Width + 5128), (float)Game1.viewport.Height * 0.5f - 392f), false, false, 0.2f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 108000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(0, 1452, 300, 69), 900f, 1, 999999, new Vector2((float)(Game1.viewport.Width + 7692), (float)Game1.viewport.Height * 0.5f - 392f), false, false, 0.2f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 108000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("TileSheets\\bushes", new Rectangle(0, 0, 31, 29), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 116f), false, false, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 110000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("TileSheets\\bushes", new Rectangle(65, 0, 31, 29), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 116f), false, false, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 115000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("TileSheets\\bushes", new Rectangle(96, 90, 31, 29), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 116f), false, false, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 118000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("TileSheets\\bushes", new Rectangle(0, 176, 104, 29), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 116f), false, false, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 121000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("TileSheets\\bushes", new Rectangle(32, 320, 32, 23), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 92f), false, false, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 124000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("TileSheets\\bushes", new Rectangle(31, 58, 67, 23), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 92f), false, false, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 127000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("TileSheets\\bushes", new Rectangle(0, 98, 32, 23), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 92f), false, false, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 132000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("TileSheets\\bushes", new Rectangle(49, 131, 47, 29), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 116f), false, false, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 137000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("TerrainFeatures\\grass", new Rectangle(0, 0, 44, 13), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 52f), false, false, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 113000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("TerrainFeatures\\grass", new Rectangle(0, 20, 44, 13), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 52f), false, false, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 116000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("TerrainFeatures\\grass", new Rectangle(0, 40, 44, 13), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 52f), false, false, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 119000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("TerrainFeatures\\grass", new Rectangle(0, 60, 44, 13), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 52f), false, false, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 126000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("TerrainFeatures\\grass", new Rectangle(0, 120, 44, 13), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 52f), false, false, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 129000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("TerrainFeatures\\grass", new Rectangle(0, 100, 44, 13), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 52f), false, false, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 134000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("TerrainFeatures\\grass", new Rectangle(0, 120, 44, 13), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 52f), false, false, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 139000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("TerrainFeatures\\upperCavePlants", new Rectangle(0, 0, 48, 21), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 84f), false, false, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 142000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("TerrainFeatures\\upperCavePlants", new Rectangle(96, 0, 48, 21), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 84f), false, false, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 146000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\temporary_sprites_1", new Rectangle(2, 123, 19, 24), 90f, 4, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f - 352f), false, true, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-4f, 0f),
				delayBeforeAnimationStart = 145000,
				yPeriodic = true,
				yPeriodicRange = 8f,
				yPeriodicLoopTime = 2500f
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\temporary_sprites_1", new Rectangle(2, 123, 19, 24), 100f, 4, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f - 358.4f), false, true, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-4f, 0f),
				delayBeforeAnimationStart = 142500,
				yPeriodic = true,
				yPeriodicRange = 8f,
				yPeriodicLoopTime = 2000f
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("TileSheets\\bushes", new Rectangle(0, 0, 31, 29), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 116f), false, false, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 149000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("TileSheets\\bushes", new Rectangle(65, 0, 31, 29), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 116f), false, false, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 151000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("TileSheets\\bushes", new Rectangle(96, 90, 31, 29), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 116f), false, false, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 154000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("TileSheets\\bushes", new Rectangle(0, 176, 104, 29), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 116f), false, false, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 156000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("TerrainFeatures\\grass", new Rectangle(0, 0, 44, 13), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 52f), false, false, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 155000
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("TerrainFeatures\\grass", new Rectangle(0, 20, 44, 13), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 52f), false, false, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 152500
			});
			base.TemporarySprites.Add(new TemporaryAnimatedSprite("TerrainFeatures\\grass", new Rectangle(0, 40, 44, 13), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f + 240f - 52f), false, false, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
			{
				motion = new Vector2(-3f, 0f),
				delayBeforeAnimationStart = 158000
			});
			if (Game1.player.favoriteThing.Value.EqualsIgnoreCase("concernedape"))
			{
				base.TemporarySprites.Add(new TemporaryAnimatedSprite("Minigames\\Clouds", new Rectangle(210, 842, 138, 130), 900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.5f - 240f), false, false, 0.7f, 0f, Color.White, 3f, 0f, 0f, 0f, true)
				{
					motion = new Vector2(-3f, 0f),
					delayBeforeAnimationStart = 160000,
					startSound = "discoverMineral"
				});
			}
			if (!Utility.hasFinishedJojaRoute() && Game1.netWorldState.Value.PerfectionWaivers == 0 && !Game1.netWorldState.Value.ActivatedGoldenParrot)
			{
				base.TemporarySprites.Add(new TemporaryAnimatedSprite("Characters\\Morris", new Rectangle(48, 128, 16, 32), 9900f, 1, 999999, new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height), false, false, 0.7f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
				{
					motion = new Vector2(-7f, -4f),
					delayBeforeAnimationStart = 168500,
					startSound = "slimeHit",
					rotationChange = 0.05f
				});
				base.TemporarySprites.Add(new TemporaryAnimatedSprite
				{
					text = Game1.content.LoadString("Strings\\1_6_Strings:JojaFreeRun"),
					color = Color.Lime,
					position = new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height) / 2f,
					interval = 3000f,
					totalNumberOfLoops = 1,
					animationLength = 1,
					delayBeforeAnimationStart = 169500,
					layerDepth = 0.71f,
					local = true
				});
			}
			sb.Append("/spriteText 2 \"").Append(Utility.loadStringShort("UI", "EndCredit_Monsters")).Append(" \"/pause ").Append(i - oldTime + 19000);
			i += 6000;
			oldTime = i;
			foreach (KeyValuePair<string, string> v2 in DataLoader.Monsters(Game1.content))
			{
				if (!(v2.Key == "Fireball") && !(v2.Key == "Skeleton Warrior"))
				{
					int spriteHeight = 16;
					int spriteWidth = 16;
					int spriteStartIndex = 0;
					int animationLength = 4;
					bool pingpong = false;
					int yOffset = 0;
					Character attachedCharacter = null;
					if (v2.Key.Contains("Bat") || v2.Key.Contains("Ghost"))
					{
						spriteHeight = 24;
					}
					string key = v2.Key;
					if (key != null)
					{
						switch (key.Length)
						{
						case 3:
							switch (key[0])
							{
							case 'B':
							{
								if (!(key == "Bat"))
								{
									goto IL_4C20;
								}
								Texture2D t = Game1.content.Load<Texture2D>("Characters\\Monsters\\Frost Bat");
								base.TemporarySprites.Add(new TemporaryAnimatedSprite(null, new Rectangle(spriteWidth * spriteStartIndex % t.Width, spriteWidth * spriteStartIndex / t.Width * spriteHeight, spriteWidth, spriteHeight), 100f, animationLength, 999999, new Vector2((float)(Game1.viewport.Width + 192), (float)Game1.viewport.Height * 0.5f - (float)(spriteHeight * 4) - 16f), false, true, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
								{
									motion = new Vector2(-3f, 0f),
									delayBeforeAnimationStart = i,
									yPeriodic = (animationLength == 1),
									yPeriodicRange = 16f,
									yPeriodicLoopTime = 3000f,
									attachedCharacter = attachedCharacter,
									texture = t
								});
								t = Game1.content.Load<Texture2D>("Characters\\Monsters\\Lava Bat");
								spriteHeight = 24;
								base.TemporarySprites.Add(new TemporaryAnimatedSprite(null, new Rectangle(spriteWidth * spriteStartIndex % t.Width, spriteWidth * spriteStartIndex / t.Width * spriteHeight, spriteWidth, spriteHeight), 100f, animationLength, 999999, new Vector2((float)Game1.viewport.Width + 96f, (float)Game1.viewport.Height * 0.5f - (float)(spriteHeight * 4) - 16f), false, true, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
								{
									motion = new Vector2(-3f, 0f),
									delayBeforeAnimationStart = i,
									yPeriodic = (animationLength == 1),
									yPeriodicRange = 16f,
									yPeriodicLoopTime = 3000f,
									attachedCharacter = attachedCharacter,
									texture = t
								});
								t = Game1.content.Load<Texture2D>("Characters\\Monsters\\Iridium Bat");
								base.TemporarySprites.Add(new TemporaryAnimatedSprite(null, new Rectangle(spriteWidth * spriteStartIndex % t.Width, spriteWidth * spriteStartIndex / t.Width * spriteHeight, spriteWidth, spriteHeight), 100f, animationLength, 999999, new Vector2((float)Game1.viewport.Width + 288f, (float)Game1.viewport.Height * 0.5f - (float)(spriteHeight * 4) - 16f), false, true, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
								{
									motion = new Vector2(-3f, 0f),
									delayBeforeAnimationStart = i,
									yPeriodic = (animationLength == 1),
									yPeriodicRange = 16f,
									yPeriodicLoopTime = 3000f,
									attachedCharacter = attachedCharacter,
									texture = t
								});
								base.TemporarySprites.Add(new TemporaryAnimatedSprite(null, new Rectangle(spriteWidth * spriteStartIndex % t.Width, spriteWidth * spriteStartIndex / t.Width * spriteHeight, spriteWidth, spriteHeight), 100f, animationLength, 999999, new Vector2((float)(Game1.viewport.Width + 128 + spriteWidth * 4 / 2) - Game1.dialogueFont.MeasureString(v2.Value.Split('/', StringSplitOptions.None)[14]).X / 2f, (float)Game1.viewport.Height * 0.5f), false, false, 0.9f, 0f, Color.White, 1f, 0f, 0f, 0f, true)
								{
									motion = new Vector2(-3f, 0f),
									delayBeforeAnimationStart = i,
									text = Utility.loadStringShort("UI", "EndCredit_Bats")
								});
								i += 1500;
								continue;
							}
							case 'C':
								if (!(key == "Cat"))
								{
									goto IL_4C20;
								}
								continue;
							case 'D':
							case 'E':
								goto IL_4C20;
							case 'F':
								if (!(key == "Fly"))
								{
									goto IL_4C20;
								}
								break;
							default:
								goto IL_4C20;
							}
							break;
						case 4:
							switch (key[0])
							{
							case 'C':
								if (!(key == "Crow"))
								{
									goto IL_4C20;
								}
								continue;
							case 'D':
							case 'E':
								goto IL_4C20;
							case 'F':
								if (!(key == "Frog"))
								{
									goto IL_4C20;
								}
								continue;
							case 'G':
								if (!(key == "Grub"))
								{
									goto IL_4C20;
								}
								break;
							default:
								goto IL_4C20;
							}
							break;
						case 5:
						{
							char c = key[0];
							if (c != 'D')
							{
								if (c != 'G')
								{
									if (c != 'M')
									{
										goto IL_4C20;
									}
									if (!(key == "Mummy"))
									{
										goto IL_4C20;
									}
									goto IL_3E14;
								}
								else
								{
									if (!(key == "Ghost"))
									{
										goto IL_4C20;
									}
									goto IL_3E0C;
								}
							}
							else if (!(key == "Duggy"))
							{
								goto IL_4C20;
							}
							break;
						}
						case 6:
						{
							char c = key[1];
							if (c != 'l')
							{
								if (c != 'p')
								{
									goto IL_4C20;
								}
								if (key == "Spider")
								{
									spriteWidth = 32;
									spriteHeight = 32;
									animationLength = 2;
									goto IL_4C20;
								}
								if (!(key == "Spiker"))
								{
									goto IL_4C20;
								}
								goto IL_3E0C;
							}
							else
							{
								if (!(key == "Sludge"))
								{
									goto IL_4C20;
								}
								continue;
							}
							break;
						}
						case 7:
							if (!(key == "Serpent"))
							{
								goto IL_4C20;
							}
							spriteWidth = 32;
							spriteHeight = 32;
							animationLength = 5;
							goto IL_4C20;
						case 8:
						{
							char c = key[0];
							if (c != 'L')
							{
								if (c != 'S')
								{
									goto IL_4C20;
								}
								if (!(key == "Skeleton"))
								{
									goto IL_4C20;
								}
								goto IL_3E14;
							}
							else
							{
								if (!(key == "Lava Bat"))
								{
									goto IL_4C20;
								}
								continue;
							}
							break;
						}
						case 9:
						{
							char c = key[0];
							if (c <= 'F')
							{
								if (c != 'B')
								{
									if (c != 'F')
									{
										goto IL_4C20;
									}
									if (!(key == "Frost Bat"))
									{
										goto IL_4C20;
									}
									continue;
								}
								else
								{
									if (!(key == "Big Slime"))
									{
										goto IL_4C20;
									}
									spriteHeight = 32;
									spriteWidth = 32;
									yOffset = 64;
									attachedCharacter = new BigSlime(Vector2.Zero, 0);
									goto IL_4C20;
								}
							}
							else if (c != 'L')
							{
								if (c != 'R')
								{
									goto IL_4C20;
								}
								if (!(key == "Rock Crab"))
								{
									goto IL_4C20;
								}
							}
							else if (!(key == "Lava Crab"))
							{
								if (!(key == "Lava Lurk"))
								{
									goto IL_4C20;
								}
								spriteStartIndex = 4;
								pingpong = true;
								goto IL_4C20;
							}
							break;
						}
						case 10:
						{
							char c = key[0];
							if (c != 'B')
							{
								if (c != 'P')
								{
									if (c != 'S')
									{
										goto IL_4C20;
									}
									if (!(key == "Shadow Guy"))
									{
										goto IL_4C20;
									}
									spriteHeight = 32;
									spriteStartIndex = 4;
									Texture2D t2 = Game1.content.Load<Texture2D>("Characters\\Monsters\\Shadow Brute");
									base.TemporarySprites.Add(new TemporaryAnimatedSprite(null, new Rectangle(spriteWidth * spriteStartIndex % t2.Width, spriteWidth * spriteStartIndex / t2.Width * spriteHeight, spriteWidth, spriteHeight), 100f, animationLength, 999999, new Vector2((float)(Game1.viewport.Width + 192), (float)Game1.viewport.Height * 0.5f - (float)(spriteHeight * 4) - 16f), false, true, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
									{
										motion = new Vector2(-3f, 0f),
										delayBeforeAnimationStart = i,
										yPeriodic = (animationLength == 1),
										yPeriodicRange = 16f,
										yPeriodicLoopTime = 3000f,
										attachedCharacter = attachedCharacter,
										texture = t2
									});
									t2 = Game1.content.Load<Texture2D>("Characters\\Monsters\\Shadow Shaman");
									spriteHeight = 24;
									base.TemporarySprites.Add(new TemporaryAnimatedSprite(null, new Rectangle(spriteWidth * spriteStartIndex % t2.Width, spriteWidth * spriteStartIndex / t2.Width * spriteHeight, spriteWidth, spriteHeight), 100f, animationLength, 999999, new Vector2((float)Game1.viewport.Width + 96f, (float)Game1.viewport.Height * 0.5f - (float)(spriteHeight * 4) - 16f), false, true, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
									{
										motion = new Vector2(-3f, 0f),
										delayBeforeAnimationStart = i,
										yPeriodic = (animationLength == 1),
										yPeriodicRange = 16f,
										yPeriodicLoopTime = 3000f,
										attachedCharacter = attachedCharacter,
										texture = t2
									});
									t2 = Game1.content.Load<Texture2D>("Characters\\Monsters\\Shadow Sniper");
									spriteHeight = 32;
									spriteWidth = 32;
									base.TemporarySprites.Add(new TemporaryAnimatedSprite(null, new Rectangle(spriteWidth * spriteStartIndex % t2.Width, spriteWidth * spriteStartIndex / t2.Width * spriteHeight, spriteWidth, spriteHeight), 100f, animationLength, 999999, new Vector2((float)Game1.viewport.Width + 288f, (float)Game1.viewport.Height * 0.5f - (float)(spriteHeight * 4) - 16f), false, true, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
									{
										motion = new Vector2(-3f, 0f),
										delayBeforeAnimationStart = i,
										yPeriodic = (animationLength == 1),
										yPeriodicRange = 16f,
										yPeriodicLoopTime = 3000f,
										attachedCharacter = attachedCharacter,
										texture = t2
									});
									base.TemporarySprites.Add(new TemporaryAnimatedSprite(null, new Rectangle(spriteWidth * spriteStartIndex % t2.Width, spriteWidth * spriteStartIndex / t2.Width * spriteHeight, spriteWidth, spriteHeight), 100f, animationLength, 999999, new Vector2((float)(Game1.viewport.Width + 128 + spriteWidth * 4 / 2) - Game1.dialogueFont.MeasureString(v2.Value.Split('/', StringSplitOptions.None)[14]).X / 2f, (float)Game1.viewport.Height * 0.5f), false, false, 0.9f, 0f, Color.White, 1f, 0f, 0f, 0f, true)
									{
										motion = new Vector2(-3f, 0f),
										delayBeforeAnimationStart = i,
										text = Utility.loadStringShort("UI", "EndCredit_ShadowPeople")
									});
									i += 1500;
									continue;
								}
								else
								{
									if (!(key == "Pepper Rex"))
									{
										goto IL_4C20;
									}
									spriteWidth = 32;
									spriteHeight = 32;
									goto IL_4C20;
								}
							}
							else
							{
								if (!(key == "Blue Squid"))
								{
									goto IL_4C20;
								}
								spriteWidth = 24;
								spriteHeight = 24;
								animationLength = 5;
								goto IL_4C20;
							}
							break;
						}
						case 11:
						{
							char c = key[0];
							if (c <= 'M')
							{
								switch (c)
								{
								case 'D':
									if (!(key == "Dust Spirit"))
									{
										goto IL_4C20;
									}
									goto IL_3D8F;
								case 'E':
								case 'H':
									goto IL_4C20;
								case 'F':
									if (!(key == "Frost Jelly"))
									{
										goto IL_4C20;
									}
									continue;
								case 'G':
								{
									if (!(key == "Green Slime"))
									{
										goto IL_4C20;
									}
									Texture2D t3 = null;
									if (attachedCharacter == null)
									{
										t3 = Game1.content.Load<Texture2D>("Characters\\Monsters\\Green Slime");
									}
									spriteHeight = 32;
									spriteStartIndex = 4;
									GreenSlime slime = new GreenSlime(Vector2.Zero, 0);
									base.TemporarySprites.Add(new TemporaryAnimatedSprite(null, new Rectangle(spriteWidth * spriteStartIndex % t3.Width, spriteWidth * spriteStartIndex / t3.Width * spriteHeight, spriteWidth, spriteHeight), 100f, animationLength, 999999, new Vector2((float)(Game1.viewport.Width + 192 - 64), (float)Game1.viewport.Height * 0.5f - (float)(spriteHeight * 4) + 32f), false, true, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
									{
										motion = new Vector2(-3f, 0f),
										delayBeforeAnimationStart = i,
										yPeriodic = (animationLength == 1),
										yPeriodicRange = 16f,
										yPeriodicLoopTime = 3000f,
										attachedCharacter = slime,
										texture = null
									});
									slime = new GreenSlime(Vector2.Zero, 41);
									base.TemporarySprites.Add(new TemporaryAnimatedSprite(null, new Rectangle(spriteWidth * spriteStartIndex % t3.Width, spriteWidth * spriteStartIndex / t3.Width * spriteHeight, spriteWidth, spriteHeight), 100f, animationLength, 999999, new Vector2((float)Game1.viewport.Width + 96f - 64f, (float)Game1.viewport.Height * 0.5f - (float)(spriteHeight * 4) + 32f), false, true, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
									{
										motion = new Vector2(-3f, 0f),
										delayBeforeAnimationStart = i,
										yPeriodic = (animationLength == 1),
										yPeriodicRange = 16f,
										yPeriodicLoopTime = 3000f,
										attachedCharacter = slime,
										texture = null
									});
									slime = new GreenSlime(Vector2.Zero, 81);
									base.TemporarySprites.Add(new TemporaryAnimatedSprite(null, new Rectangle(spriteWidth * spriteStartIndex % t3.Width, spriteWidth * spriteStartIndex / t3.Width * spriteHeight, spriteWidth, spriteHeight), 100f, animationLength, 999999, new Vector2((float)Game1.viewport.Width + 288f - 64f, (float)Game1.viewport.Height * 0.5f - (float)(spriteHeight * 4) + 32f), false, true, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
									{
										motion = new Vector2(-3f, 0f),
										delayBeforeAnimationStart = i,
										yPeriodic = (animationLength == 1),
										yPeriodicRange = 16f,
										yPeriodicLoopTime = 3000f,
										attachedCharacter = slime,
										texture = null
									});
									slime = new GreenSlime(Vector2.Zero, 121);
									base.TemporarySprites.Add(new TemporaryAnimatedSprite(null, new Rectangle(spriteWidth * spriteStartIndex % t3.Width, spriteWidth * spriteStartIndex / t3.Width * spriteHeight, spriteWidth, spriteHeight), 100f, animationLength, 999999, new Vector2((float)Game1.viewport.Width + 240f - 64f, (float)Game1.viewport.Height * 0.5f - (float)(spriteHeight * 4 * 2) + 32f), false, true, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
									{
										motion = new Vector2(-3f, 0f),
										delayBeforeAnimationStart = i,
										yPeriodic = (animationLength == 1),
										yPeriodicRange = 16f,
										yPeriodicLoopTime = 3000f,
										attachedCharacter = slime,
										texture = null
									});
									slime = new GreenSlime(Vector2.Zero, 0);
									slime.makeTigerSlime(false);
									base.TemporarySprites.Add(new TemporaryAnimatedSprite(null, new Rectangle(spriteWidth * spriteStartIndex % t3.Width, spriteWidth * spriteStartIndex / t3.Width * spriteHeight, spriteWidth, spriteHeight), 100f, animationLength, 999999, new Vector2((float)Game1.viewport.Width + 144f - 64f, (float)Game1.viewport.Height * 0.5f - (float)(spriteHeight * 4 * 2) + 32f), false, true, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
									{
										motion = new Vector2(-3f, 0f),
										delayBeforeAnimationStart = i,
										yPeriodic = (animationLength == 1),
										yPeriodicRange = 16f,
										yPeriodicLoopTime = 3000f,
										attachedCharacter = slime,
										texture = null
									});
									base.TemporarySprites.Add(new TemporaryAnimatedSprite(null, new Rectangle(spriteWidth * spriteStartIndex % t3.Width, spriteWidth * spriteStartIndex / t3.Width * spriteHeight, spriteWidth, spriteHeight), 100f, animationLength, 999999, new Vector2((float)(Game1.viewport.Width + 192 + spriteWidth * 4 / 2) - Game1.dialogueFont.MeasureString(v2.Value.Split('/', StringSplitOptions.None)[14]).X / 2f, (float)Game1.viewport.Height * 0.5f), false, false, 0.9f, 0f, Color.White, 1f, 0f, 0f, 0f, true)
									{
										motion = new Vector2(-3f, 0f),
										delayBeforeAnimationStart = i,
										text = Utility.loadStringShort("UI", "EndCredit_Slimes")
									});
									i += 1500;
									continue;
								}
								case 'I':
									if (!(key == "Iridium Bat"))
									{
										goto IL_4C20;
									}
									continue;
								default:
									if (c != 'M')
									{
										goto IL_4C20;
									}
									if (!(key == "Magma Duggy"))
									{
										goto IL_4C20;
									}
									break;
								}
							}
							else if (c != 'S')
							{
								if (c != 'T')
								{
									goto IL_4C20;
								}
								if (!(key == "Tiger Slime"))
								{
									goto IL_4C20;
								}
								continue;
							}
							else if (!(key == "Stone Golem"))
							{
								goto IL_4C20;
							}
							break;
						}
						case 12:
						{
							char c = key[0];
							if (c <= 'I')
							{
								if (c != 'C')
								{
									if (c != 'I')
									{
										goto IL_4C20;
									}
									if (!(key == "Iridium Crab"))
									{
										goto IL_4C20;
									}
								}
								else
								{
									if (!(key == "Carbon Ghost"))
									{
										goto IL_4C20;
									}
									goto IL_3E0C;
								}
							}
							else if (c != 'M')
							{
								if (c != 'P')
								{
									if (c != 'S')
									{
										goto IL_4C20;
									}
									if (!(key == "Shadow Brute"))
									{
										goto IL_4C20;
									}
									continue;
								}
								else
								{
									if (!(key == "Putrid Ghost"))
									{
										goto IL_4C20;
									}
									goto IL_3E0C;
								}
							}
							else
							{
								if (!(key == "Magma Sprite"))
								{
									goto IL_4C20;
								}
								goto IL_3DB3;
							}
							break;
						}
						case 13:
						{
							char c = key[8];
							if (c <= 'a')
							{
								if (c != ' ')
								{
									if (c != 'S')
									{
										if (c != 'a')
										{
											goto IL_4C20;
										}
										if (!(key == "Magma Sparker"))
										{
											goto IL_4C20;
										}
										goto IL_3DB3;
									}
									else
									{
										if (!(key == "Iridium Slime"))
										{
											goto IL_4C20;
										}
										continue;
									}
								}
								else
								{
									if (!(key == "Skeleton Mage"))
									{
										goto IL_4C20;
									}
									goto IL_3E14;
								}
							}
							else if (c != 'h')
							{
								if (c != 'n')
								{
									if (c != 'r')
									{
										goto IL_4C20;
									}
									if (!(key == "Royal Serpent"))
									{
										goto IL_4C20;
									}
									continue;
								}
								else
								{
									if (!(key == "Shadow Sniper"))
									{
										goto IL_4C20;
									}
									continue;
								}
							}
							else
							{
								if (!(key == "Shadow Shaman"))
								{
									goto IL_4C20;
								}
								continue;
							}
							break;
						}
						case 14:
							goto IL_4C20;
						case 15:
						{
							char c = key[0];
							if (c != 'D')
							{
								if (c != 'F')
								{
									goto IL_4C20;
								}
								if (!(key == "False Magma Cap"))
								{
									goto IL_4C20;
								}
								goto IL_3D8F;
							}
							else
							{
								if (!(key == "Dwarvish Sentry"))
								{
									goto IL_4C20;
								}
								goto IL_3E0C;
							}
							break;
						}
						case 16:
							if (!(key == "Wilderness Golem"))
							{
								goto IL_4C20;
							}
							break;
						default:
							goto IL_4C20;
						}
						spriteHeight = 24;
						spriteStartIndex = 4;
						goto IL_4C20;
						IL_3D8F:
						spriteHeight = 24;
						spriteStartIndex = 0;
						goto IL_4C20;
						IL_3DB3:
						animationLength = 7;
						spriteStartIndex = 7;
						goto IL_4C20;
						IL_3E0C:
						animationLength = 1;
						goto IL_4C20;
						IL_3E14:
						spriteHeight = 32;
						spriteStartIndex = 4;
					}
					IL_4C20:
					try
					{
						Texture2D t4 = (attachedCharacter == null) ? Game1.content.Load<Texture2D>("Characters\\Monsters\\" + v2.Key) : attachedCharacter.Sprite.Texture;
						base.TemporarySprites.Add(new TemporaryAnimatedSprite(null, new Rectangle(spriteWidth * spriteStartIndex % t4.Width, spriteWidth * spriteStartIndex / t4.Width * spriteHeight + 1, spriteWidth, spriteHeight - 1), 100f, animationLength, 999999, new Vector2((float)(Game1.viewport.Width + 192), (float)Game1.viewport.Height * 0.5f - (float)(spriteHeight * 4) - 16f + (float)yOffset), false, true, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
						{
							motion = new Vector2(-3f, 0f),
							delayBeforeAnimationStart = i,
							yPeriodic = (animationLength == 1),
							yPeriodicRange = 16f,
							yPeriodicLoopTime = 3000f,
							attachedCharacter = attachedCharacter,
							texture = ((attachedCharacter == null) ? t4 : null),
							pingPong = pingpong
						});
						base.TemporarySprites.Add(new TemporaryAnimatedSprite(null, new Rectangle(spriteWidth * spriteStartIndex % t4.Width, spriteWidth * spriteStartIndex / t4.Width * spriteHeight, spriteWidth, spriteHeight), 100f, animationLength, 999999, new Vector2((float)(Game1.viewport.Width + 192 + spriteWidth * 4 / 2) - Game1.dialogueFont.MeasureString(Game1.parseText(v2.Value.Split('/', StringSplitOptions.None)[14], Game1.dialogueFont, 256)).X / 2f, (float)Game1.viewport.Height * 0.5f), false, false, 0.9f, 0f, Color.White, 1f, 0f, 0f, 0f, true)
						{
							motion = new Vector2(-3f, 0f),
							delayBeforeAnimationStart = i,
							text = Game1.parseText(v2.Value.Split('/', StringSplitOptions.None)[14], Game1.dialogueFont, 256)
						});
						i += 1500;
					}
					catch
					{
					}
				}
			}
			return sb.ToString();
		}

		// Token: 0x06003253 RID: 12883 RVA: 0x00289204 File Offset: 0x00287404
		public bool TryDrawNpc(string name, CharacterData data, int animationInterval, int delayBeforeAnimationStart)
		{
			bool result;
			try
			{
				string texName = NPC.getTextureNameForCharacter(name);
				Rectangle sourceRect = new Rectangle(0, data.Size.Y * 3, data.Size.X, data.Size.Y);
				Vector2 position = new Vector2((float)Game1.viewport.Width, (float)Game1.viewport.Height * 0.4f + (float)((32 - sourceRect.Height) * 4));
				base.TemporarySprites.Add(new TemporaryAnimatedSprite("Characters\\" + texName, sourceRect, 90f, 4, 999999, position, false, false, 0.9f, 0f, Color.White, 4f, 0f, 0f, 0f, true)
				{
					motion = new Vector2(-3f, 0f),
					delayBeforeAnimationStart = delayBeforeAnimationStart
				});
				result = true;
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06003254 RID: 12884 RVA: 0x002892F8 File Offset: 0x002874F8
		private bool sayGrufferSummitIntro(NPC spouse)
		{
			string value = spouse.name.Value;
			return !(value == "Harvey") && !(value == "Elliott") && (value == "Abigail" || value == "Maru" || spouse.Gender == Gender.Male);
		}

		// Token: 0x06003255 RID: 12885 RVA: 0x00289354 File Offset: 0x00287554
		public override void drawAboveAlwaysFrontLayer(SpriteBatch b)
		{
			base.drawAboveAlwaysFrontLayer(b);
			if (Game1.eventUp && this.isShowingEndSlideshow)
			{
				b.Draw(Game1.staminaRect, new Rectangle(0, (int)((float)Game1.viewport.Height * 0.5f - 400f), Game1.viewport.Width, 8), Utility.GetPrismaticColor(0, 1f));
				b.Draw(Game1.staminaRect, new Rectangle(0, (int)((float)Game1.viewport.Height * 0.5f - 412f), Game1.viewport.Width, 4), Utility.GetPrismaticColor(0, 1f) * 0.8f);
				b.Draw(Game1.staminaRect, new Rectangle(0, (int)((float)Game1.viewport.Height * 0.5f - 432f), Game1.viewport.Width, 4), Utility.GetPrismaticColor(0, 1f) * 0.6f);
				b.Draw(Game1.staminaRect, new Rectangle(0, (int)((float)Game1.viewport.Height * 0.5f - 468f), Game1.viewport.Width, 4), Utility.GetPrismaticColor(0, 1f) * 0.4f);
				b.Draw(Game1.staminaRect, new Rectangle(0, (int)((float)Game1.viewport.Height * 0.5f - 536f), Game1.viewport.Width, 4), Utility.GetPrismaticColor(0, 1f) * 0.2f);
				b.Draw(Game1.staminaRect, new Rectangle(0, (int)((float)Game1.viewport.Height * 0.5f + 240f), Game1.viewport.Width, 8), Utility.GetPrismaticColor(0, 1f));
				b.Draw(Game1.staminaRect, new Rectangle(0, (int)((float)Game1.viewport.Height * 0.5f + 256f), Game1.viewport.Width, 4), Utility.GetPrismaticColor(0, 1f) * 0.8f);
				b.Draw(Game1.staminaRect, new Rectangle(0, (int)((float)Game1.viewport.Height * 0.5f + 276f), Game1.viewport.Width, 4), Utility.GetPrismaticColor(0, 1f) * 0.6f);
				b.Draw(Game1.staminaRect, new Rectangle(0, (int)((float)Game1.viewport.Height * 0.5f + 312f), Game1.viewport.Width, 4), Utility.GetPrismaticColor(0, 1f) * 0.4f);
				b.Draw(Game1.staminaRect, new Rectangle(0, (int)((float)Game1.viewport.Height * 0.5f + 380f), Game1.viewport.Width, 4), Utility.GetPrismaticColor(0, 1f) * 0.2f);
			}
		}

		// Token: 0x040021A4 RID: 8612
		private ICue wind;

		// Token: 0x040021A5 RID: 8613
		private float windGust;

		// Token: 0x040021A6 RID: 8614
		private float globalWind = -0.25f;

		// Token: 0x040021A7 RID: 8615
		[XmlIgnore]
		public bool isShowingEndSlideshow;
	}
}
